package com.glasslauncher.app

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CreateNewFolder
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/** One slot on the home grid or dock: an app or a folder. */
sealed class HomeEntry {
    class A(val app: AppEntry) : HomeEntry()
    class F(val folder: Folder) : HomeEntry()
}

fun entryKey(e: HomeEntry): String = when (e) {
    is HomeEntry.A -> e.app.pkg + "/" + e.app.cls
    is HomeEntry.F -> "f:" + e.folder.id
}

/** Turns stored ids ("pkg" or "f:<id>") into entries, skipping hidden apps and deleted folders. */
fun resolveEntries(state: AppState, ids: List<String>): List<HomeEntry> {
    val vis = state.visibleApps
    return ids.mapNotNull { id ->
        if (id.startsWith("f:")) state.folders.firstOrNull { "f:" + it.id == id }?.let { HomeEntry.F(it) }
        else vis.firstOrNull { it.pkg == id }?.let { HomeEntry.A(it) }
    }
}

/** iOS-style folder icon: glass squircle with up to four mini icons. */
@Composable
fun FolderIconView(folder: Folder, state: AppState, size: Dp) {
    val c = LocalColors.current
    val shape = RoundedCornerShape(percent = 24)
    val apps = folder.pkgs.mapNotNull { p -> state.visibleApps.firstOrNull { it.pkg == p } }.take(4)
    val mini = size * 0.36f
    Box(
        Modifier.size(size)
            .shadow(5.dp, shape, clip = false, ambientColor = Color(0x22000000), spotColor = Color(0x33000000))
            .clip(shape)
            .background(Brush.verticalGradient(listOf(c.glassHi, c.glassLo)))
            .border(1.dp, c.rim, shape)
            .padding(size * 0.1f)
    ) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceEvenly) {
            for (r in 0..1) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    for (k in 0..1) {
                        val a = apps.getOrNull(r * 2 + k)
                        if (a != null) AppIconView(a, state, mini) else Spacer(Modifier.size(mini))
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FolderTile(folder: Folder, state: AppState, modifier: Modifier = Modifier, onClick: () -> Unit, onLong: () -> Unit) {
    val c = LocalColors.current
    val src = remember { MutableInteractionSource() }
    val sc = pressScale(src)
    Column(
        modifier.graphicsLayer { scaleX = sc; scaleY = sc }
            .combinedClickable(interactionSource = src, indication = null, onClick = onClick, onLongClick = onLong)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        FolderIconView(folder, state, state.iconSize.dp)
        if (state.showLabels) {
            Spacer(Modifier.height(5.dp))
            Text(folder.name, color = c.text, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 2.dp))
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FolderDockIcon(folder: Folder, state: AppState, onClick: () -> Unit, onLong: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val sc = pressScale(src)
    Box(
        Modifier.graphicsLayer { scaleX = sc; scaleY = sc }
            .combinedClickable(interactionSource = src, indication = null, onClick = onClick, onLongClick = onLong)
    ) { FolderIconView(folder, state, state.iconSize.dp) }
}

/** The popup that opens when a folder is tapped. Long-press an app inside to take it out. */
@Composable
fun FolderDialog(folderId: String, state: AppState, onDismiss: () -> Unit, onEdit: () -> Unit) {
    val ctx = LocalContext.current
    val c = LocalColors.current
    val folder = state.folders.firstOrNull { it.id == folderId }
    if (folder == null) {
        LaunchedEffect(Unit) { onDismiss() }
        return
    }
    val apps = folder.pkgs.mapNotNull { p -> state.visibleApps.firstOrNull { it.pkg == p } }
    var removeApp by remember { mutableStateOf<AppEntry?>(null) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onDismiss() }, contentAlignment = Alignment.Center) {
            Column(
                Modifier.fillMaxWidth(0.9f).clip(RoundedCornerShape(30.dp)).background(c.dialog.copy(alpha = 0.96f))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(folder.name, color = c.text, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    TextButton(onClick = onEdit) { Text(tr("ویرایش", "Edit")) }
                }
                if (apps.isEmpty()) Text(tr("پوشه خالی است", "Folder is empty"), color = c.sub, fontSize = 14.sp, modifier = Modifier.padding(vertical = 16.dp))
                apps.chunked(4).forEach { row ->
                    Row(Modifier.fillMaxWidth()) {
                        row.forEach { a ->
                            AppTile(a, state, Modifier.weight(1f), onClick = { launchApp(ctx, a); onDismiss() }, onLong = { removeApp = a })
                        }
                        repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }
    }
    removeApp?.let { a ->
        AlertDialog(
            onDismissRequest = { removeApp = null },
            title = { Text(tr("برداشتن از پوشه؟", "Remove from folder?")) },
            text = { Text(a.label) },
            confirmButton = { TextButton(onClick = { state.removeFromFolder(folder.id, a.pkg); removeApp = null }) { Text(tr("برداشتن", "Remove")) } },
            dismissButton = { TextButton(onClick = { removeApp = null }) { Text(tr("انصراف", "Cancel")) } }
        )
    }
}

/** Create or edit a folder: name, apps, and whether it shows on the home screen / dock. */
@Composable
fun FolderEditorDialog(state: AppState, folderId: String?, preselect: String?, onDismiss: () -> Unit) {
    val c = LocalColors.current
    val existing = folderId?.let { id -> state.folders.firstOrNull { it.id == id } }
    var name by remember { mutableStateOf(existing?.name ?: "") }
    val sel = remember { mutableStateListOf<String>().apply { addAll(existing?.pkgs ?: listOfNotNull(preselect)) } }
    var inHome by remember { mutableStateOf(existing == null || ("f:" + existing.id) in state.pinned) }
    var inDock by remember { mutableStateOf(existing != null && ("f:" + existing.id) in state.dock) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxWidth(0.92f).fillMaxHeight(0.86f).clip(RoundedCornerShape(28.dp)).background(c.dialog).padding(16.dp)) {
            Text(
                if (existing == null) tr("پوشه‌ی جدید", "New folder") else tr("ویرایش پوشه", "Edit folder"),
                color = c.text, fontSize = 18.sp, fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = name, onValueChange = { name = it }, singleLine = true,
                label = { Text(tr("نام پوشه", "Folder name")) }, modifier = Modifier.fillMaxWidth()
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = inHome, onCheckedChange = { inHome = it })
                Text(tr("صفحه‌ی اصلی", "Home"), color = c.text, fontSize = 14.sp)
                Spacer(Modifier.width(16.dp))
                Checkbox(checked = inDock, onCheckedChange = { inDock = it })
                Text(tr("داک", "Dock"), color = c.text, fontSize = 14.sp)
            }
            Text(tr("برنامه‌ها", "Apps"), color = c.sub, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            LazyColumn(Modifier.weight(1f)) {
                items(state.apps, key = { it.pkg + "/" + it.cls }) { a ->
                    val on = a.pkg in sel
                    Row(
                        Modifier.fillMaxWidth().clickable { if (on) sel.remove(a.pkg) else sel.add(a.pkg) }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = on, onCheckedChange = { if (on) sel.remove(a.pkg) else sel.add(a.pkg) })
                        AppIconView(a, state, 32.dp)
                        Spacer(Modifier.width(10.dp))
                        Text(a.label, color = c.text, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onDismiss) { Text(tr("انصراف", "Cancel")) }
                Button(
                    enabled = sel.isNotEmpty(),
                    onClick = { state.saveFolder(folderId, name, sel.toList(), inHome, inDock); onDismiss() }
                ) { Text(tr("ذخیره", "Save")) }
            }
        }
    }
}

/** Long-press menu of a folder tile: edit or delete. */
@Composable
fun FolderMenu(folderId: String, state: AppState, onEdit: () -> Unit, onDismiss: () -> Unit) {
    val c = LocalColors.current
    val folder = state.folders.firstOrNull { it.id == folderId }
    var confirm by remember { mutableStateOf(false) }
    if (folder == null) {
        LaunchedEffect(Unit) { onDismiss() }
        return
    }
    val shape = RoundedCornerShape(20.dp)
    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.width(220.dp).clip(shape).background(c.dialog.copy(alpha = 0.95f)).border(1.dp, c.rim.copy(alpha = 0.6f), shape).padding(vertical = 6.dp)) {
            Text(folder.name, color = c.sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp))
            MenuItem(Icons.Outlined.Edit, tr("ویرایش پوشه", "Edit folder")) { onEdit() }
            MenuItem(Icons.Outlined.Delete, tr("حذف پوشه", "Delete folder"), c.danger) { confirm = true }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text(tr("حذف پوشه؟", "Delete folder?")) },
            text = { Text(tr("برنامه‌ها حذف نمی‌شوند، فقط پوشه برداشته می‌شود.", "Apps are not uninstalled, only the folder is removed.")) },
            confirmButton = { TextButton(onClick = { state.deleteFolder(folder.id); confirm = false; onDismiss() }) { Text(tr("حذف", "Delete"), color = c.danger) } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text(tr("انصراف", "Cancel")) } }
        )
    }
}

/** From an app's long-press menu: put it into a folder or start a new one. */
@Composable
fun AddToFolderDialog(app: AppEntry, state: AppState, onDismiss: () -> Unit) {
    val c = LocalColors.current
    var creating by remember { mutableStateOf(false) }
    if (creating) {
        FolderEditorDialog(state, null, app.pkg, onDismiss)
        return
    }
    val shape = RoundedCornerShape(20.dp)
    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.width(240.dp).clip(shape).background(c.dialog.copy(alpha = 0.95f)).border(1.dp, c.rim.copy(alpha = 0.6f), shape).padding(vertical = 6.dp)) {
            Text(tr("افزودن به پوشه", "Add to folder"), color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp))
            state.folders.forEach { f ->
                MenuItem(Icons.Outlined.Folder, f.name) { state.addToFolder(f.id, app.pkg); onDismiss() }
            }
            MenuItem(Icons.Outlined.CreateNewFolder, tr("پوشه‌ی جدید", "New folder")) { creating = true }
        }
    }
}
