package com.glasslauncher.app

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * App list (POCO style): all apps A-Z, no search bar. Swipe down (from the handle, or by pulling the list
 * down while it is at the top) closes it. One swipe right = categories; a second swipe right within 3 s
 * opens the pattern screen for the hidden vault.
 */
@Composable
fun DrawerScreen(
    state: AppState,
    open: Boolean,
    isPulling: () -> Boolean,
    onPull: (Float) -> Unit,
    onRelease: (Float) -> Unit,
    onPin: (AppEntry) -> Unit,
    onVault: () -> Unit
) {
    val ctx = LocalContext.current
    val c = LocalColors.current
    var page by remember { mutableIntStateOf(0) }
    var lastRight by remember { mutableLongStateOf(0L) }
    var menuApp by remember { mutableStateOf<AppEntry?>(null) }
    val vaultCb by rememberUpdatedState(onVault)
    val pullCb by rememberUpdatedState(onPull)
    val relCb by rememberUpdatedState(onRelease)
    val pullingCb by rememberUpdatedState(isPulling)
    LaunchedEffect(open) { if (!open) { page = 0; lastRight = 0L } }

    val nested = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (pullingCb() && available.y < 0f) { pullCb(available.y); return Offset(0f, available.y) }
                return Offset.Zero
            }
            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (source == NestedScrollSource.UserInput && available.y > 0f) { pullCb(available.y); return Offset(0f, available.y) }
                return Offset.Zero
            }
            override suspend fun onPreFling(available: Velocity): Velocity {
                if (pullingCb()) { relCb(available.y); return available }
                return Velocity.Zero
            }
        }
    }

    val list = state.visibleApps
    val groupNames = listOf(
        tr("اجتماعی", "Social"), tr("بازی", "Games"), tr("رسانه", "Media"),
        tr("بهره‌وری", "Productivity"), tr("سایر", "Other")
    )

    Column(
        Modifier.fillMaxSize().blockTouches().background(c.sheet).statusBarsPadding()
            .nestedScroll(nested)
            .swipeX(with(LocalDensity.current) { 56.dp.toPx() }) { dir ->
                if (dir > 0) {
                    val t = System.currentTimeMillis()
                    if (t - lastRight < 3500L) {
                        // second swipe right in a row -> hidden vault
                        lastRight = 0L
                        page = 0
                        vaultCb()
                    } else {
                        page = 1
                        lastRight = t
                    }
                } else {
                    page = 0
                    lastRight = 0L
                }
            }
    ) {
        // handle: drag it down to close the list
        Box(
            Modifier.fillMaxWidth().height(36.dp).pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragEnd = { relCb(0f) },
                    onDragCancel = { relCb(0f) },
                    onVerticalDrag = { _, dy -> pullCb(dy) }
                )
            },
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.width(40.dp).height(5.dp).clip(RoundedCornerShape(3.dp)).background(c.sub.copy(alpha = 0.5f)))
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(state.columns),
            modifier = Modifier.weight(1f).padding(horizontal = 14.dp),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            if (page == 0) {
                items(list, key = { it.pkg + "/" + it.cls }) { a ->
                    AppTile(a, state, Modifier, onDragUp = { onPin(a) }, onClick = { launchApp(ctx, a) }, onLong = { menuApp = a })
                }
            } else {
                for (g in 0..4) {
                    val gl = list.filter { categoryOf(it.cat) == g }
                    if (gl.isNotEmpty()) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            Text(groupNames[g], color = c.sub, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 6.dp, top = 12.dp, bottom = 4.dp))
                        }
                        items(gl, key = { it.pkg + "/" + it.cls }) { a ->
                            AppTile(a, state, Modifier, onDragUp = { onPin(a) }, onClick = { launchApp(ctx, a) }, onLong = { menuApp = a })
                        }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(bottom = 10.dp), horizontalArrangement = Arrangement.Center) {
            for (i in 0..1) {
                Box(Modifier.padding(horizontal = 3.dp).size(7.dp).clip(CircleShape).background(if (i == page) c.text else c.sub.copy(alpha = 0.4f)))
            }
        }
    }
    menuApp?.let { AppMenu(it, state) { menuApp = null } }
}
