package com.glasslauncher.app

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import kotlin.math.abs

/**
 * Vertical swipe that only starts when the finger moves clearly more up/down than sideways and nobody else
 * (dock scrolling, widgets, lists) has already consumed the gesture. This is what stops a diagonal scroll in the dock
 * from dragging the app list open.
 */
@Composable
fun Modifier.dragUpDown(onDelta: (Float) -> Unit, onEnd: () -> Unit): Modifier {
    val deltaCb by rememberUpdatedState(onDelta)
    val endCb by rememberUpdatedState(onEnd)
    return this.pointerInput(Unit) {
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false)
            val slop = viewConfiguration.touchSlop
            var dragging = false
            var tx = 0f
            var ty = 0f
            while (true) {
                val ev = awaitPointerEvent()
                val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                if (!ch.pressed) break
                val d = ch.positionChange()
                tx += d.x
                ty += d.y
                if (!dragging) {
                    if (ch.isConsumed) break
                    if (abs(ty) > slop && abs(ty) > abs(tx) * 1.8f) {
                        dragging = true
                        deltaCb(ty)
                    } else if (abs(tx) > slop * 2f) {
                        break
                    }
                } else {
                    deltaCb(d.y)
                    ch.consume()
                }
            }
            if (dragging) endCb()
        }
    }
}

/**
 * Horizontal swipe judged when the finger lifts: long enough and mostly sideways. It ignores whether a list
 * under the finger scrolled, so a quick swipe always counts. onSwipe gets +1 for right, -1 for left.
 */
@Composable
fun Modifier.swipeX(minPx: Float, onSwipe: (Int) -> Unit): Modifier {
    val cb by rememberUpdatedState(onSwipe)
    return this.pointerInput(Unit) {
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false)
            var tx = 0f
            var ty = 0f
            while (true) {
                val ev = awaitPointerEvent()
                val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                val d = ch.positionChange()
                tx += d.x
                ty += d.y
                if (!ch.pressed) break
            }
            if (abs(tx) > minPx && abs(tx) > abs(ty) * 1.2f) cb(if (tx > 0f) 1 else -1)
        }
    }
}
