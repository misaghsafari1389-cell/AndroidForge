package com.glasslauncher.app

import android.appwidget.AppWidgetProviderInfo
import android.os.Bundle
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/** Shows one Android app widget on the home screen. */
@Composable
fun WidgetView(state: AppState, id: Int) {
    val info = remember(id) { try { state.widgetManager.getAppWidgetInfo(id) } catch (e: Exception) { null } }
    if (info == null) return
    val d = LocalDensity.current
    val hDp = with(d) { info.minHeight.toDp() }.coerceIn(72.dp, 320.dp)
    val minW = (info.minWidth / d.density).toInt()
    AndroidView(
        factory = { c -> state.widgetHost.createView(c, id, info) },
        modifier = Modifier.fillMaxWidth().height(hDp).clip(RoundedCornerShape(24.dp)),
        update = { v -> v.updateAppWidgetSize(Bundle(), minW, hDp.value.toInt(), 360, hDp.value.toInt()) }
    )
}

/** List of widgets offered by installed apps; choosing one starts the bind/configure flow in MainActivity. */
@Composable
fun WidgetPickerDialog(state: AppState, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val c = LocalColors.current
    val items = remember {
        val pm = ctx.packageManager
        try {
            state.widgetManager.installedProviders
                .filter { (it.widgetCategory and AppWidgetProviderInfo.WIDGET_CATEGORY_HOME_SCREEN) != 0 }
                .map { info ->
                    val app = try { pm.getApplicationLabel(pm.getApplicationInfo(info.provider.packageName, 0)).toString() } catch (e: Exception) { info.provider.packageName }
                    val label = try { info.loadLabel(pm) } catch (e: Exception) { "Widget" }
                    Triple(info, app, label)
                }
                .sortedBy { it.second.lowercase() + it.third.lowercase() }
        } catch (e: Exception) { emptyList() }
    }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxWidth(0.92f).fillMaxHeight(0.8f).clip(RoundedCornerShape(28.dp)).background(c.dialog).padding(16.dp)) {
            Text(tr("افزودن ویجت", "Add widget"), color = c.text, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp))
            if (items.isEmpty()) Text(tr("ویجتی پیدا نشد", "No widgets found"), color = c.sub, fontSize = 14.sp)
            LazyColumn(Modifier.weight(1f)) {
                items(items, key = { it.first.provider.flattenToString() }) { t ->
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                            .clickable { state.widgetStarter?.invoke(t.first); onDismiss() }
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        Text(t.third, color = c.text, fontSize = 15.sp)
                        Text(t.second, color = c.sub, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
