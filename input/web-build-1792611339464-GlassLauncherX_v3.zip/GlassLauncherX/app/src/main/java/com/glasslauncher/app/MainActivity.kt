package com.glasslauncher.app

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge

class MainActivity : ComponentActivity() {
    private lateinit var state: AppState

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        state = AppState(applicationContext)
        state.widgetStarter = { info -> beginWidget(info) }
        setContent { GlTheme(state) { GlApp(state) } }
        handleApply(intent)
    }

    // ---- home-screen widgets: bind (ask permission if needed) -> configure (if the widget has a screen) -> add ----
    private val reqBind = 9101
    private val reqConfig = 9102
    private var pendingWidget = -1

    private fun beginWidget(info: AppWidgetProviderInfo) {
        try {
            val id = state.widgetHost.allocateAppWidgetId()
            pendingWidget = id
            if (state.widgetManager.bindAppWidgetIdIfAllowed(id, info.provider)) {
                afterBind(id)
            } else {
                val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
                @Suppress("DEPRECATION")
                startActivityForResult(i, reqBind)
            }
        } catch (e: Exception) { }
    }

    private fun afterBind(id: Int) {
        val info = try { state.widgetManager.getAppWidgetInfo(id) } catch (e: Exception) { null }
        if (info?.configure != null) {
            try {
                state.widgetHost.startAppWidgetConfigureActivityForResult(this, id, 0, reqConfig, null)
            } catch (e: Exception) {
                state.addWidget(id)
            }
        } else {
            state.addWidget(id)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val id = data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingWidget) ?: pendingWidget
        if (requestCode == reqBind) {
            if (resultCode == RESULT_OK) afterBind(id) else try { state.widgetHost.deleteAppWidgetId(id) } catch (e: Exception) { }
        } else if (requestCode == reqConfig) {
            if (resultCode == RESULT_OK) state.addWidget(id) else try { state.widgetHost.deleteAppWidgetId(id) } catch (e: Exception) { }
        }
    }

    override fun onStart() {
        super.onStart()
        try { state.widgetHost.startListening() } catch (e: Exception) { }
    }

    /** Some icon-pack apps send an "apply" intent (Nova / ADW / Apex style). Returns true if it was one. */
    private fun handleApply(i: Intent?): Boolean {
        if (i == null) return false
        val pkg: String? = when (i.action) {
            "com.teslacoilsw.launcher.APPLY_ICON_THEME" -> i.getStringExtra("com.teslacoilsw.launcher.extra.ICON_THEME_PACKAGE")
            "org.adw.launcher.SET_THEME" -> i.getStringExtra("org.adw.launcher.theme.NAME")
            "com.anddoes.launcher.SET_THEME" -> i.getStringExtra("com.anddoes.launcher.THEME_PACKAGE_NAME")
            else -> null
        }
        if (pkg.isNullOrBlank()) return false
        state.setIconPack(pkg)
        return true
    }

    override fun onResume() {
        super.onResume()
        state.suppressLock = false
        state.resumeTick++
    }

    override fun onStop() {
        super.onStop()
        try { state.widgetHost.stopListening() } catch (e: Exception) { }
        state.requestLock()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (!handleApply(intent)) {
            // Home button pressed while the launcher is already running
            state.homeTick++
        }
    }
}
