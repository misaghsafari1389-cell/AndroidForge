package com.glasslauncher.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * progress(): 0 = home, 1 = app list fully open (read inside graphicsLayer so the animation never recomposes).
 * onSwipe(dy) / onSwipeEnd() let the parent move the app list under the finger.
 */
@Composable
fun HomeScreen(
    state: AppState,
    progress: () -> Float,
    onSwipe: (Float) -> Unit,
    onSwipeEnd: () -> Unit,
    openSettings: () -> Unit
) {
    val ctx = LocalContext.current
    val c = LocalColors.current
    val fa = state.lang == "fa"
    var menuApp by remember { mutableStateOf<AppEntry?>(null) }
    var openFolder by remember { mutableStateOf<String?>(null) }
    var folderMenu by remember { mutableStateOf<String?>(null) }
    var editFolder by remember { mutableStateOf<String?>(null) }
    val now by produceState(System.currentTimeMillis()) {
        while (true) { value = System.currentTimeMillis(); delay(15_000L) }
    }
    val timeStr = remember(now, fa) {
        val s = SimpleDateFormat("HH:mm", Locale.US).format(Date(now))
        if (fa) faDigits(s) else s
    }
    val dateStr = remember(now, fa) { CalUtil.fmtLong(fa, CalUtil.today()) }
    val homeEntries = resolveEntries(state, state.pinned)
    val dockEntries = resolveEntries(state, state.dock)

    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
            .dragUpDown(onDelta = onSwipe, onEnd = onSwipeEnd)
            .padding(horizontal = 18.dp)
    ) {
        Column(
            Modifier.weight(1f).fillMaxWidth().clipToBounds().graphicsLayer {
                val p = progress()
                alpha = 1f - 0.7f * p
                scaleX = 1f - 0.05f * p
                scaleY = 1f - 0.05f * p
            }
        ) {
            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth().glass(30.dp).padding(horizontal = 22.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(timeStr, color = c.text, fontSize = 52.sp, fontWeight = FontWeight.Light)
                    Text(dateStr, color = c.sub, fontSize = 14.sp)
                }
                IconButton(onClick = openSettings) {
                    Icon(Icons.Outlined.Settings, contentDescription = null, tint = c.text)
                }
            }
            state.widgetIds.toList().forEach { id ->
                Spacer(Modifier.height(12.dp))
                WidgetView(state, id)
            }
            Spacer(Modifier.height(18.dp))
            homeEntries.chunked(state.columns).forEach { row ->
                Row(Modifier.fillMaxWidth()) {
                    row.forEach { e ->
                        when (e) {
                            is HomeEntry.A -> AppTile(e.app, state, Modifier.weight(1f), onClick = { launchApp(ctx, e.app) }, onLong = { menuApp = e.app })
                            is HomeEntry.F -> FolderTile(e.folder, state, Modifier.weight(1f), onClick = { openFolder = e.folder.id }, onLong = { folderMenu = e.folder.id })
                        }
                    }
                    repeat(state.columns - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
        // dock: slides down and fades while the app list rises, comes back up when it closes
        LazyRow(
            Modifier.fillMaxWidth().graphicsLayer {
                val p = progress()
                translationY = p * 170.dp.toPx()
                alpha = 1f - p
            }.glass(34.dp),
            contentPadding = PaddingValues(horizontal = 18.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items(dockEntries, key = { entryKey(it) }) { e ->
                when (e) {
                    is HomeEntry.A -> DockIcon(e.app, state, onClick = { launchApp(ctx, e.app) }, onLong = { menuApp = e.app })
                    is HomeEntry.F -> FolderDockIcon(e.folder, state, onClick = { openFolder = e.folder.id }, onLong = { folderMenu = e.folder.id })
                }
            }
        }
        Spacer(Modifier.height(10.dp))
    }
    menuApp?.let { AppMenu(it, state) { menuApp = null } }
    openFolder?.let { id -> FolderDialog(id, state, onDismiss = { openFolder = null }, onEdit = { editFolder = id; openFolder = null }) }
    folderMenu?.let { id -> FolderMenu(id, state, onEdit = { editFolder = id; folderMenu = null }, onDismiss = { folderMenu = null }) }
    editFolder?.let { id -> FolderEditorDialog(state, id, null) { editFolder = null } }
}
