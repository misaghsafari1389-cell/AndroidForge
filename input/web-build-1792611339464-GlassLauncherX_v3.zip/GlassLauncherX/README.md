# GlassLauncherX (گلس لانچر)

Native Android launcher (Kotlin + Jetpack Compose), Persian RTL by default, English optional.
Same project layout as TacticalLauncherX (single `app` module, `AppState` in SharedPreferences,
one file per screen, GitHub Actions debug-APK workflow).

Design: white "liquid glass" surfaces (translucent gradient + bright rim light), iOS-style squircle icons
and floating dock, with Xiaomi/POCO behaviour (app drawer, categories, hidden vault via double swipe).

## Features (v3)
- Home: glass clock card, pinned apps, scrollable glass dock (up to 12 apps). No search bars.
- App list: swipe up from anywhere on home; it follows your finger with a soft spring, the dock slides down and fades,
  and it comes back when you close it. **Close by swiping down** (drag the handle, or pull the list down when it is at the top),
  by the Back gesture, or the Home button.
- POCO behaviour: one swipe right = categories; **second swipe right within 3 s = pattern screen -> vault.**
- Vault (private storage, FLAG_SECURE, closes when you leave the app): photos, videos, documents, and hidden apps.
  Hidden apps can be **launched from the vault** (tap) or unhidden. Pattern is stored as a salted hash; changing it needs the old one
  and the old pattern stays valid until the new one is confirmed. 5 wrong tries = 30 s lock.
- Long-press an app: minimal popup (pin to home, add/remove dock, hide, app info, **uninstall**). Uninstall asks for confirmation,
  then Android shows its own confirmation (permission REQUEST_DELETE_PACKAGES). System apps cannot be uninstalled.
- Wallpaper: pick a photo, then **zoom and move it in an editor before applying** (pinch, drag or slider; WYSIWYG for the full screen).
- Icon packs: installed packs (ADW/Nova/GO/Apex `appfilter.xml`), **icon packs from a ZIP file** (Settings -> Icon pack -> Add from ZIP;
  the ZIP can hold PNG/WebP icons and a plain-text appfilter.xml; without it icons are matched by file name such as `com_whatsapp.png`),
  and "apply to launcher" intents from icon-pack apps that send them (Nova / ADW / Apex style).
- Folders: create / edit / delete in Settings -> Folders (name, apps, show on home and/or dock) or from an app's menu ("Add to folder").
  Folders look like iOS folders (glass tile with mini icons), open as a popup, long-press a folder to edit or delete it,
  long-press an app inside a folder to take it out.
- Pin by dragging: in the app list, long-press an app and drag it **up** to put it on the home screen (long-press without moving = menu).
- Widgets: Settings -> Widgets -> add any Android widget to the home screen (Android asks permission to bind it, and shows the widget's
  own setup screen if it has one). Remove them from the same list.
- Dock scrolling is smooth: icons are produced off the main thread, and a diagonal scroll in the dock no longer drags the app list open.
- Hidden vault gesture: the second swipe right is judged when the finger lifts (long enough, mostly sideways), so it works the first time
  even when the list under your finger scrolls a little. Window for the second swipe is 3.5 s.
- Settings: white/dark glass, glass strength, icon size, columns, labels, wallpaper (+blur on Android 12+), change pattern,
  default launcher, language fa/en.

## Build
- AGP 8.5.2, Kotlin 1.9.24, Gradle 8.9, JDK 17, minSdk 26, targetSdk 34
- `gradle assembleDebug` -> `app/build/outputs/apk/debug/app-debug.apk`
- GitHub: push to `main`, the workflow `Build debug APK` uploads the APK. Vazirmatn font via `scripts/download_fonts.sh` (optional).
- No INTERNET permission is requested.

## Known limits (honest list)
- Vault files are in app-private storage but **not encrypted yet** (next step: AES-GCM with an Android Keystore key).
- Pattern only (no fingerprint yet; BiometricPrompt can be added).
- "Hide" removes apps from this launcher only; other launchers still show them.
- Glass is drawn with gradients and rim light (no live backdrop blur of other apps; Android cannot do that for a launcher).
- ZIP icon packs: a binary appfilter.xml (copied straight out of an APK) cannot be read; file-name matching is used instead.
- Icon-pack apps that only list launchers they know by package name will not show this launcher; use Settings -> Icon pack instead.
- Widgets sit in a fixed area under the clock (no scrolling); many large widgets will be clipped, remove some in Settings.
- Not compiled in the authoring environment, see BUILD_STATUS.txt.
