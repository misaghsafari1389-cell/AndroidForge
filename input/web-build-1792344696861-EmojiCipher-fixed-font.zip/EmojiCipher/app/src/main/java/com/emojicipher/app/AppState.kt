package com.emojicipher.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.emojicipher.app.data.HistoryItem
import com.emojicipher.app.data.HistoryRepository
import com.emojicipher.app.data.HistoryType

data class ToastMessage(val text: String, val id: Long = System.nanoTime())

/** UI-facing state + platform integrations (clipboard, share sheet). Message text is never logged. */
class AppState(private val context: Context, private val repo: HistoryRepository) {

    var history: List<HistoryItem> by mutableStateOf(repo.load())
        private set
    var historyEnabled: Boolean by mutableStateOf(repo.historyEnabled)
        private set
    var toast: ToastMessage? by mutableStateOf(null)

    val onboardingDone: Boolean get() = repo.onboardingDone

    fun completeOnboarding() { repo.onboardingDone = true }

    fun record(type: HistoryType, text: String, emojis: String) {
        history = repo.add(type, text, emojis)
    }

    fun setHistoryEnabled(enabled: Boolean) {
        repo.historyEnabled = enabled
        historyEnabled = enabled
    }

    fun deleteItem(id: Long) { history = repo.delete(id) }

    fun clearHistory() {
        history = repo.clear()
        showToast("تاریخچه پاک شد")
    }

    fun showToast(text: String) { toast = ToastMessage(text) }

    fun copy(text: String, confirmation: String = "کپی شد") {
        try {
            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Emoji Cipher", text))
            showToast(confirmation)
        } catch (e: Exception) {
            showToast("کپی انجام نشد")
        }
    }

    /** Returns the clipboard text, or null if empty / not readable. */
    fun readClipboard(): String? = try {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(context)?.toString()
    } catch (e: Exception) {
        null
    }

    fun share(text: String) {
        try {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            }
            val chooser = Intent.createChooser(send, "اشتراک‌گذاری").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        } catch (e: Exception) {
            showToast("اشتراک‌گذاری انجام نشد")
        }
    }

    fun versionName(): String = try {
        context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "1.0.0"
    } catch (e: Exception) {
        "1.0.0"
    }
}
