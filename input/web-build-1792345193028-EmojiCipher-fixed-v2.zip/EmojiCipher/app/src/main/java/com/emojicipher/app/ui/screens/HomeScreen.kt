package com.emojicipher.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material.icons.rounded.IosShare
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.emojicipher.app.ui.components.IconActionButton
import com.emojicipher.app.ui.components.IconTile
import com.emojicipher.app.ui.components.glass
import com.emojicipher.app.ui.theme.TextPrimary
import com.emojicipher.app.ui.theme.TextSecondary

@Composable
fun HomeScreen(onEncode: () -> Unit, onDecode: () -> Unit, onSettings: () -> Unit) {
    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)
    ) {
        Box(Modifier.fillMaxWidth().height(64.dp)) {
            Text(
                "رمزگذاری پیام", color = TextPrimary, fontSize = 24.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.Center)
            )
            IconActionButton(
                Icons.Rounded.Settings, "تنظیمات", onSettings,
                modifier = Modifier.align(Alignment.CenterStart), tint = TextSecondary
            )
        }
        Spacer(Modifier.height(20.dp))
        HomeCard(
            icon = Icons.Rounded.Edit,
            title = "رمزگذاری پیام",
            description = "متن خود را بنویسید و به ایموجی تبدیل کنید.",
            onClick = onEncode
        )
        Spacer(Modifier.height(20.dp))
        HomeCard(
            icon = Icons.Rounded.Translate,
            title = "ترجمه پیام",
            description = "پیام ایموجی را وارد کنید و متن اصلی را دریافت کنید.",
            onClick = onDecode
        )
        Spacer(Modifier.height(130.dp))
    }
}

/** Card geometry follows the reference: icon tile top-left, text right-aligned, chevron on the right edge. */
@Composable
private fun HomeCard(icon: ImageVector, title: String, description: String, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth()
            .glass(RoundedCornerShape(30.dp), tintAlpha = 0.38f)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(20.dp)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Box(Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(end = 28.dp), horizontalAlignment = Alignment.End) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        IconTile(icon)
                        Text(title, color = TextPrimary, fontSize = 21.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Right)
                    }
                    Spacer(Modifier.height(14.dp))
                    Text(
                        description, color = TextSecondary, fontSize = 14.sp, lineHeight = 24.sp,
                        textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth()
                    )
                }
                Icon(
                    Icons.Rounded.ChevronRight, null, tint = TextSecondary,
                    modifier = Modifier.align(Alignment.CenterEnd).size(24.dp)
                )
            }
        }
    }
}
