package com.emojicipher.app.data

enum class HistoryType { ENCODE, DECODE }

/**
 * One saved operation.
 * [text]   is the plain message (input for ENCODE, result for DECODE).
 * [emojis] is the emoji message (result for ENCODE, input for DECODE).
 */
data class HistoryItem(
    val id: Long,
    val type: HistoryType,
    val text: String,
    val emojis: String,
    val timestamp: Long
)
