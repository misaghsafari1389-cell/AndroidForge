package com.emojicipher.app.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.emojicipher.app.ui.theme.AccentBlueBottom
import com.emojicipher.app.ui.theme.AccentBlueTop
import com.emojicipher.app.ui.theme.ErrorSoft
import com.emojicipher.app.ui.theme.TextMuted
import com.emojicipher.app.ui.theme.TextPrimary
import com.emojicipher.app.ui.theme.TextSecondary

enum class ButtonStyle { Welcome, Primary, Secondary }

/** Glass button. Icon/text order follows the reference (physical left-to-right). */
@Composable
fun GlassButton(
    text: String,
    icon: ImageVector?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    style: ButtonStyle = ButtonStyle.Primary,
    iconAfterText: Boolean = false,
    height: Dp = 52.dp
) {
    val shape = RoundedCornerShape(22.dp)
    val (tint, tintAlpha, borderAlpha) = when (style) {
        ButtonStyle.Welcome -> Triple(Color(0xFF5A748E), 0.62f, 0.34f)
        ButtonStyle.Primary -> Triple(Color(0xFF3F6086), 0.62f, 0.32f)
        ButtonStyle.Secondary -> Triple(Color(0xFF2A4566), 0.50f, 0.24f)
    }
    Box(
        modifier
            .height(height)
            .alpha(if (enabled) 1f else 0.45f)
            .glass(shape, tint = tint, tintAlpha = tintAlpha, borderAlpha = borderAlpha)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(horizontal = 12.dp)
            ) {
                if (icon != null && !iconAfterText) Icon(icon, null, tint = TextPrimary, modifier = Modifier.size(20.dp))
                Text(text, color = TextPrimary, fontSize = 15.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Medium, maxLines = 1)
                if (icon != null && iconAfterText) Icon(icon, null, tint = TextPrimary, modifier = Modifier.size(20.dp))
            }
        }
    }
}

/** Large rounded translucent panel. */
@Composable
fun GlassPanel(modifier: Modifier = Modifier, padding: Dp = 16.dp, content: @Composable () -> Unit) {
    Column(modifier.fillMaxWidth().glass(RoundedCornerShape(28.dp)).padding(padding)) { content() }
}

/** Compact top bar: back arrow on the physical left (as in the reference), centred title. */
@Composable
fun GlassTopBar(
    title: String,
    onBack: (() -> Unit)?,
    modifier: Modifier = Modifier,
    trailing: @Composable (() -> Unit)? = null
) {
    Box(modifier.fillMaxWidth().height(56.dp)) {
        if (onBack != null) {
            Box(
                Modifier.align(Alignment.CenterEnd).size(48.dp).clip(RoundedCornerShape(24.dp))
                    .clickable(role = Role.Button, onClick = onBack)
                    .semantics { contentDescription = "بازگشت" },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Rounded.ArrowBack, null, tint = TextPrimary, modifier = Modifier.size(24.dp)) }
        }
        Text(
            title, color = TextPrimary, fontSize = 18.sp,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
            modifier = Modifier.align(Alignment.Center)
        )
        if (trailing != null) Box(Modifier.align(Alignment.CenterStart)) { trailing() }
    }
}

@Composable
fun IconActionButton(icon: ImageVector, description: String, onClick: () -> Unit, modifier: Modifier = Modifier, tint: Color = TextPrimary, size: Dp = 48.dp) {
    Box(
        modifier.size(size).clip(RoundedCornerShape(size / 2)).clickable(role = Role.Button, onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp)) }
}

/** Blue rounded icon tile used on the home cards. */
@Composable
fun IconTile(icon: ImageVector, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier.size(54.dp).clip(shape)
            .background(Brush.verticalGradient(listOf(AccentBlueTop, AccentBlueBottom)))
            .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(0.55f), Color.White.copy(0.1f))), shape),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(26.dp)) }
}

/** Speech-bubble-with-smile emblem (welcome screen), drawn with vector paths. */
@Composable
fun AppEmblem(modifier: Modifier = Modifier, size: Dp = 112.dp) {
    Box(
        modifier.size(size).glass(RoundedCornerShape(size * 0.28f), tintAlpha = 0.5f, borderAlpha = 0.34f),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(size * 0.66f)) {
            val w = this.size.width
            val h = this.size.height
            val brush = Brush.verticalGradient(listOf(Color(0xFFFFFFFF), Color(0xFFC3CEDA)))
            val bubble = Path().apply {
                addRoundRect(RoundRect(Rect(0f, 0f, w, h * 0.84f), CornerRadius(w * 0.34f)))
            }
            val tail = Path().apply {
                moveTo(w * 0.20f, h * 0.76f)
                lineTo(w * 0.10f, h * 1.0f)
                lineTo(w * 0.44f, h * 0.82f)
                close()
            }
            drawPath(bubble, brush)
            drawPath(tail, brush)
            val dark = Color(0xFF1F2B3A)
            val eyeW = w * 0.09f
            val eyeH = h * 0.14f
            drawOval(dark, Offset(w * 0.31f, h * 0.24f), Size(eyeW, eyeH))
            drawOval(dark, Offset(w * 0.60f, h * 0.24f), Size(eyeW, eyeH))
            drawArc(
                dark, startAngle = 25f, sweepAngle = 130f, useCenter = false,
                topLeft = Offset(w * 0.27f, h * 0.22f), size = Size(w * 0.46f, h * 0.38f),
                style = Stroke(width = w * 0.055f, cap = StrokeCap.Round)
            )
        }
    }
}

/** Dark inset area used inside panels (input field background). */
@Composable
fun InsetBox(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Box(
        modifier.fillMaxWidth().clip(shape).background(Color(0xFF050B14).copy(alpha = 0.30f))
            .border(1.dp, Color.White.copy(alpha = 0.07f), shape)
    ) { content() }
}

/** Multiline text input on a glass panel with label and code-point counter. */
@Composable
fun MessageInputPanel(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    counter: String,
    minHeight: Dp = 150.dp,
    maxInputHeight: Dp = 320.dp,
    emojiStyle: Boolean = false,
    onPaste: (() -> Unit)? = null
) {
    GlassPanel {
        Text(label, color = TextSecondary, fontSize = 13.sp, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        InsetBox {
            Box(Modifier.fillMaxWidth().heightIn(min = minHeight, max = maxInputHeight)) {
                val textStyle = TextStyle(
                    color = TextPrimary,
                    fontSize = if (emojiStyle) 24.sp else 18.sp,
                    lineHeight = if (emojiStyle) 38.sp else 28.sp,
                    fontFamily = MaterialTheme.typography.bodyLarge.fontFamily,
                    textDirection = if (emojiStyle) TextDirection.Ltr else TextDirection.Content,
                    textAlign = TextAlign.Start
                )
                BasicTextField(
                    value = value,
                    onValueChange = onValueChange,
                    textStyle = textStyle,
                    cursorBrush = SolidColor(AccentBlueTop),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Default),
                    modifier = Modifier.fillMaxWidth().heightIn(min = minHeight, max = maxInputHeight)
                        .padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 36.dp),
                    decorationBox = { inner ->
                        Box(Modifier.fillMaxWidth()) {
                            if (value.isEmpty()) Text(
                                placeholder, color = TextMuted,
                                style = textStyle.copy(textDirection = TextDirection.Content, fontSize = 16.sp, lineHeight = 26.sp)
                            )
                            inner()
                        }
                    }
                )
                Text(
                    counter, color = TextMuted, fontSize = 12.sp,
                    modifier = Modifier.align(Alignment.BottomEnd).padding(14.dp)
                )
                if (onPaste != null) {
                    IconActionButton(
                        Icons.Rounded.ContentPaste, "چسباندن از کلیپ‌بورد", onPaste,
                        modifier = Modifier.align(Alignment.BottomStart).padding(4.dp),
                        tint = TextSecondary, size = 44.dp
                    )
                }
            }
        }
    }
}

/** Output panel. Emoji text is always shown left-to-right so the sequence reads like the reference. */
@Composable
fun ResultPanel(
    label: String,
    content: String,
    placeholder: String,
    error: String?,
    emojiMode: Boolean,
    counter: String? = null
) {
    GlassPanel {
        Text(label, color = TextSecondary, fontSize = 13.sp, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        Box(Modifier.fillMaxWidth().heightIn(min = 72.dp, max = 280.dp).verticalScroll(rememberScrollState())) {
            when {
                error != null -> Text(error, color = ErrorSoft, fontSize = 15.sp, modifier = Modifier.fillMaxWidth())
                content.isEmpty() -> Text(placeholder, color = TextMuted, fontSize = 15.sp, modifier = Modifier.fillMaxWidth())
                emojiMode -> Text(
                    content, fontSize = 26.sp, lineHeight = 44.sp, letterSpacing = 6.sp,
                    style = TextStyle(textDirection = TextDirection.Ltr, textAlign = TextAlign.Start),
                    modifier = Modifier.fillMaxWidth()
                )
                else -> Text(
                    content, color = TextPrimary, fontSize = 22.sp, lineHeight = 34.sp,
                    style = TextStyle(textDirection = TextDirection.Content, textAlign = TextAlign.Start),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        if (counter != null && error == null && content.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Box(Modifier.fillMaxWidth()) {
                Text(counter, color = TextMuted, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterEnd))
            }
        }
    }
}

/** Floating glass bottom navigation. Physical order (left to right): Home, History, Settings, as in the reference. */
@Composable
fun FloatingNav(current: String, onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    val items = listOf(
        Triple("home", "خانه", Icons.Rounded.Home),
        Triple("history", "تاریخچه", Icons.Rounded.History),
        Triple("settings", "تنظیمات", Icons.Rounded.Settings)
    )
    val outer = RoundedCornerShape(30.dp)
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)
                .navigationBarsPadding()
                .glass(outer, tintAlpha = 0.5f, borderAlpha = 0.28f)
                .padding(6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            items.forEach { (route, label, icon) ->
                val selected = current == route
                val itemShape = RoundedCornerShape(24.dp)
                Column(
                    Modifier.weight(1f).heightIn(min = 56.dp).clip(itemShape)
                        .then(
                            if (selected) Modifier.background(Color.White.copy(alpha = 0.13f), itemShape)
                                .border(1.dp, Color.White.copy(alpha = 0.22f), itemShape)
                            else Modifier
                        )
                        .clickable(role = Role.Tab) { onSelect(route) }
                        .semantics { contentDescription = label }
                        .padding(vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(icon, null, tint = if (selected) Color.White else TextSecondary, modifier = Modifier.size(24.dp))
                    Spacer(Modifier.height(2.dp))
                    Text(
                        label, fontSize = 11.sp,
                        color = if (selected) Color.White else TextSecondary,
                        fontWeight = if (selected) androidx.compose.ui.text.font.FontWeight.Bold else androidx.compose.ui.text.font.FontWeight.Normal
                    )
                }
            }
        }
    }
}

/** Subtle confirmation pill ("copied"). */
@Composable
fun GlassToast(message: String?, modifier: Modifier = Modifier) {
    AnimatedVisibility(
        visible = message != null,
        enter = fadeIn() + slideInVertically { it / 2 },
        exit = fadeOut() + slideOutVertically { it / 2 },
        modifier = modifier
    ) {
        Box(
            Modifier.glass(RoundedCornerShape(24.dp), tintAlpha = 0.62f, borderAlpha = 0.3f)
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) { Text(message ?: "", color = TextPrimary, fontSize = 14.sp) }
    }
}

@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    confirmLabel: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    dismissLabel: String = "انصراف"
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF14202E),
        titleContentColor = TextPrimary,
        textContentColor = TextSecondary,
        shape = RoundedCornerShape(28.dp),
        title = { Text(title, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) },
        text = { Text(message) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirmLabel, color = ErrorSoft) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(dismissLabel, color = TextPrimary) } }
    )
}

@Composable
fun InfoDialog(title: String, message: String, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF14202E),
        titleContentColor = TextPrimary,
        textContentColor = TextSecondary,
        shape = RoundedCornerShape(28.dp),
        title = { Text(title, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) },
        text = { Text(message) },
        confirmButton = { TextButton(onClick = onDismiss) { Text("باشه", color = TextPrimary) } }
    )
}
