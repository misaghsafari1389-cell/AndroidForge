package com.emojicipher.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.IosShare
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.unit.dp
import com.emojicipher.app.AppState
import com.emojicipher.app.codec.EmojiCodec
import com.emojicipher.app.data.HistoryType
import com.emojicipher.app.ui.codePoints
import com.emojicipher.app.ui.components.ButtonStyle
import com.emojicipher.app.ui.components.GlassButton
import com.emojicipher.app.ui.components.GlassTopBar
import com.emojicipher.app.ui.components.MessageInputPanel
import com.emojicipher.app.ui.components.ResultPanel
import com.emojicipher.app.ui.decodeErrorText
import com.emojicipher.app.ui.limitCodePoints

@Composable
fun DecodeScreen(state: AppState, onBack: () -> Unit) {
    var input by rememberSaveable { mutableStateOf("") }
    var output by rememberSaveable { mutableStateOf("") }
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    val focus = LocalFocusManager.current
    val max = EmojiCodec.MAX_DECODE_INPUT_CODE_POINTS

    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding().padding(horizontal = 16.dp)
    ) {
        GlassTopBar("ترجمه پیام", onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            MessageInputPanel(
                label = "پیام ایموجی",
                value = input,
                onValueChange = { new ->
                    input = limitCodePoints(new, max)
                    output = ""
                    error = null
                },
                placeholder = "پیام ایموجی را اینجا بچسبانید…",
                counter = "${codePoints(input)}",
                emojiStyle = true,
                onPaste = {
                    val clip = state.readClipboard()
                    if (clip.isNullOrEmpty()) state.showToast("کلیپ‌بورد خالی است")
                    else { input = limitCodePoints(clip, max); output = ""; error = null }
                }
            )
            GlassButton(
                text = "ترجمه پیام", icon = Icons.Rounded.Translate,
                modifier = Modifier.fillMaxWidth(), style = ButtonStyle.Primary,
                onClick = {
                    focus.clearFocus()
                    when (val r = EmojiCodec.decode(input)) {
                        is EmojiCodec.DecodeResult.Success -> {
                            output = r.text
                            error = null
                            state.record(HistoryType.DECODE, r.text, input.trim())
                        }
                        is EmojiCodec.DecodeResult.Failure -> {
                            output = ""
                            error = decodeErrorText(r.error)
                        }
                    }
                }
            )
            ResultPanel(
                label = "متن اصلی", content = output,
                placeholder = "متن اصلی پس از ترجمه اینجا نمایش داده می‌شود.",
                error = error, emojiMode = false
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                GlassButton(
                    "اشتراک‌گذاری", Icons.Rounded.IosShare, { state.share(output) },
                    Modifier.weight(1f), enabled = output.isNotEmpty(), style = ButtonStyle.Secondary, iconAfterText = true
                )
                GlassButton(
                    "کپی کردن", Icons.Rounded.ContentCopy, { state.copy(output) },
                    Modifier.weight(1f), enabled = output.isNotEmpty(), style = ButtonStyle.Secondary, iconAfterText = true
                )
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}
