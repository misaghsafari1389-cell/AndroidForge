package com.emojicipher.app.ui.components

import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.emojicipher.app.ui.theme.GlassTint

/**
 * Frosted "liquid glass" surface:
 *  1. the pre-blurred landscape, aligned with the screen background,
 *  2. the same navy dimming the background has,
 *  3. a translucent blue-grey tint,
 *  4. a soft highlight along the top edge,
 *  5. a thin low-opacity white border (brighter on top).
 */
fun Modifier.glass(
    shape: Shape = RoundedCornerShape(28.dp),
    tint: Color = GlassTint,
    tintAlpha: Float = 0.42f,
    borderAlpha: Float = 0.26f,
    borderWidth: Dp = 1.dp
): Modifier = composed {
    val backdrop = LocalBackdrop.current
    var origin by remember { mutableStateOf(Offset.Zero) }
    this
        .onGloballyPositioned { origin = it.positionInRoot() }
        .clip(shape)
        .drawBehind {
            if (backdrop != null) {
                withTransform({ translate(-origin.x, -origin.y) }) {
                    drawCover(backdrop.blurred, backdrop.widthPx, backdrop.heightPx)
                    drawDim(backdrop.dim.value, backdrop.widthPx, backdrop.heightPx)
                }
            }
            drawRect(tint.copy(alpha = tintAlpha))
            drawRect(
                Brush.verticalGradient(
                    0f to Color.White.copy(alpha = 0.13f),
                    0.35f to Color.White.copy(alpha = 0.03f),
                    1f to Color.Transparent
                )
            )
        }
        .border(
            borderWidth,
            Brush.verticalGradient(
                listOf(Color.White.copy(alpha = borderAlpha + 0.12f), Color.White.copy(alpha = borderAlpha * 0.35f))
            ),
            shape
        )
}
