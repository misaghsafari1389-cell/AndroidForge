package com.emojicipher.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.emojicipher.app.AppState
import com.emojicipher.app.data.HistoryItem
import com.emojicipher.app.data.HistoryType
import com.emojicipher.app.ui.components.ConfirmDialog
import com.emojicipher.app.ui.components.GlassPanel
import com.emojicipher.app.ui.components.GlassTopBar
import com.emojicipher.app.ui.components.IconActionButton
import com.emojicipher.app.ui.formatTimestamp
import com.emojicipher.app.ui.theme.TextMuted
import com.emojicipher.app.ui.theme.TextPrimary
import com.emojicipher.app.ui.theme.TextSecondary

@Composable
fun HistoryScreen(state: AppState) {
    var confirmClear by remember { mutableStateOf(false) }
    val entries = state.history

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp)) {
        GlassTopBar(
            title = "تاریخچه", onBack = null,
            trailing = {
                if (entries.isNotEmpty()) {
                    IconActionButton(Icons.Rounded.DeleteSweep, "پاک کردن همه‌ی تاریخچه", { confirmClear = true }, tint = TextSecondary)
                }
            }
        )
        if (entries.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth().padding(bottom = 120.dp), contentAlignment = Alignment.Center) {
                GlassPanel(padding = 24.dp) {
                    Text("تاریخچه خالی است", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        if (state.historyEnabled) "پیام‌هایی که رمزگذاری یا ترجمه کنید اینجا ذخیره می‌شوند."
                        else "ذخیره‌ی تاریخچه در تنظیمات خاموش است.",
                        color = TextSecondary, fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        } else {
            LazyColumn(
                Modifier.weight(1f),
                contentPadding = PaddingValues(top = 8.dp, bottom = 130.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(entries, key = { it.id }) { item ->
                    HistoryCard(
                        item,
                        onCopy = {
                            if (item.type == HistoryType.ENCODE) state.copy(item.emojis) else state.copy(item.text)
                        },
                        onDelete = { state.deleteItem(item.id) }
                    )
                }
            }
        }
    }

    if (confirmClear) {
        ConfirmDialog(
            title = "پاک کردن تاریخچه",
            message = "همه‌ی موارد ذخیره‌شده برای همیشه حذف می‌شوند. ادامه می‌دهید؟",
            confirmLabel = "پاک کردن",
            onConfirm = { confirmClear = false; state.clearHistory() },
            onDismiss = { confirmClear = false }
        )
    }
}

@Composable
private fun HistoryCard(item: HistoryItem, onCopy: () -> Unit, onDelete: () -> Unit) {
    val encode = item.type == HistoryType.ENCODE
    GlassPanel(padding = 14.dp) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TypeBadge(encode)
            Spacer(Modifier.weight(1f))
            IconActionButton(
                Icons.Rounded.ContentCopy,
                if (encode) "کپی پیام ایموجی" else "کپی متن اصلی",
                onCopy, tint = TextSecondary
            )
            IconActionButton(Icons.Rounded.Delete, "حذف این مورد", onDelete, tint = TextSecondary)
        }
        Text(
            item.text, color = TextPrimary, fontSize = 17.sp, lineHeight = 26.sp,
            maxLines = 2, overflow = TextOverflow.Ellipsis,
            style = TextStyle(textDirection = TextDirection.Content, textAlign = TextAlign.Start),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(6.dp))
        Text(
            item.emojis, fontSize = 18.sp, letterSpacing = 3.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            style = TextStyle(textDirection = TextDirection.Ltr, textAlign = TextAlign.Start),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(6.dp))
        Box(Modifier.fillMaxWidth()) {
            Text(formatTimestamp(item.timestamp), color = TextMuted, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterEnd))
        }
    }
}

@Composable
private fun TypeBadge(encode: Boolean) {
    val accent = if (encode) Color(0xFF7DB4F0) else Color(0xFF7CD1AC)
    val shape = RoundedCornerShape(10.dp)
    Text(
        if (encode) "رمزگذاری" else "ترجمه",
        color = accent, fontSize = 12.sp, fontWeight = FontWeight.Medium,
        modifier = Modifier.background(accent.copy(alpha = 0.14f), shape)
            .border(1.dp, accent.copy(alpha = 0.35f), shape)
            .padding(horizontal = 12.dp, vertical = 4.dp)
    )
}
