package com.emojicipher.app.ui

import com.emojicipher.app.codec.EmojiCodec
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Persian user-facing messages for codec errors. */
fun encodeErrorText(e: EmojiCodec.EncodeError): String = when (e) {
    EmojiCodec.EncodeError.EMPTY -> "لطفاً ابتدا متن پیام را بنویسید."
    EmojiCodec.EncodeError.TOO_LONG -> "متن بیش از حد طولانی است. حداکثر ${EmojiCodec.MAX_MESSAGE_CODE_POINTS} نویسه مجاز است."
    EmojiCodec.EncodeError.INVALID_TEXT -> "متن شامل نویسه‌ی نامعتبر است و قابل تبدیل نیست."
}

fun decodeErrorText(e: EmojiCodec.DecodeError): String = when (e) {
    EmojiCodec.DecodeError.Empty -> "لطفاً پیام ایموجی را وارد کنید."
    is EmojiCodec.DecodeError.UnknownSymbol -> "در پیام نمادی وجود دارد که متعلق به این برنامه نیست. پیام را دوباره و کامل کپی کنید."
    EmojiCodec.DecodeError.Truncated -> "پیام ناقص است. ظاهراً بخشی از آن کپی نشده یا حذف شده است."
    EmojiCodec.DecodeError.NotACipherMessage -> "این پیام با «رمزگذاری پیام» ساخته نشده است."
    is EmojiCodec.DecodeError.UnsupportedVersion -> "این پیام با نسخه‌ی دیگری از برنامه ساخته شده است. برنامه را به‌روزرسانی کنید."
    EmojiCodec.DecodeError.Corrupted -> "پیام آسیب دیده است (بررسی صحت ناموفق بود). ممکن است برنامه‌ی پیام‌رسان آن را تغییر داده باشد."
    EmojiCodec.DecodeError.InvalidText -> "محتوای پیام قابل خواندن نیست."
    EmojiCodec.DecodeError.TooLong -> "پیام بیش از حد طولانی است."
}

/** Keeps at most [max] Unicode code points. */
fun limitCodePoints(s: String, max: Int): String =
    if (s.codePointCount(0, s.length) <= max) s else s.substring(0, s.offsetByCodePoints(0, max))

fun codePoints(s: String): Int = s.codePointCount(0, s.length)

/** "14:32 · امروز" / "دیروز" / Persian-calendar date. */
fun formatTimestamp(ts: Long): String {
    val time = SimpleDateFormat("HH:mm", Locale.US).format(Date(ts))
    val now = Calendar.getInstance()
    val then = Calendar.getInstance().apply { timeInMillis = ts }
    fun sameDay(a: Calendar, b: Calendar) =
        a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)
    val yesterday = (now.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, -1) }
    val day = when {
        sameDay(now, then) -> "امروز"
        sameDay(yesterday, then) -> "دیروز"
        else -> persianDate(ts)
    }
    return "$time · $day"
}

private fun persianDate(ts: Long): String = try {
    val locale = android.icu.util.ULocale("fa_IR@calendar=persian;numbers=latn")
    android.icu.text.SimpleDateFormat("yyyy/MM/dd", locale).format(Date(ts))
} catch (e: Throwable) {
    SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(ts))
}
