package com.emojicipher.app.ui.theme

import androidx.compose.ui.graphics.Color

val Navy = Color(0xFF0A1422)
val GlassTint = Color(0xFF22344A)
val GlassTintDeep = Color(0xFF111C2B)
val TextPrimary = Color(0xFFF4F7FB)
val TextSecondary = Color(0xFFB4C0CF)
val TextMuted = Color(0xFF8795A8)
val AccentBlueTop = Color(0xFF5B9BE0)
val AccentBlueBottom = Color(0xFF2F68B0)
val ButtonTop = Color(0xFF5F7E9D)
val ButtonBottom = Color(0xFF32506C)
val ErrorSoft = Color(0xFFFFB4AB)
val ToggleOn = Color(0xFF4C8DF0)
