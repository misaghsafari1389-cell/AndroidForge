package com.emojicipher.app.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.emojicipher.app.AppState
import com.emojicipher.app.R
import com.emojicipher.app.ui.components.AppBackground
import com.emojicipher.app.ui.components.Backdrop
import com.emojicipher.app.ui.components.FloatingNav
import com.emojicipher.app.ui.components.GlassToast
import com.emojicipher.app.ui.components.LocalBackdrop
import com.emojicipher.app.ui.components.animatedDim
import com.emojicipher.app.ui.screens.DecodeScreen
import com.emojicipher.app.ui.screens.EncodeScreen
import com.emojicipher.app.ui.screens.HistoryScreen
import com.emojicipher.app.ui.screens.HomeScreen
import com.emojicipher.app.ui.screens.SettingsScreen
import com.emojicipher.app.ui.screens.WelcomeScreen
import kotlinx.coroutines.delay

object Routes {
    const val WELCOME = "welcome"
    const val HOME = "home"
    const val HISTORY = "history"
    const val SETTINGS = "settings"
    const val ENCODE = "encode"
    const val DECODE = "decode"
    val TABS = setOf(HOME, HISTORY, SETTINGS)
}

@Composable
fun EmojiCipherApp(state: AppState) {
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val startDestination = remember { if (state.onboardingDone) Routes.HOME else Routes.WELCOME }

    val sharp = ImageBitmap.imageResource(R.drawable.bg_landscape)
    val blurred = ImageBitmap.imageResource(R.drawable.bg_blur)
    val dim = animatedDim(if (route == Routes.WELCOME) 0.10f else 0.58f)

    // Auto-hide the confirmation pill.
    val toast = state.toast
    LaunchedEffect(toast?.id) {
        if (toast != null) {
            delay(1800)
            if (state.toast?.id == toast.id) state.toast = null
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val density = LocalDensity.current
        val widthPx = with(density) { maxWidth.toPx() }
        val heightPx = with(density) { maxHeight.toPx() }
        val backdrop = remember(sharp, blurred, widthPx, heightPx) { Backdrop(sharp, blurred, widthPx, heightPx, dim) }

        CompositionLocalProvider(LocalBackdrop provides backdrop) {
            AppBackground(backdrop)

            NavHost(
                navController = navController,
                startDestination = startDestination,
                modifier = Modifier.fillMaxSize(),
                enterTransition = { fadeIn(tween(220)) },
                exitTransition = { fadeOut(tween(160)) },
                popEnterTransition = { fadeIn(tween(220)) },
                popExitTransition = { fadeOut(tween(160)) }
            ) {
                composable(Routes.WELCOME) {
                    WelcomeScreen(onStart = {
                        state.completeOnboarding()
                        navController.navigate(Routes.HOME) {
                            popUpTo(navController.graph.id) { inclusive = true }
                            launchSingleTop = true
                        }
                    })
                }
                composable(Routes.HOME) {
                    HomeScreen(
                        onEncode = { navController.navigate(Routes.ENCODE) },
                        onDecode = { navController.navigate(Routes.DECODE) },
                        onSettings = { navController.selectTab(Routes.SETTINGS) }
                    )
                }
                composable(Routes.HISTORY) { HistoryScreen(state) }
                composable(Routes.SETTINGS) {
                    SettingsScreen(state, onShowWelcome = { navController.navigate(Routes.WELCOME) })
                }
                composable(Routes.ENCODE) { EncodeScreen(state, onBack = { navController.popBackStack() }) }
                composable(Routes.DECODE) { DecodeScreen(state, onBack = { navController.popBackStack() }) }
            }

            val onTab = route in Routes.TABS
            if (onTab) {
                FloatingNav(
                    current = route ?: Routes.HOME,
                    onSelect = { navController.selectTab(it) },
                    modifier = Modifier.align(Alignment.BottomCenter)
                )
            }
            GlassToast(
                message = toast?.text,
                modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding()
                    .padding(bottom = if (onTab) 112.dp else 28.dp)
            )
        }
    }
}

private fun androidx.navigation.NavController.selectTab(target: String) {
    if (currentDestination?.route == target) return
    if (target == Routes.HOME) {
        if (!popBackStack(Routes.HOME, inclusive = false)) navigate(Routes.HOME) { launchSingleTop = true }
    } else {
        navigate(target) {
            popUpTo(Routes.HOME) { inclusive = false }
            launchSingleTop = true
        }
    }
}
