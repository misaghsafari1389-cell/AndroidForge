package com.emojicipher.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.emojicipher.app.ui.components.AppEmblem
import com.emojicipher.app.ui.components.ButtonStyle
import com.emojicipher.app.ui.components.GlassButton
import com.emojicipher.app.ui.theme.TextPrimary
import com.emojicipher.app.ui.theme.TextSecondary

@Composable
fun WelcomeScreen(onStart: () -> Unit) {
    val shadow = Shadow(Color.Black.copy(alpha = 0.45f), Offset(0f, 2f), 12f)
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.weight(0.8f))
        AppEmblem(size = 112.dp)
        Spacer(Modifier.height(28.dp))
        Text(
            "رمزگذاری پیام", color = TextPrimary, fontSize = 32.sp, fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center, style = TextStyle(shadow = shadow)
        )
        Spacer(Modifier.height(4.dp))
        Text(
            "با ایموجی", color = TextPrimary.copy(alpha = 0.92f), fontSize = 22.sp, fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center, style = TextStyle(shadow = shadow)
        )
        Spacer(Modifier.height(24.dp))
        Text(
            "پیام‌های خود را به ایموجی تبدیل کنید و دوباره رمزگشایی کنید.",
            color = TextSecondary, fontSize = 15.sp, lineHeight = 26.sp, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
        )
        Spacer(Modifier.weight(1f))
        GlassButton(
            text = "شروع", icon = Icons.Rounded.ArrowForward, onClick = onStart,
            modifier = Modifier.fillMaxWidth(), style = ButtonStyle.Welcome, iconAfterText = true, height = 56.dp
        )
        Spacer(Modifier.height(28.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("سریع", color = TextSecondary, fontSize = 13.sp)
            Text("•", color = TextSecondary, fontSize = 13.sp)
            Text("ساده", color = TextSecondary, fontSize = 13.sp)
            Text("•", color = TextSecondary, fontSize = 13.sp)
            Text("آفلاین", color = TextSecondary, fontSize = 13.sp)
        }
        Spacer(Modifier.height(20.dp))
    }
}
