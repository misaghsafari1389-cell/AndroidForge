package com.emojicipher.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

@Composable
fun EmojiCipherTheme(content: @Composable () -> Unit) {
    val context = LocalContext.current
    val family = remember { loadAppFontFamily(context) }
    val typography = remember(family) { appTypography(family) }
    val scheme = darkColorScheme(
        primary = AccentBlueTop,
        onPrimary = TextPrimary,
        background = Navy,
        onBackground = TextPrimary,
        surface = GlassTintDeep,
        onSurface = TextPrimary,
        error = ErrorSoft
    )
    // The whole app is right-to-left (Persian).
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = scheme, typography = typography, content = content)
    }
}
