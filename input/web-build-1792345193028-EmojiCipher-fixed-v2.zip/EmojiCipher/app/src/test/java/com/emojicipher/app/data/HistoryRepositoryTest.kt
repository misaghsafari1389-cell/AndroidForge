package com.emojicipher.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

private class FakeStore : KeyValueStore {
    val strings = HashMap<String, String>()
    val bools = HashMap<String, Boolean>()
    override fun getString(key: String): String? = strings[key]
    override fun putString(key: String, value: String) { strings[key] = value }
    override fun getBoolean(key: String, default: Boolean): Boolean = bools[key] ?: default
    override fun putBoolean(key: String, value: Boolean) { bools[key] = value }
}

class HistoryRepositoryTest {

    // ---- 15 app restart with history enabled ----
    @Test fun historySurvivesRestartWhenEnabled() {
        val store = FakeStore()
        val first = HistoryRepository(store)
        assertTrue(first.historyEnabled)
        first.add(HistoryType.ENCODE, "سلام داداش خوبی؟", "🚀🌁")
        first.add(HistoryType.DECODE, "Good night\nline2", "🌙⭐")

        val afterRestart = HistoryRepository(store) // new instance, same storage
        val items = afterRestart.load()
        assertEquals(2, items.size)
        assertEquals("Good night\nline2", items[0].text) // newest first
        assertEquals(HistoryType.DECODE, items[0].type)
        assertEquals("سلام داداش خوبی؟", items[1].text)
        assertEquals("🚀🌁", items[1].emojis)
    }

    // ---- 16 app restart with history disabled ----
    @Test fun nothingIsSavedWhenDisabledAndSettingSurvivesRestart() {
        val store = FakeStore()
        val first = HistoryRepository(store)
        first.historyEnabled = false
        first.add(HistoryType.ENCODE, "secret", "🚀")
        assertTrue(first.load().isEmpty())

        val afterRestart = HistoryRepository(store)
        assertFalse(afterRestart.historyEnabled)
        afterRestart.add(HistoryType.ENCODE, "still secret", "🚀")
        assertTrue(afterRestart.load().isEmpty())
        assertTrue(store.strings["history_json"] == null || store.strings["history_json"] == "[]")
    }

    @Test fun disablingHistoryKeepsExistingItemsUntilCleared() {
        val store = FakeStore()
        val repo = HistoryRepository(store)
        repo.add(HistoryType.ENCODE, "a", "🚀")
        repo.historyEnabled = false
        assertEquals(1, repo.load().size)
        repo.clear()
        assertTrue(HistoryRepository(store).load().isEmpty())
    }

    @Test fun deleteRemovesOnlyThatItem() {
        val repo = HistoryRepository(FakeStore())
        repo.add(HistoryType.ENCODE, "one", "🚀")
        repo.add(HistoryType.ENCODE, "two", "🚀")
        val items = repo.load()
        val remaining = repo.delete(items[0].id)
        assertEquals(1, remaining.size)
        assertEquals("one", remaining[0].text)
    }

    @Test fun historyIsCapped() {
        val repo = HistoryRepository(FakeStore(), maxItems = 5)
        repeat(12) { repo.add(HistoryType.ENCODE, "m$it", "🚀") }
        val items = repo.load()
        assertEquals(5, items.size)
        assertEquals("m11", items.first().text)
    }

    @Test fun corruptedStorageDoesNotCrash() {
        val store = FakeStore()
        store.putString("history_json", "{not json")
        assertTrue(HistoryRepository(store).load().isEmpty())
    }

    @Test fun onboardingFlagPersists() {
        val store = FakeStore()
        assertFalse(HistoryRepository(store).onboardingDone)
        HistoryRepository(store).onboardingDone = true
        assertTrue(HistoryRepository(store).onboardingDone)
    }
}
