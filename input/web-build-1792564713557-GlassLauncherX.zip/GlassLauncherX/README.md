# GlassLauncherX (گلس لانچر)

Native Android launcher (Kotlin + Jetpack Compose), Persian RTL by default, English optional.
Same project layout as TacticalLauncherX (single `app` module, `AppState` in SharedPreferences,
one file per screen, GitHub Actions debug-APK workflow).

Design: white "liquid glass" surfaces (translucent gradient + bright rim light), iOS-style squircle icons
and floating dock, with Xiaomi/POCO behaviour (app drawer, categories, hidden vault via double swipe).

## Features
- Home: glass clock card, pinned apps, search pill, glass dock. Swipe up (or tap search) opens the drawer.
- Drawer (POCO style): all apps A-Z + search. One swipe right = categories (social, games, media, productivity, other).
  **Second swipe right within 3 s = pattern screen -> vault.** Swipe left goes back.
- Vault (app-private storage, FLAG_SECURE, auto-closes when you leave the app):
  photos, videos, documents (picked from storage, copied in; original deleted when the file provider allows it),
  and hidden apps (removed from home + drawer; toggle them back here).
  First time you open it you set a pattern (stored only as a salted SHA-256 hash). 5 wrong tries = 30 s lock.
- Settings: white/dark glass, glass strength, icon size, columns, labels, wallpaper from gallery (+blur on Android 12+),
  **icon packs read from the phone** (ADW/Nova/GO/Apex standard: `appfilter.xml`), change pattern (needs old pattern),
  set as default launcher, language fa/en.
- Long-press any app: pin to home, add to dock, hide (vault), app info.

## Icon packs
Install any normal icon pack from the store, then Settings -> Icon pack -> pick it. Apps the pack does not cover
fall back to the iOS-style tile. The pack list uses `<queries>` entries in the manifest (Android 11+ package visibility).

## Build
- AGP 8.5.2, Kotlin 1.9.24, Gradle 8.9, JDK 17, minSdk 26, targetSdk 34
- `gradle assembleDebug` -> `app/build/outputs/apk/debug/app-debug.apk`
- GitHub: push to `main`, the workflow `Build debug APK` uploads the APK. Vazirmatn font via `scripts/download_fonts.sh` (optional).
- No INTERNET permission is requested.

## Known limits (honest list)
- Vault files are in app-private storage but **not encrypted yet** (next step: AES-GCM with an Android Keystore key).
- Pattern only (no fingerprint yet; BiometricPrompt can be added).
- "Hide" removes apps from this launcher only; other launchers still show them.
- Glass is drawn with gradients and rim light (no live backdrop blur of other apps; Android cannot do that for a launcher).
- Not compiled in the authoring environment, see BUILD_STATUS.txt.
