package com.glasslauncher.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.view.WindowCompat

// ---------------------------------------------------------------- palettes (white glass / dark glass)

data class GlColors(
    val dark: Boolean,
    val bgTop: Color, val bgBottom: Color, val glow1: Color, val glow2: Color,
    val glassHi: Color, val glassLo: Color, val rim: Color, val scrim: Color, val sheet: Color,
    val text: Color, val sub: Color, val accent: Color, val onAccent: Color,
    val danger: Color, val dialog: Color
)

val LightGl = GlColors(
    dark = false,
    bgTop = Color(0xFFDCE8FF), bgBottom = Color(0xFFF6E3F2),
    glow1 = Color(0xFF8DBBFF), glow2 = Color(0xFFFFB8D4),
    glassHi = Color(0xA6FFFFFF), glassLo = Color(0x4DFFFFFF), rim = Color(0xF2FFFFFF),
    scrim = Color(0x33FFFFFF), sheet = Color(0xD9F3F6FB),
    text = Color(0xFF10141A), sub = Color(0xFF59626F), accent = Color(0xFF0A84FF), onAccent = Color.White,
    danger = Color(0xFFFF3B30), dialog = Color(0xFFF7F8FB)
)

val DarkGl = GlColors(
    dark = true,
    bgTop = Color(0xFF0B1220), bgBottom = Color(0xFF1B1033),
    glow1 = Color(0xFF2B5BD7), glow2 = Color(0xFF9B3FCB),
    glassHi = Color(0x3DFFFFFF), glassLo = Color(0x14FFFFFF), rim = Color(0x73FFFFFF),
    scrim = Color(0x40000000), sheet = Color(0xE60B0F18),
    text = Color(0xFFF2F5FA), sub = Color(0xFFA7B0BE), accent = Color(0xFF4DA3FF), onAccent = Color(0xFF04101F),
    danger = Color(0xFFFF6B60), dialog = Color(0xFF1A2130)
)

val LocalColors = staticCompositionLocalOf { LightGl }
val LocalLang = staticCompositionLocalOf { "fa" }
val LocalGlass = staticCompositionLocalOf { 1f }

@Composable
fun tr(fa: String, en: String): String = if (LocalLang.current == "fa") fa else en

@Composable
fun nf(n: Int): String = if (LocalLang.current == "fa") faDigits(n.toString()) else n.toString()

// ---------------------------------------------------------------- font + theme

fun loadAppFontFamily(context: Context): FontFamily {
    val files = try { context.assets.list("fonts")?.toSet() ?: emptySet() } catch (e: Exception) { emptySet() }
    val fonts = buildList<Font> {
        if ("Vazirmatn-Regular.ttf" in files) add(Font("fonts/Vazirmatn-Regular.ttf", context.assets, FontWeight.Normal))
        if ("Vazirmatn-Medium.ttf" in files) add(Font("fonts/Vazirmatn-Medium.ttf", context.assets, FontWeight.Medium))
        if ("Vazirmatn-Bold.ttf" in files) add(Font("fonts/Vazirmatn-Bold.ttf", context.assets, FontWeight.Bold))
    }
    return if (fonts.isEmpty()) FontFamily.SansSerif else FontFamily(fonts)
}

/** Persian is a joining script, so letter spacing must stay at 0. */
fun appTypography(family: FontFamily): Typography {
    fun TextStyle.fix() = copy(fontFamily = family, letterSpacing = 0.sp, lineHeight = (fontSize.value * 1.5f).sp)
    val d = Typography()
    return Typography(
        displayLarge = d.displayLarge.fix(), displayMedium = d.displayMedium.fix(), displaySmall = d.displaySmall.fix(),
        headlineLarge = d.headlineLarge.fix(), headlineMedium = d.headlineMedium.fix(), headlineSmall = d.headlineSmall.fix(),
        titleLarge = d.titleLarge.fix(), titleMedium = d.titleMedium.fix(), titleSmall = d.titleSmall.fix(),
        bodyLarge = d.bodyLarge.fix(), bodyMedium = d.bodyMedium.fix(), bodySmall = d.bodySmall.fix(),
        labelLarge = d.labelLarge.fix(), labelMedium = d.labelMedium.fix(), labelSmall = d.labelSmall.fix()
    )
}

@Composable
fun GlTheme(state: AppState, content: @Composable () -> Unit) {
    val c = if (state.themeIndex == 1) DarkGl else LightGl
    val fa = state.lang == "fa"
    val ctx = LocalContext.current
    val family = remember { loadAppFontFamily(ctx) }
    val scheme = if (c.dark) {
        darkColorScheme(primary = c.accent, onPrimary = c.onAccent, background = c.bgTop, onBackground = c.text, surface = c.dialog, onSurface = c.text)
    } else {
        lightColorScheme(primary = c.accent, onPrimary = c.onAccent, background = c.bgTop, onBackground = c.text, surface = c.dialog, onSurface = c.text)
    }
    val view = LocalView.current
    SideEffect {
        val w = (view.context as? Activity)?.window
        if (w != null) {
            val ctrl = WindowCompat.getInsetsController(w, view)
            ctrl.isAppearanceLightStatusBars = !c.dark
            ctrl.isAppearanceLightNavigationBars = !c.dark
        }
    }
    CompositionLocalProvider(
        LocalColors provides c,
        LocalLang provides state.lang,
        LocalGlass provides state.glass,
        LocalLayoutDirection provides (if (fa) LayoutDirection.Rtl else LayoutDirection.Ltr),
        LocalContentColor provides c.text
    ) {
        MaterialTheme(colorScheme = scheme, typography = appTypography(family), content = content)
    }
}

// ---------------------------------------------------------------- glass building blocks

/** Frosted "white glass" surface: translucent gradient fill + bright rim light. */
@Composable
fun Modifier.glass(corner: Dp = 24.dp): Modifier {
    val c = LocalColors.current
    val k = LocalGlass.current
    val shape = RoundedCornerShape(corner)
    val hi = c.glassHi.copy(alpha = (c.glassHi.alpha * k).coerceIn(0.05f, 0.95f))
    val lo = c.glassLo.copy(alpha = (c.glassLo.alpha * k).coerceIn(0.03f, 0.9f))
    return this
        .clip(shape)
        .background(Brush.verticalGradient(listOf(hi, lo)))
        .border(1.dp, Brush.verticalGradient(listOf(c.rim, c.rim.copy(alpha = 0.15f))), shape)
}

/** Swallows taps so layers stacked above the home screen do not click through. */
@Composable
fun Modifier.blockTouches(): Modifier =
    this.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = {})

@Composable
fun Backdrop(state: AppState, modifier: Modifier = Modifier) {
    val c = LocalColors.current
    val wp = state.wallpaper
    Box(modifier.background(Brush.verticalGradient(listOf(c.bgTop, c.bgBottom)))) {
        if (wp != null) {
            val m = if (state.wallBlur) Modifier.fillMaxSize().blur(18.dp) else Modifier.fillMaxSize()
            Image(bitmap = wp, contentDescription = null, contentScale = ContentScale.Crop, modifier = m)
            Box(Modifier.fillMaxSize().background(c.scrim))
        } else {
            Canvas(Modifier.fillMaxSize()) {
                val r = this.size.width * 0.95f
                drawRect(Brush.radialGradient(listOf(c.glow1.copy(alpha = 0.55f), Color.Transparent), center = Offset(this.size.width * 0.15f, this.size.height * 0.2f), radius = r))
                drawRect(Brush.radialGradient(listOf(c.glow2.copy(alpha = 0.55f), Color.Transparent), center = Offset(this.size.width * 0.9f, this.size.height * 0.78f), radius = r))
            }
        }
    }
}

@Composable
fun GlassChip(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val c = LocalColors.current
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier
            .clip(shape)
            .background(if (selected) c.accent else Color.Transparent)
            .border(1.dp, if (selected) c.accent else c.rim.copy(alpha = 0.5f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (selected) c.onAccent else c.text, fontSize = 13.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal, maxLines = 1)
    }
}

@Composable
fun GlassField(value: String, onValueChange: (String) -> Unit, placeholder: String, modifier: Modifier = Modifier) {
    val c = LocalColors.current
    Row(modifier.glass(22.dp).padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Outlined.Search, contentDescription = null, tint = c.sub, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Box(Modifier.weight(1f)) {
            if (value.isEmpty()) Text(placeholder, color = c.sub, fontSize = 14.sp)
            BasicTextField(
                value = value, onValueChange = onValueChange, singleLine = true,
                textStyle = TextStyle(color = c.text, fontSize = 14.sp),
                cursorBrush = SolidColor(c.accent), modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

// ---------------------------------------------------------------- app icons (iOS style squircle)

@Composable
fun AppIconView(app: AppEntry, state: AppState, size: Dp) {
    val shape = RoundedCornerShape(percent = 24)
    val bmp = remember(app.pkg, app.cls, state.iconVersion) { state.iconFor(app) }
    Image(
        bitmap = bmp, contentDescription = null,
        modifier = Modifier
            .size(size)
            .shadow(5.dp, shape, clip = false, ambientColor = Color(0x22000000), spotColor = Color(0x33000000))
            .clip(shape)
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppTile(app: AppEntry, state: AppState, modifier: Modifier = Modifier, onClick: () -> Unit, onLong: () -> Unit) {
    val c = LocalColors.current
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).combinedClickable(onClick = onClick, onLongClick = onLong).padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AppIconView(app, state, state.iconSize.dp)
        if (state.showLabels) {
            Spacer(Modifier.height(5.dp))
            Text(app.label, color = c.text, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 2.dp))
        }
    }
}

@Composable
private fun MenuRow(text: String, color: Color? = null, onClick: () -> Unit) {
    val c = LocalColors.current
    Text(
        text, color = color ?: c.text, fontSize = 15.sp,
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp)
    )
}

/** Long-press menu for an app: pin to home, dock, hide (vault), app info. */
@Composable
fun AppMenu(app: AppEntry, state: AppState, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val c = LocalColors.current
    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.clip(RoundedCornerShape(26.dp)).background(c.dialog).padding(10.dp)) {
            Text(app.label, color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
            val pinned = app.pkg in state.pinned
            val docked = app.pkg in state.dock
            MenuRow(if (pinned) tr("برداشتن از صفحه‌ی اصلی", "Unpin from home") else tr("افزودن به صفحه‌ی اصلی", "Pin to home")) { state.togglePin(app.pkg); onDismiss() }
            MenuRow(if (docked) tr("برداشتن از داک", "Remove from dock") else tr("افزودن به داک", "Add to dock")) { state.toggleDock(app.pkg); onDismiss() }
            MenuRow(tr("مخفی کردن (در گاوصندوق)", "Hide (in vault)")) { state.setHidden(app.pkg, true); onDismiss() }
            MenuRow(tr("اطلاعات برنامه", "App info")) {
                try {
                    ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + app.pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) { }
                onDismiss()
            }
        }
    }
}
