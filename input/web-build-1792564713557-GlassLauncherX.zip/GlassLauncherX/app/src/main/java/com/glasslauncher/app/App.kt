package com.glasslauncher.app

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class Route { Home, Drawer, Settings, Lock, Vault }

@Composable
fun GlApp(state: AppState) {
    val ctx = LocalContext.current
    var route by remember { mutableStateOf(Route.Home) }
    var lockMode by remember { mutableIntStateOf(0) }

    // (re)load the installed-apps list at start and whenever the launcher returns to the foreground
    LaunchedEffect(state.resumeTick) {
        state.updateApps(withContext(Dispatchers.Default) { loadLauncherApps(ctx) })
    }
    // leaving the app (or pressing Home) closes the vault and returns to the home screen
    LaunchedEffect(state.lockTick) {
        if (route == Route.Vault || route == Route.Lock) route = Route.Home
    }
    LaunchedEffect(state.homeTick) {
        if (state.homeTick > 0) route = Route.Home
    }
    BackHandler(enabled = route == Route.Drawer || route == Route.Settings) { route = Route.Home }

    Box(Modifier.fillMaxSize()) {
        Backdrop(state, Modifier.fillMaxSize())
        HomeScreen(state, openDrawer = { route = Route.Drawer }, openSettings = { route = Route.Settings })
        AnimatedVisibility(
            visible = route == Route.Drawer,
            enter = slideInVertically(tween(260)) { it / 3 } + fadeIn(tween(260)),
            exit = slideOutVertically(tween(200)) { it / 3 } + fadeOut(tween(200))
        ) {
            DrawerScreen(state, onBack = { route = Route.Home }, onVault = { lockMode = 0; route = Route.Lock })
        }
        AnimatedVisibility(visible = route == Route.Settings, enter = fadeIn(tween(180)), exit = fadeOut(tween(150))) {
            SettingsScreen(state, onBack = { route = Route.Home }, onChangePattern = { lockMode = 1; route = Route.Lock })
        }
        if (route == Route.Lock) {
            PatternGate(
                state, lockMode,
                onSuccess = { route = if (lockMode == 1) Route.Settings else Route.Vault },
                onCancel = { route = if (lockMode == 1) Route.Settings else Route.Drawer }
            )
        }
        if (route == Route.Vault) {
            VaultScreen(state, onClose = { route = Route.Drawer })
        }
    }
}
