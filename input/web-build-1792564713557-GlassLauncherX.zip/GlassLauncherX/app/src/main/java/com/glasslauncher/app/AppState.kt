package com.glasslauncher.app

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class AppEntry(val label: String, val pkg: String, val cls: String, val cat: Int)

/** kind: 0 = photo, 1 = video, 2 = document. */
data class VaultItem(val id: String, val kind: Int, val name: String, val mime: String, val file: String, val added: Long)

/** Drawer category groups: 0 social, 1 games, 2 media, 3 productivity, 4 other. */
fun categoryOf(cat: Int): Int = when (cat) {
    ApplicationInfo.CATEGORY_SOCIAL -> 0
    ApplicationInfo.CATEGORY_GAME -> 1
    ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO, ApplicationInfo.CATEGORY_IMAGE -> 2
    ApplicationInfo.CATEGORY_PRODUCTIVITY, ApplicationInfo.CATEGORY_NEWS, ApplicationInfo.CATEGORY_MAPS -> 3
    else -> 4
}

fun loadLauncherApps(ctx: Context): List<AppEntry> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map {
            val cat = try { it.activityInfo.applicationInfo.category } catch (e: Exception) { ApplicationInfo.CATEGORY_UNDEFINED }
            AppEntry(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.activityInfo.name, cat)
        }
        .sortedBy { it.label.lowercase() }
}

fun launchApp(ctx: Context, app: AppEntry) {
    try {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(ComponentName(app.pkg, app.cls))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        ctx.startActivity(i)
    } catch (e: Exception) { }
}

/** All data lives in SharedPreferences and the app's private storage. Nothing is sent anywhere. */
class AppState(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("glx_prefs", Context.MODE_PRIVATE)

    // ---- settings ----
    var themeIndex by mutableIntStateOf(prefs.getInt("theme", 0)); private set
    var lang by mutableStateOf(prefs.getString("lang", "fa") ?: "fa"); private set
    var glass by mutableFloatStateOf(prefs.getFloat("glass", 1f)); private set
    var iconSize by mutableIntStateOf(prefs.getInt("icon", 58)); private set
    var columns by mutableIntStateOf(prefs.getInt("cols", 4)); private set
    var showLabels by mutableStateOf(prefs.getBoolean("labels", true)); private set
    var wallBlur by mutableStateOf(prefs.getBoolean("wblur", false)); private set
    var iconPackPkg by mutableStateOf(prefs.getString("pack", "") ?: ""); private set
    var iconVersion by mutableIntStateOf(0); private set
    var wallpaper by mutableStateOf<ImageBitmap?>(null); private set

    // ---- data ----
    var apps by mutableStateOf<List<AppEntry>>(emptyList()); private set
    var packs by mutableStateOf<List<IconPackInfo>>(emptyList()); private set
    val pinned = mutableStateListOf<String>()
    val dock = mutableStateListOf<String>()
    val hidden = mutableStateListOf<String>()
    val vault = mutableStateListOf<VaultItem>()
    var patternHash by mutableStateOf<String?>(prefs.getString("pat", null)); private set

    // ---- lifecycle signals (MainActivity -> UI) ----
    var lockTick by mutableIntStateOf(0); private set
    var resumeTick by mutableIntStateOf(0)
    var homeTick by mutableIntStateOf(0)
    @Volatile var suppressLock = false

    private val cache = HashMap<String, ImageBitmap>()
    private var pack: IconPack? = null

    init {
        loadList("pinned", pinned)
        loadList("dock", dock)
        loadList("hidden", hidden)
        loadVault()
        if (iconPackPkg.isNotEmpty()) pack = try { IconPack(ctx, iconPackPkg) } catch (e: Exception) { null }
        val f = File(ctx.filesDir, "wall.img")
        if (f.exists()) wallpaper = decodeSampled(f.path, 1600)?.asImageBitmap()
    }

    // ---- simple settings ----
    fun changeTheme(i: Int) { themeIndex = i; prefs.edit().putInt("theme", i).apply() }
    fun changeLang(l: String) { lang = l; prefs.edit().putString("lang", l).apply() }
    fun changeGlass(v: Float) { glass = v; prefs.edit().putFloat("glass", v).apply() }
    fun changeIconSize(v: Int) { iconSize = v; prefs.edit().putInt("icon", v).apply() }
    fun changeColumns(v: Int) { columns = v; prefs.edit().putInt("cols", v).apply() }
    fun changeLabels(v: Boolean) { showLabels = v; prefs.edit().putBoolean("labels", v).apply() }
    fun changeWallBlur(v: Boolean) { wallBlur = v; prefs.edit().putBoolean("wblur", v).apply() }
    fun requestLock() { if (!suppressLock) lockTick++ }

    // ---- apps ----
    val visibleApps: List<AppEntry> get() = apps.filter { it.pkg !in hidden }

    fun updateApps(list: List<AppEntry>) {
        apps = list
        if (!prefs.contains("dock")) seedDock()
    }

    private fun seedDock() {
        val want = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        val list = ArrayList<String>()
        for (i in want) {
            val p = try { ctx.packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName } catch (e: Exception) { null }
            if (p != null && apps.any { it.pkg == p } && p !in list) list.add(p)
        }
        dock.clear(); dock.addAll(list); saveList("dock", dock)
    }

    fun togglePin(pkg: String) { if (pkg in pinned) pinned.remove(pkg) else pinned.add(pkg); saveList("pinned", pinned) }
    fun toggleDock(pkg: String) {
        if (pkg in dock) dock.remove(pkg) else if (dock.size < 5) dock.add(pkg)
        saveList("dock", dock)
    }
    fun setHidden(pkg: String, v: Boolean) {
        if (v && pkg !in hidden) hidden.add(pkg)
        if (!v) hidden.remove(pkg)
        saveList("hidden", hidden)
    }

    private fun loadList(key: String, into: MutableList<String>) {
        into.clear()
        (prefs.getString(key, "") ?: "").split("\n").filter { it.isNotBlank() }.forEach { into.add(it) }
    }
    private fun saveList(key: String, l: List<String>) { prefs.edit().putString(key, l.joinToString("\n")).apply() }

    // ---- icons / icon packs ----
    fun refreshPacks() { packs = findIconPacks(ctx) }

    fun setIconPack(pkg: String) {
        iconPackPkg = pkg
        prefs.edit().putString("pack", pkg).apply()
        pack = if (pkg.isEmpty()) null else try { IconPack(ctx, pkg) } catch (e: Exception) { null }
        cache.clear()
        iconVersion++
    }

    fun iconFor(app: AppEntry): ImageBitmap {
        val key = app.pkg + "/" + app.cls
        cache[key]?.let { return it }
        val px = 192
        var bmp: Bitmap? = null
        try {
            val cn = ComponentName(app.pkg, app.cls)
            val d = pack?.iconFor(cn)
            bmp = if (d != null) d.toBitmap(px, px) else iosIcon(ctx.packageManager.getActivityIcon(cn), px)
        } catch (e: Exception) { }
        val out = (bmp ?: Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)).asImageBitmap()
        cache[key] = out
        return out
    }

    // ---- wallpaper ----
    suspend fun setWallpaper(uri: Uri) = withContext(Dispatchers.IO) {
        try {
            val f = File(ctx.filesDir, "wall.img")
            ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            wallpaper = decodeSampled(f.path, 1600)?.asImageBitmap()
        } catch (e: Exception) { }
    }

    fun clearWallpaper() { File(ctx.filesDir, "wall.img").delete(); wallpaper = null }

    // ---- vault pattern (stored only as a salted hash) ----
    private fun hashOf(p: String) = sha256Hex("glx::" + p)
    fun setPattern(p: String) { patternHash = hashOf(p); prefs.edit().putString("pat", patternHash).apply() }
    fun clearPattern() { patternHash = null; prefs.edit().remove("pat").apply() }
    fun checkPattern(p: String): Boolean = patternHash != null && patternHash == hashOf(p)

    // ---- vault files (copied into app-private storage) ----
    private fun vaultDir(): File = File(ctx.filesDir, "vault").apply { mkdirs() }
    fun vaultFile(it: VaultItem): File = File(vaultDir(), it.file)

    private fun queryName(u: Uri): String? = try {
        ctx.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (e: Exception) { null }

    /** Copies picked files into the vault. Returns (imported, originalsDeleted). */
    suspend fun importUris(uris: List<Uri>, kind: Int): Pair<Int, Int> = withContext(Dispatchers.IO) {
        var ok = 0
        var del = 0
        val added = ArrayList<VaultItem>()
        for (u in uris) {
            try {
                val name = queryName(u) ?: "file"
                val mime = ctx.contentResolver.getType(u) ?: "*/*"
                val id = UUID.randomUUID().toString()
                val fname = id + "_" + name.replace(Regex("[^A-Za-z0-9._-]"), "_")
                val out = File(vaultDir(), fname)
                val input = ctx.contentResolver.openInputStream(u) ?: continue
                input.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
                added.add(VaultItem(id, kind, name, mime, fname, System.currentTimeMillis()))
                ok++
                try { if (DocumentsContract.deleteDocument(ctx.contentResolver, u)) del++ } catch (e: Exception) { }
            } catch (e: Exception) { }
        }
        vault.addAll(0, added)
        persistVault()
        Pair(ok, del)
    }

    fun removeVault(item: VaultItem) {
        vaultFile(item).delete()
        vault.removeAll { it.id == item.id }
        persistVault()
    }

    private fun persistVault() {
        val arr = JSONArray()
        for (v in vault) {
            arr.put(JSONObject().put("id", v.id).put("k", v.kind).put("n", v.name).put("m", v.mime).put("f", v.file).put("t", v.added))
        }
        prefs.edit().putString("vault", arr.toString()).apply()
    }

    private fun loadVault() {
        vault.clear()
        try {
            val arr = JSONArray(prefs.getString("vault", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                vault.add(VaultItem(o.getString("id"), o.getInt("k"), o.getString("n"), o.getString("m"), o.getString("f"), o.getLong("t")))
            }
        } catch (e: Exception) { }
    }
}
