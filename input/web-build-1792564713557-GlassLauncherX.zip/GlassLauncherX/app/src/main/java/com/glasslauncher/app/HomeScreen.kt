package com.glasslauncher.app

import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(state: AppState, openDrawer: () -> Unit, openSettings: () -> Unit) {
    val ctx = LocalContext.current
    val c = LocalColors.current
    val fa = state.lang == "fa"
    var menuApp by remember { mutableStateOf<AppEntry?>(null) }
    val now by produceState(System.currentTimeMillis()) {
        while (true) { value = System.currentTimeMillis(); delay(15_000L) }
    }
    val timeStr = remember(now, fa) {
        val s = SimpleDateFormat("HH:mm", Locale.US).format(Date(now))
        if (fa) faDigits(s) else s
    }
    val dateStr = remember(now, fa) { CalUtil.fmtLong(fa, CalUtil.today()) }
    val vis = state.visibleApps
    val pinnedApps = state.pinned.mapNotNull { p -> vis.firstOrNull { it.pkg == p } }
    val dockApps = state.dock.mapNotNull { p -> vis.firstOrNull { it.pkg == p } }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
            .pointerInput(Unit) {
                var t = 0f
                detectVerticalDragGestures(
                    onDragStart = { t = 0f },
                    onDragEnd = { if (t < -120f) openDrawer() },
                    onVerticalDrag = { _, dy -> t += dy }
                )
            }
            .padding(horizontal = 18.dp)
    ) {
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth().glass(30.dp).padding(horizontal = 22.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(timeStr, color = c.text, fontSize = 52.sp, fontWeight = FontWeight.Light)
                Text(dateStr, color = c.sub, fontSize = 14.sp)
            }
            IconButton(onClick = openSettings) {
                Icon(Icons.Outlined.Settings, contentDescription = null, tint = c.text)
            }
        }
        Spacer(Modifier.height(22.dp))
        if (pinnedApps.isEmpty()) {
            Text(
                tr("برای افزودن برنامه، آن را در منو نگه دارید", "Long-press an app in the drawer to pin it here"),
                color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 6.dp)
            )
        } else {
            pinnedApps.chunked(state.columns).forEach { row ->
                Row(Modifier.fillMaxWidth()) {
                    row.forEach { a ->
                        AppTile(a, state, Modifier.weight(1f), onClick = { launchApp(ctx, a) }, onLong = { menuApp = a })
                    }
                    repeat(state.columns - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
        Spacer(Modifier.weight(1f))
        Row(
            Modifier.fillMaxWidth().glass(22.dp).clickable { openDrawer() }.padding(horizontal = 16.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Outlined.Search, contentDescription = null, tint = c.sub, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(tr("جستجو یا بکشید بالا", "Search or swipe up"), color = c.sub, fontSize = 14.sp)
        }
        Spacer(Modifier.height(12.dp))
        Row(
            Modifier.fillMaxWidth().glass(34.dp).padding(horizontal = 14.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically
        ) {
            if (dockApps.isEmpty()) {
                Text(tr("داک خالی است", "Dock is empty"), color = c.sub, fontSize = 13.sp)
            }
            dockApps.forEach { a ->
                AppTile(a, state, Modifier, onClick = { launchApp(ctx, a) }, onLong = { menuApp = a })
            }
        }
        Spacer(Modifier.height(10.dp))
    }
    menuApp?.let { AppMenu(it, state) { menuApp = null } }
}
