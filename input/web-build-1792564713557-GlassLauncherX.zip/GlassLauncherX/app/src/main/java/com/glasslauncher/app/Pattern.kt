package com.glasslauncher.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private fun padCenter(i: Int, w: Float, h: Float) = Offset(w * (i % 3 * 2 + 1) / 6f, h * (i / 3 * 2 + 1) / 6f)

/** 3x3 pattern pad. Calls onDone with the dot sequence, e.g. "01258". */
@Composable
fun PatternPad(onDone: (String) -> Unit, modifier: Modifier = Modifier, side: Dp = 260.dp) {
    val c = LocalColors.current
    var box by remember { mutableStateOf(IntSize.Zero) }
    val sel = remember { mutableStateListOf<Int>() }
    var cur by remember { mutableStateOf<Offset?>(null) }
    val done by rememberUpdatedState(onDone)

    fun hit(p: Offset) {
        for (i in 0..8) {
            if (i !in sel && (padCenter(i, box.width.toFloat(), box.height.toFloat()) - p).getDistance() < box.width / 8f) {
                sel.add(i)
                break
            }
        }
    }

    Canvas(
        modifier.size(side).onSizeChanged { box = it }.pointerInput(Unit) {
            detectDragGestures(
                onDragStart = { o -> sel.clear(); cur = o; hit(o) },
                onDrag = { change, _ -> cur = change.position; hit(change.position) },
                onDragEnd = { val s = sel.joinToString(""); cur = null; sel.clear(); if (s.isNotEmpty()) done(s) },
                onDragCancel = { sel.clear(); cur = null }
            )
        }
    ) {
        val w = this.size.width
        val h = this.size.height
        for (k in 1 until sel.size) {
            drawLine(c.accent, padCenter(sel[k - 1], w, h), padCenter(sel[k], w, h), strokeWidth = 7f, cap = StrokeCap.Round)
        }
        val last = sel.lastOrNull()
        val pos = cur
        if (last != null && pos != null) drawLine(c.accent, padCenter(last, w, h), pos, strokeWidth = 7f, cap = StrokeCap.Round)
        for (i in 0..8) {
            val ctr = padCenter(i, w, h)
            val on = i in sel
            drawCircle(if (on) c.accent else c.sub.copy(alpha = 0.55f), radius = if (on) w / 22f else w / 30f, center = ctr)
            if (on) drawCircle(c.accent.copy(alpha = 0.25f), radius = w / 11f, center = ctr)
        }
    }
}

/**
 * Pattern screen. First run: set a pattern (draw twice). Later: verify.
 * mode 1 = "change pattern": verify the old pattern first, then set a new one.
 */
@Composable
fun PatternGate(state: AppState, mode: Int, onSuccess: () -> Unit, onCancel: () -> Unit) {
    val c = LocalColors.current
    val setup = state.patternHash == null
    var first by remember { mutableStateOf<String?>(null) }
    var msg by remember { mutableStateOf("") }
    var fails by remember { mutableIntStateOf(0) }
    var lockUntil by remember { mutableLongStateOf(0L) }
    val sShort = tr("حداقل ۴ نقطه را وصل کنید", "Connect at least 4 dots")
    val sRepeat = tr("برای تأیید دوباره بکشید", "Draw again to confirm")
    val sMismatch = tr("یکسان نبود، دوباره از اول", "Did not match, start again")
    val sWrong = tr("الگو اشتباه است", "Wrong pattern")
    val sLocked = tr("۳۰ ثانیه صبر کنید", "Wait 30 seconds")
    val title = if (setup) tr("الگوی گاوصندوق را تعیین کنید", "Set your vault pattern")
    else if (mode == 1) tr("الگوی فعلی را بکشید", "Draw your current pattern")
    else tr("الگو را بکشید", "Draw your pattern")
    BackHandler { onCancel() }
    Column(
        Modifier.fillMaxSize().blockTouches().background(c.sheet).statusBarsPadding().navigationBarsPadding().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Outlined.Lock, contentDescription = null, tint = c.accent, modifier = Modifier.size(34.dp))
        Spacer(Modifier.height(14.dp))
        Text(title, color = c.text, fontSize = 18.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text(msg, color = c.sub, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.height(20.dp))
        Spacer(Modifier.height(24.dp))
        PatternPad(onDone = { p ->
            val now = System.currentTimeMillis()
            if (now < lockUntil) {
                msg = sLocked
            } else if (p.length < 4) {
                msg = sShort
            } else if (setup) {
                val f = first
                if (f == null) { first = p; msg = sRepeat }
                else if (f == p) { state.setPattern(p); onSuccess() }
                else { first = null; msg = sMismatch }
            } else if (state.checkPattern(p)) {
                if (mode == 1) { state.clearPattern(); msg = "" } else onSuccess()
            } else {
                fails++
                if (fails >= 5) { lockUntil = now + 30_000L; fails = 0; msg = sLocked } else msg = sWrong
            }
        })
    }
}
