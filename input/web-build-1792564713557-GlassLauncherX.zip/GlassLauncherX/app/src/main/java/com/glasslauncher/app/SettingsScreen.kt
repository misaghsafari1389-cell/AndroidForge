package com.glasslauncher.app

import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    val c = LocalColors.current
    Text(title, color = c.sub, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 8.dp, top = 16.dp, bottom = 6.dp))
    Column(Modifier.fillMaxWidth().glass(24.dp).padding(14.dp), content = content)
}

@Composable
private fun SwitchRow(text: String, value: Boolean, onChange: (Boolean) -> Unit) {
    val c = LocalColors.current
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, color = c.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Switch(checked = value, onCheckedChange = onChange)
    }
}

@Composable
private fun SliderRow(text: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    val c = LocalColors.current
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(text, color = c.text, fontSize = 15.sp)
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

@Composable
private fun ActionRow(text: String, onClick: () -> Unit) {
    val c = LocalColors.current
    Text(text, color = c.accent, fontSize = 15.sp, modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 10.dp))
}

@Composable
private fun PackRow(text: String, selected: Boolean, onClick: () -> Unit) {
    val c = LocalColors.current
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, color = c.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        if (selected) Icon(Icons.Outlined.Check, contentDescription = null, tint = c.accent)
    }
}

@Composable
fun SettingsScreen(state: AppState, onBack: () -> Unit, onChangePattern: () -> Unit) {
    val ctx = LocalContext.current
    val c = LocalColors.current
    val scope = rememberCoroutineScope()
    val wallPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) scope.launch { state.setWallpaper(u) }
    }
    LaunchedEffect(Unit) { state.refreshPacks() }
    BackHandler { onBack() }

    Column(Modifier.fillMaxSize().blockTouches().background(c.sheet).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(tr("تنظیمات", "Settings"), color = c.text, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onClick = onBack) { Icon(Icons.Outlined.Close, contentDescription = null, tint = c.text) }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 14.dp).padding(bottom = 24.dp)) {
            Section(tr("ظاهر", "Appearance")) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassChip(tr("شیشه‌ی سفید", "White glass"), state.themeIndex == 0) { state.changeTheme(0) }
                    GlassChip(tr("شیشه‌ی تیره", "Dark glass"), state.themeIndex == 1) { state.changeTheme(1) }
                }
                SliderRow(tr("شفافیت شیشه", "Glass strength"), state.glass, 0.5f..1.5f) { state.changeGlass(it) }
                SliderRow(tr("اندازه‌ی آیکون", "Icon size"), state.iconSize.toFloat(), 44f..72f) { state.changeIconSize(it.toInt()) }
                Text(tr("تعداد ستون", "Columns"), color = c.text, fontSize = 15.sp, modifier = Modifier.padding(top = 4.dp, bottom = 6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (n in 4..6) GlassChip(nf(n), state.columns == n) { state.changeColumns(n) }
                }
                SwitchRow(tr("نام زیر آیکون", "Show labels"), state.showLabels) { state.changeLabels(it) }
            }
            Section(tr("والپیپر", "Wallpaper")) {
                ActionRow(tr("انتخاب عکس از گالری", "Pick from gallery")) { wallPicker.launch("image/*") }
                ActionRow(tr("بازگشت به پس‌زمینه‌ی پیش‌فرض", "Reset to default")) { state.clearWallpaper() }
                SwitchRow(tr("محو کردن والپیپر (اندروید ۱۲+)", "Blur wallpaper (Android 12+)"), state.wallBlur) { state.changeWallBlur(it) }
            }
            Section(tr("آیکون‌پک", "Icon pack")) {
                PackRow(tr("پیش‌فرض (سبک iOS)", "Default (iOS style)"), state.iconPackPkg.isEmpty()) { state.setIconPack("") }
                state.packs.forEach { p -> PackRow(p.label, state.iconPackPkg == p.pkg) { state.setIconPack(p.pkg) } }
                if (state.packs.isEmpty()) {
                    Text(
                        tr("آیکون‌پک‌های نصب‌شده روی گوشی اینجا نمایش داده می‌شوند. یک آیکون‌پک نصب کنید و دوباره باز کنید.",
                            "Icon packs installed on this phone appear here. Install one and reopen this screen."),
                        color = c.sub, fontSize = 13.sp
                    )
                }
                ActionRow(tr("بازخوانی لیست", "Refresh list")) { state.refreshPacks() }
            }
            Section(tr("گاوصندوق", "Vault")) {
                ActionRow(tr("تغییر الگو", "Change pattern")) { onChangePattern() }
            }
            Section(tr("سیستم", "System")) {
                ActionRow(tr("انتخاب به‌عنوان لانچر پیش‌فرض", "Set as default launcher")) {
                    try { ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                    GlassChip("فارسی", state.lang == "fa") { state.changeLang("fa") }
                    GlassChip("English", state.lang == "en") { state.changeLang("en") }
                }
            }
        }
    }
}
