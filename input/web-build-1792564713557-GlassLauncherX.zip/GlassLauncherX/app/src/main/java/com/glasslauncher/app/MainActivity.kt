package com.glasslauncher.app

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge

class MainActivity : ComponentActivity() {
    private lateinit var state: AppState

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        state = AppState(applicationContext)
        setContent { GlTheme(state) { GlApp(state) } }
    }

    override fun onResume() {
        super.onResume()
        state.suppressLock = false
        state.resumeTick++
    }

    override fun onStop() {
        super.onStop()
        state.requestLock()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Home button pressed while the launcher is already running
        state.homeTick++
    }
}
