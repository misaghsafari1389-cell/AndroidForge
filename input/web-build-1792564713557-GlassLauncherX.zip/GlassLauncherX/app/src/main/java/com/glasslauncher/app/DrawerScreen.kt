package com.glasslauncher.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * App drawer (POCO style): all apps A-Z. One swipe to the right shows categories;
 * a second swipe to the right (within 3 seconds) opens the hidden vault pattern screen.
 */
@Composable
fun DrawerScreen(state: AppState, onBack: () -> Unit, onVault: () -> Unit) {
    val ctx = LocalContext.current
    val c = LocalColors.current
    var q by remember { mutableStateOf("") }
    var page by remember { mutableIntStateOf(0) }
    var lastRight by remember { mutableLongStateOf(0L) }
    var menuApp by remember { mutableStateOf<AppEntry?>(null) }
    val vaultCb by rememberUpdatedState(onVault)
    BackHandler { onBack() }

    val list = state.visibleApps.let { all -> if (q.isBlank()) all else all.filter { it.label.contains(q.trim(), true) } }
    val groupNames = listOf(
        tr("اجتماعی", "Social"), tr("بازی", "Games"), tr("رسانه", "Media"),
        tr("بهره‌وری", "Productivity"), tr("سایر", "Other")
    )

    Column(
        Modifier.fillMaxSize().blockTouches().background(c.sheet).statusBarsPadding()
            .pointerInput(Unit) {
                var total = 0f
                detectHorizontalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = {
                        if (total > 110f) {
                            val t = System.currentTimeMillis()
                            if (page == 1 && t - lastRight < 3000L) {
                                lastRight = 0L
                                page = 0
                                vaultCb()
                            } else {
                                page = 1
                                lastRight = t
                            }
                        } else if (total < -110f) {
                            page = 0
                            lastRight = 0L
                        }
                    },
                    onHorizontalDrag = { _, dx -> total += dx }
                )
            }
    ) {
        Spacer(Modifier.height(10.dp))
        GlassField(q, { q = it }, tr("جستجوی برنامه...", "Search apps..."), Modifier.fillMaxWidth().padding(horizontal = 16.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(state.columns),
            modifier = Modifier.weight(1f).padding(horizontal = 14.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            if (page == 0 || q.isNotBlank()) {
                items(list, key = { it.pkg + "/" + it.cls }) { a ->
                    AppTile(a, state, Modifier, onClick = { launchApp(ctx, a) }, onLong = { menuApp = a })
                }
            } else {
                for (g in 0..4) {
                    val gl = list.filter { categoryOf(it.cat) == g }
                    if (gl.isNotEmpty()) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            Text(groupNames[g], color = c.sub, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 6.dp, top = 12.dp, bottom = 4.dp))
                        }
                        items(gl, key = { it.pkg + "/" + it.cls }) { a ->
                            AppTile(a, state, Modifier, onClick = { launchApp(ctx, a) }, onLong = { menuApp = a })
                        }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(bottom = 10.dp), horizontalArrangement = Arrangement.Center) {
            for (i in 0..1) {
                Box(Modifier.padding(horizontal = 3.dp).size(7.dp).clip(CircleShape).background(if (i == page) c.text else c.sub.copy(alpha = 0.4f)))
            }
        }
    }
    menuApp?.let { AppMenu(it, state) { menuApp = null } }
}
