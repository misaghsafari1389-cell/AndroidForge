package com.glasslauncher.app

import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.SecureFlagPolicy
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

fun openVaultItem(ctx: Context, state: AppState, item: VaultItem) {
    try {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", state.vaultFile(item))
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, item.mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        state.suppressLock = true
        ctx.startActivity(i)
    } catch (e: Exception) {
        state.suppressLock = false
        Toast.makeText(ctx, "No app can open this file", Toast.LENGTH_SHORT).show()
    }
}

private fun loadThumb(state: AppState, item: VaultItem): ImageBitmap? {
    val f = state.vaultFile(item)
    return try {
        when (item.kind) {
            0 -> decodeSampled(f.path, 320)?.asImageBitmap()
            1 -> {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(f.path)
                    r.getFrameAtTime(0)?.asImageBitmap()
                } finally {
                    r.release()
                }
            }
            else -> null
        }
    } catch (e: Exception) { null }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun VaultScreen(state: AppState, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val c = LocalColors.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var viewing by remember { mutableStateOf<VaultItem?>(null) }
    var deleting by remember { mutableStateOf<VaultItem?>(null) }
    var pendingKind by remember { mutableIntStateOf(0) }
    val tHidden = tr("فایل مخفی شد", "file(s) hidden")
    val tNote = tr("اگر نسخه‌ی اصلی هنوز در گالری است، خودتان پاکش کنید.", "If the original is still in your gallery, delete it there.")
    val tabs = listOf(tr("عکس", "Photos"), tr("فیلم", "Videos"), tr("سند", "Docs"), tr("برنامه", "Apps"))

    // Block screenshots and the recents preview while the vault is open.
    DisposableEffect(Unit) {
        val w = ctx.findActivity()?.window
        w?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { w?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        state.suppressLock = false
        if (uris.isNotEmpty()) {
            scope.launch {
                val r = state.importUris(uris, pendingKind)
                val extra = if (r.second < r.first) "\n" + tNote else ""
                Toast.makeText(ctx, "${r.first} $tHidden$extra", Toast.LENGTH_LONG).show()
            }
        }
    }

    Column(Modifier.fillMaxSize().blockTouches().background(c.sheet).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(tr("گاوصندوق", "Vault"), color = c.text, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onClick = onClose) { Icon(Icons.Outlined.Close, contentDescription = null, tint = c.text) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            tabs.forEachIndexed { i, t -> GlassChip(t, tab == i, Modifier.weight(1f)) { tab = i } }
        }
        Spacer(Modifier.height(10.dp))
        if (tab == 3) {
            LazyColumn(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                items(state.apps, key = { it.pkg + "/" + it.cls }) { a ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        AppIconView(a, state, 40.dp)
                        Spacer(Modifier.width(12.dp))
                        Text(a.label, color = c.text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        Switch(checked = a.pkg in state.hidden, onCheckedChange = { state.setHidden(a.pkg, it) })
                    }
                }
            }
        } else {
            val shown = state.vault.filter { it.kind == tab }
            val mimes = when (tab) { 0 -> arrayOf("image/*"); 1 -> arrayOf("video/*"); else -> arrayOf("*/*") }
            LazyVerticalGrid(
                columns = GridCells.Fixed(3), modifier = Modifier.weight(1f).padding(horizontal = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Button(
                        onClick = { pendingKind = tab; state.suppressLock = true; picker.launch(mimes) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(tr("افزودن به گاوصندوق", "Add to vault")) }
                }
                if (shown.isEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Text(tr("اینجا خالی است", "Nothing here yet"), color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(8.dp))
                    }
                }
                items(shown, key = { it.id }) { v ->
                    val thumb by produceState<ImageBitmap?>(null, v.id) { value = withContext(Dispatchers.IO) { loadThumb(state, v) } }
                    Box(
                        Modifier.aspectRatio(1f).clip(RoundedCornerShape(16.dp)).glass(16.dp)
                            .combinedClickable(
                                onClick = { if (v.kind == 0) viewing = v else openVaultItem(ctx, state, v) },
                                onLongClick = { deleting = v }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        val t = thumb
                        if (t != null) Image(bitmap = t, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        if (v.kind == 1) Icon(Icons.Outlined.PlayCircle, contentDescription = null, tint = Color.White, modifier = Modifier.size(34.dp))
                        if (v.kind == 2) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(6.dp)) {
                                Icon(Icons.Outlined.Description, contentDescription = null, tint = c.accent, modifier = Modifier.size(32.dp))
                                Text(v.name, color = c.text, fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        }
    }

    viewing?.let { v ->
        Dialog(
            onDismissRequest = { viewing = null },
            properties = DialogProperties(usePlatformDefaultWidth = false, securePolicy = SecureFlagPolicy.SecureOn)
        ) {
            val big by produceState<ImageBitmap?>(null, v.id) {
                value = withContext(Dispatchers.IO) { decodeSampled(state.vaultFile(v).path, 1600)?.asImageBitmap() }
            }
            Box(Modifier.fillMaxSize().background(Color.Black).clickable { viewing = null }, contentAlignment = Alignment.Center) {
                val b = big
                if (b != null) Image(bitmap = b, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
            }
        }
    }

    deleting?.let { v ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text(tr("حذف از گاوصندوق؟", "Delete from vault?")) },
            text = { Text(v.name) },
            confirmButton = { TextButton(onClick = { state.removeVault(v); deleting = null }) { Text(tr("حذف", "Delete"), color = c.danger) } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text(tr("انصراف", "Cancel")) } }
        )
    }
}
