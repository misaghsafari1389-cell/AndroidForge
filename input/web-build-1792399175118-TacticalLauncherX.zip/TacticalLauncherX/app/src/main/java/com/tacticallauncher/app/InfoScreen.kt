package com.tacticallauncher.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import kotlinx.coroutines.launch
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun catName(i: Int): String = when (i) {
    0 -> tr("سیاسی", "Political")
    1 -> tr("نظامی", "Military")
    2 -> tr("اقتصادی", "Economic")
    else -> tr("فرهنگی", "Cultural")
}

fun catIcon(i: Int): ImageVector = when (i) {
    0 -> Icons.Outlined.Public
    1 -> Icons.Outlined.Shield
    2 -> Icons.Outlined.Payments
    else -> Icons.Outlined.Palette
}

fun catColor(i: Int): Color = when (i) {
    0 -> Color(0xFF5B8DEF)
    1 -> Color(0xFF6FBF73)
    2 -> Color(0xFFE5A93B)
    else -> Color(0xFFB07CE8)
}

private fun openLink(ctx: Context, url: String) {
    if (!(url.startsWith("https://") || url.startsWith("http://"))) return
    try {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (e: Exception) { }
}

@Composable
fun InfoScreen(state: AppState, go: (Route) -> Unit) {
    val c = LocalColors.current
    val fa = LocalLang.current == "fa"
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var filter by remember { mutableIntStateOf(-1) }
    var showAdd by remember { mutableStateOf(false) }
    var showFeeds by remember { mutableStateOf(false) }
    var detail by remember { mutableStateOf<InfoItem?>(null) }
    val now = System.currentTimeMillis()
    val list = if (filter < 0) state.infos.toList() else state.infos.filter { it.category == filter }

    LaunchedEffect(tab) {
        if (tab == 1 && (state.news.isEmpty() || System.currentTimeMillis() - state.newsUpdated > 600000L)) {
            state.refreshNews()
        }
    }

    Column(Modifier.fillMaxSize()) {
        TopBar(tr("اطلاعات", "Information")) {
            if (tab == 0) {
                IconBtn(Icons.Outlined.Place) { go(Route.Map) }
                IconBtn(Icons.Outlined.Add) { showAdd = true }
            } else {
                IconBtn(Icons.Outlined.Refresh) { scope.launch { state.refreshNews() } }
                IconBtn(Icons.Outlined.Tune) { showFeeds = true }
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            GlassChip(tr("اطلاعات من", "My items"), tab == 0, Modifier.weight(1f)) { tab = 0 }
            GlassChip(tr("اخبار زنده", "Live news"), tab == 1, Modifier.weight(1f)) { tab = 1 }
        }
        Spacer(Modifier.height(8.dp))

        if (tab == 0) {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                GlassChip(tr("همه", "All"), filter < 0) { filter = -1 }
                for (i in 0..3) {
                    GlassChip(catName(i), filter == i) { filter = i }
                }
            }
            LazyColumn(
                Modifier.weight(1f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (list.isEmpty()) {
                    item {
                        EmptyState(Icons.Outlined.Visibility, tr("موردی ثبت نشده. با دکمه‌ی + اطلاعات خودتان را اضافه کنید.", "Nothing here yet. Use + to add your own items."))
                    }
                }
                items(list, key = { it.id }) { info ->
                    GlassCard(Modifier.fillMaxWidth(), padding = 10.dp, onClick = { detail = info }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(68.dp).clip(RoundedCornerShape(14.dp))
                                    .background(Brush.verticalGradient(listOf(catColor(info.category).copy(alpha = 0.55f), catColor(info.category).copy(alpha = 0.15f)))),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(catIcon(info.category), contentDescription = null, tint = c.text, modifier = Modifier.size(30.dp))
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(info.title, color = c.text, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(info.summary, color = c.sub, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Spacer(Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(catName(info.category), color = catColor(info.category), fontSize = 11.sp)
                                    Text("  ·  " + relTime(fa, info.created, now), color = c.sub, fontSize = 11.sp)
                                    if (info.sample) {
                                        Text("  ·  " + tr("نمونه", "Sample"), color = c.warn, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                Modifier.weight(1f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (state.newsLoading) {
                            CircularProgressIndicator(color = c.accent, strokeWidth = 2.dp, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(tr("در حال دریافت...", "Loading..."), color = c.sub, fontSize = 12.sp)
                        } else if (state.newsUpdated > 0L) {
                            Text(tr("آخرین بروزرسانی: ", "Last update: ") + relTime(fa, state.newsUpdated, now), color = c.sub, fontSize = 12.sp)
                        }
                        Spacer(Modifier.weight(1f))
                        Text(nf(state.feeds.size) + tr(" منبع", " sources"), color = c.sub, fontSize = 12.sp)
                    }
                }
                if (state.news.isEmpty() && !state.newsLoading) {
                    item {
                        EmptyState(Icons.Outlined.Public, tr("خبری دریافت نشد. اینترنت را بررسی کنید یا منبع‌ها را از دکمه‌ی بالا تغییر دهید.", "No news loaded. Check your internet or edit the sources with the button above."))
                    }
                }
                items(state.news.toList(), key = { it.link }) { n ->
                    GlassCard(Modifier.fillMaxWidth(), onClick = { openLink(ctx, n.link) }) {
                        Text(n.title, color = c.text, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        if (n.snippet.isNotBlank()) {
                            Spacer(Modifier.height(4.dp))
                            Text(n.snippet, color = c.sub, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                        Spacer(Modifier.height(6.dp))
                        Row {
                            Text(n.source, color = c.accent, fontSize = 11.sp)
                            if (n.time > 0L) {
                                Text("  ·  " + relTime(fa, n.time, now), color = c.sub, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAdd) {
        AddInfoDialog(onDismiss = { showAdd = false }, onSave = { t, s, cat ->
            state.addInfo(t, s, cat)
            showAdd = false
        })
    }
    if (showFeeds) {
        FeedsDialog(state, onDismiss = { showFeeds = false }, onChanged = { scope.launch { state.refreshNews() } })
    }
    val d = detail
    if (d != null) {
        TlxDialog(
            title = d.title,
            onDismiss = { detail = null },
            confirmText = tr("حذف", "Delete"),
            onConfirm = { state.deleteInfo(d.id); detail = null },
            dismissText = tr("بستن", "Close")
        ) {
            Text(catName(d.category), color = catColor(d.category), fontSize = 13.sp)
            Text(d.summary, color = c.text, fontSize = 14.sp)
            Text(CalUtil.fmt(fa, d.created / 86400000L), color = c.sub, fontSize = 12.sp)
        }
    }
}

@Composable
private fun FeedsDialog(state: AppState, onDismiss: () -> Unit, onChanged: () -> Unit) {
    val c = LocalColors.current
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("https://") }
    TlxDialog(
        title = tr("منابع خبری (RSS)", "News sources (RSS)"),
        onDismiss = onDismiss,
        confirmText = tr("افزودن", "Add"),
        onConfirm = {
            if (url.trim().startsWith("https://") && url.trim().length > 10) {
                state.addFeed(name, url)
                name = ""
                url = "https://"
                onChanged()
            }
        },
        dismissText = tr("بستن", "Close")
    ) {
        Column(
            Modifier.heightIn(max = 220.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            for (f in state.feeds.toList()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(f.name, color = c.text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        Text(f.url, color = c.sub, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    IconBtn(Icons.Outlined.Delete, c.sub) { state.removeFeed(f.url) }
                }
            }
        }
        GlassField(name, { name = it }, tr("نام منبع", "Source name"), Modifier.fillMaxWidth())
        GlassField(url, { url = it }, "https://.../rss.xml", Modifier.fillMaxWidth())
        TextButton(onClick = { state.resetFeeds(); onChanged() }) {
            Text(tr("بازگشت به منابع پیش‌فرض", "Reset to default sources"), color = c.sub)
        }
    }
}

@Composable
private fun AddInfoDialog(onDismiss: () -> Unit, onSave: (String, String, Int) -> Unit) {
    var title by remember { mutableStateOf("") }
    var summary by remember { mutableStateOf("") }
    var cat by remember { mutableIntStateOf(0) }
    TlxDialog(
        title = tr("افزودن اطلاعات", "Add information"),
        onDismiss = onDismiss,
        confirmText = tr("ذخیره", "Save"),
        onConfirm = { if (title.isNotBlank()) onSave(title.trim(), summary.trim(), cat) },
        dismissText = tr("انصراف", "Cancel")
    ) {
        GlassField(title, { title = it }, tr("عنوان", "Title"), Modifier.fillMaxWidth())
        GlassField(summary, { summary = it }, tr("خلاصه", "Summary"), Modifier.fillMaxWidth(), singleLine = false, minLines = 3)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (i in 0..3) {
                GlassChip(catName(i), cat == i) { cat = i }
            }
        }
    }
}
