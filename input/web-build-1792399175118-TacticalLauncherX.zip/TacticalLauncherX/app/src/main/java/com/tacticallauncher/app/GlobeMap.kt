package com.tacticallauncher.app

import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.horizontalScroll
import androidx.compose.ui.viewinterop.AndroidView
import org.json.JSONArray
import org.json.JSONObject
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private fun citiesGeoJson(state: AppState, fa: Boolean): String {
    val colors = arrayOf("#6FCF7A", "#F2C14E", "#EF6B5F")
    val feats = JSONArray()
    for (ct in Cities) {
        val geom = JSONObject().put("type", "Point").put("coordinates", JSONArray().put(ct.lon).put(ct.lat))
        val props = JSONObject().put("name", if (fa) ct.fa else ct.en).put("color", colors[state.regionOf(ct.id) % 3])
        feats.put(JSONObject().put("type", "Feature").put("geometry", geom).put("properties", props))
    }
    return JSONObject().put("type", "FeatureCollection").put("features", feats).toString()
}

/** Free interactive world map: MapLibre GL JS in a WebView, globe projection, OpenFreeMap + EOX satellite + USGS quakes. */
@Composable
fun GlobeTab(state: AppState, modifier: Modifier = Modifier) {
    val c = LocalColors.current
    val fa = LocalLang.current == "fa"
    val ctx = LocalContext.current
    var base by remember { mutableStateOf("sat") }
    var globe by remember { mutableStateOf(true) }
    var quakes by remember { mutableStateOf(true) }
    var tilt by remember { mutableStateOf(false) }
    var ready by remember { mutableStateOf(false) }
    var wv by remember { mutableStateOf<WebView?>(null) }
    val html = remember {
        try { ctx.assets.open("map.html").bufferedReader().use { it.readText() } } catch (e: Exception) { "" }
    }
    val json = citiesGeoJson(state, fa)

    LaunchedEffect(ready, base, globe, quakes, tilt) {
        val w = wv
        if (ready && w != null) {
            w.evaluateJavascript("setBase('$base'); setGlobe($globe); setQuakes($quakes); setTilt($tilt);", null)
        }
    }
    LaunchedEffect(ready, json) {
        val w = wv
        if (ready && w != null) {
            w.evaluateJavascript("setCities(" + JSONObject.quote(json) + ");", null)
        }
    }

    Column(modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            GlassChip(tr("ماهواره", "Satellite"), base == "sat") { base = "sat" }
            GlassChip(tr("نقشه", "Street"), base == "street") { base = "street" }
            GlassChip(tr("گلوب", "Globe"), globe) { globe = !globe }
            GlassChip(tr("سه‌بعدی", "3D tilt"), tilt) { tilt = !tilt }
            GlassChip(tr("زلزله‌های ۲۴ ساعت", "Quakes 24h"), quakes) { quakes = !quakes }
        }
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            GlassChip(tr("جهان", "World"), false) { wv?.evaluateJavascript("flyTo(20, 20, 1.6);", null) }
            for (ct in Cities) {
                GlassChip(cityName(ct), false) { wv?.evaluateJavascript("flyTo(${ct.lon}, ${ct.lat}, 7);", null) }
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(18.dp)).border(1.dp, c.border, RoundedCornerShape(18.dp))) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { context ->
                    val view = WebView(context)
                    view.settings.javaScriptEnabled = true
                    view.settings.domStorageEnabled = true
                    view.setBackgroundColor(android.graphics.Color.parseColor("#06101A"))
                    view.webViewClient = object : WebViewClient() {
                        override fun onPageFinished(v: WebView?, url: String?) {
                            wv = v
                            ready = true
                        }
                    }
                    view.loadDataWithBaseURL("https://appassets.local/", html, "text/html", "utf-8", null)
                    view
                },
                onRelease = { it.destroy() }
            )
        }
        Text(
            tr("نقشه‌ی پایه: OpenFreeMap/OpenStreetMap · ماهواره: Sentinel-2 cloudless (EOX، غیرتجاری) · زلزله: USGS. به اینترنت نیاز دارد.",
                "Basemap: OpenFreeMap/OpenStreetMap · Satellite: Sentinel-2 cloudless (EOX, non-commercial) · Quakes: USGS. Needs internet."),
            color = c.sub, fontSize = 10.sp
        )
    }
}
