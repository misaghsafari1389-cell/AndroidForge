package com.tacticallauncher.app

import android.app.Activity
import android.content.Context
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.view.WindowCompat
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------------------------------------------------------------- palettes

data class TlxColors(
    val dark: Boolean,
    val bgTop: Color, val bgBottom: Color, val glow1: Color, val glow2: Color,
    val cardTop: Color, val card: Color, val border: Color, val field: Color,
    val text: Color, val sub: Color, val accent: Color, val onAccent: Color,
    val ok: Color, val warn: Color, val danger: Color, val dialog: Color
)

val DarkGlass = TlxColors(
    dark = true,
    bgTop = Color(0xFF0B1A2B), bgBottom = Color(0xFF060F18),
    glow1 = Color(0xFF3F6B4F), glow2 = Color(0xFF1D3F63),
    cardTop = Color(0x26FFFFFF), card = Color(0x0FFFFFFF), border = Color(0x2EFFFFFF), field = Color(0x14FFFFFF),
    text = Color(0xFFF1F6F2), sub = Color(0xFFA9B9B2),
    accent = Color(0xFFA3C95A), onAccent = Color(0xFF0B1A12),
    ok = Color(0xFF6FCF7A), warn = Color(0xFFF2C14E), danger = Color(0xFFEF6B5F), dialog = Color(0xFF12243A)
)

val LightGlass = TlxColors(
    dark = false,
    bgTop = Color(0xFFE8F0EE), bgBottom = Color(0xFFC8D6D3),
    glow1 = Color(0xFF9FD0B2), glow2 = Color(0xFFAFC4E6),
    cardTop = Color(0xB3FFFFFF), card = Color(0x80FFFFFF), border = Color(0xCCFFFFFF), field = Color(0x99FFFFFF),
    text = Color(0xFF0F211C), sub = Color(0xFF4B5E59),
    accent = Color(0xFF3E6B2C), onAccent = Color(0xFFFFFFFF),
    ok = Color(0xFF2E9E4F), warn = Color(0xFFC98A00), danger = Color(0xFFD14B3F), dialog = Color(0xFFF3F7F6)
)

val OliveGlass = TlxColors(
    dark = true,
    bgTop = Color(0xFF2B3219), bgBottom = Color(0xFF141908),
    glow1 = Color(0xFF7A8F34), glow2 = Color(0xFF44562B),
    cardTop = Color(0x2EFFFFFF), card = Color(0x12FFFFFF), border = Color(0x33FFFFFF), field = Color(0x18FFFFFF),
    text = Color(0xFFF3F5E6), sub = Color(0xFFB7BF9A),
    accent = Color(0xFFCADB6B), onAccent = Color(0xFF1A2008),
    ok = Color(0xFF8FD16A), warn = Color(0xFFF0C24A), danger = Color(0xFFEA7260), dialog = Color(0xFF2A3318)
)

fun paletteFor(i: Int): TlxColors = when (i) {
    1 -> LightGlass
    2 -> OliveGlass
    else -> DarkGlass
}

val LocalColors = staticCompositionLocalOf { DarkGlass }
val LocalLang = staticCompositionLocalOf { "fa" }

@Composable
fun tr(fa: String, en: String): String = if (LocalLang.current == "fa") fa else en

@Composable
fun nf(s: String): String = if (LocalLang.current == "fa") faDigits(s) else s

@Composable
fun nf(n: Int): String = nf(n.toString())

// ---------------------------------------------------------------- font + theme

/** Loads Vazirmatn from assets/fonts if it was bundled; otherwise falls back to the system font. */
fun loadAppFontFamily(context: Context): FontFamily {
    val files = try { context.assets.list("fonts")?.toSet() ?: emptySet() } catch (e: Exception) { emptySet() }
    val fonts = buildList<Font> {
        if ("Vazirmatn-Regular.ttf" in files) add(Font("fonts/Vazirmatn-Regular.ttf", context.assets, FontWeight.Normal))
        if ("Vazirmatn-Medium.ttf" in files) add(Font("fonts/Vazirmatn-Medium.ttf", context.assets, FontWeight.Medium))
        if ("Vazirmatn-Bold.ttf" in files) add(Font("fonts/Vazirmatn-Bold.ttf", context.assets, FontWeight.Bold))
    }
    return if (fonts.isEmpty()) FontFamily.SansSerif else FontFamily(fonts)
}

/** Persian is a joining script, so letter spacing must stay at 0. */
fun appTypography(family: FontFamily): Typography {
    fun TextStyle.fix() = copy(fontFamily = family, letterSpacing = 0.sp, lineHeight = (fontSize.value * 1.55f).sp)
    val d = Typography()
    return Typography(
        displayLarge = d.displayLarge.fix(), displayMedium = d.displayMedium.fix(), displaySmall = d.displaySmall.fix(),
        headlineLarge = d.headlineLarge.fix(), headlineMedium = d.headlineMedium.fix(), headlineSmall = d.headlineSmall.fix(),
        titleLarge = d.titleLarge.fix(), titleMedium = d.titleMedium.fix(), titleSmall = d.titleSmall.fix(),
        bodyLarge = d.bodyLarge.fix(), bodyMedium = d.bodyMedium.fix(), bodySmall = d.bodySmall.fix(),
        labelLarge = d.labelLarge.fix(), labelMedium = d.labelMedium.fix(), labelSmall = d.labelSmall.fix()
    )
}

@Composable
fun TlxTheme(state: AppState, content: @Composable () -> Unit) {
    val c = paletteFor(state.themeIndex)
    val fa = state.lang == "fa"
    val ctx = LocalContext.current
    val family = remember { loadAppFontFamily(ctx) }
    val scale = when (state.fontIndex) {
        0 -> 0.9f
        2 -> 1.15f
        else -> 1f
    }
    val base = LocalDensity.current
    val scheme = if (c.dark) {
        darkColorScheme(
            primary = c.accent, onPrimary = c.onAccent, secondary = c.accent,
            background = c.bgTop, onBackground = c.text, surface = c.dialog, onSurface = c.text
        )
    } else {
        lightColorScheme(
            primary = c.accent, onPrimary = c.onAccent, secondary = c.accent,
            background = c.bgTop, onBackground = c.text, surface = c.dialog, onSurface = c.text
        )
    }
    val view = LocalView.current
    SideEffect {
        val w = (view.context as? Activity)?.window
        if (w != null) {
            val ctrl = WindowCompat.getInsetsController(w, view)
            ctrl.isAppearanceLightStatusBars = !c.dark
            ctrl.isAppearanceLightNavigationBars = !c.dark
        }
    }
    CompositionLocalProvider(
        LocalColors provides c,
        LocalLang provides state.lang,
        LocalLayoutDirection provides (if (fa) LayoutDirection.Rtl else LayoutDirection.Ltr),
        LocalDensity provides Density(base.density, base.fontScale * scale),
        LocalContentColor provides c.text
    ) {
        MaterialTheme(colorScheme = scheme, typography = appTypography(family), content = content)
    }
}

// ---------------------------------------------------------------- building blocks

@Composable
fun Backdrop(modifier: Modifier = Modifier) {
    val c = LocalColors.current
    Box(modifier.background(Brush.verticalGradient(listOf(c.bgTop, c.bgBottom)))) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.width * 0.9f
            drawRect(
                Brush.radialGradient(
                    listOf(c.glow1.copy(alpha = 0.40f), Color.Transparent),
                    center = Offset(size.width * 0.1f, size.height * 0.18f), radius = r
                )
            )
            drawRect(
                Brush.radialGradient(
                    listOf(c.glow2.copy(alpha = 0.45f), Color.Transparent),
                    center = Offset(size.width * 0.95f, size.height * 0.75f), radius = r
                )
            )
        }
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    corner: Dp = 20.dp,
    padding: Dp = 14.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val c = LocalColors.current
    val shape = RoundedCornerShape(corner)
    val base = modifier
        .clip(shape)
        .background(Brush.verticalGradient(listOf(c.cardTop, c.card)))
        .border(1.dp, c.border, shape)
    val m = if (onClick != null) base.clickable(onClick = onClick) else base
    Column(m.padding(padding), content = content)
}

@Composable
fun IconBtn(icon: ImageVector, tint: Color? = null, onClick: () -> Unit) {
    val c = LocalColors.current
    IconButton(onClick = onClick) {
        Icon(icon, contentDescription = null, tint = tint ?: c.text)
    }
}

@Composable
fun GlassChip(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val c = LocalColors.current
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier
            .clip(shape)
            .background(if (selected) c.accent.copy(alpha = 0.22f) else c.card)
            .border(1.dp, if (selected) c.accent else c.border, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = if (selected) c.accent else c.sub,
            fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            maxLines = 1
        )
    }
}

@Composable
fun GlassField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    singleLine: Boolean = true,
    minLines: Int = 1,
    leading: ImageVector? = null
) {
    val c = LocalColors.current
    val shape = RoundedCornerShape(14.dp)
    Row(
        modifier
            .clip(shape)
            .background(c.field)
            .border(1.dp, c.border, shape)
            .padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (leading != null) {
            Icon(leading, contentDescription = null, tint = c.sub, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
        }
        Box(Modifier.weight(1f)) {
            if (value.isEmpty()) {
                Text(placeholder, color = c.sub, fontSize = 14.sp, maxLines = 1)
            }
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                singleLine = singleLine,
                minLines = minLines,
                textStyle = MaterialTheme.typography.bodyMedium.copy(color = c.text, fontSize = 14.sp),
                cursorBrush = SolidColor(c.accent),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun TopBar(title: String, onBack: (() -> Unit)? = null, actions: @Composable RowScope.() -> Unit = {}) {
    val c = LocalColors.current
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = null, tint = c.text)
            }
        }
        Text(
            title, color = c.text, fontSize = 20.sp, fontWeight = FontWeight.Bold,
            maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f).padding(horizontal = 6.dp)
        )
        actions()
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    val c = LocalColors.current
    Text(text, color = c.sub, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = modifier.padding(top = 6.dp, bottom = 2.dp))
}

@Composable
fun EmptyState(icon: ImageVector, text: String) {
    val c = LocalColors.current
    Column(
        Modifier.fillMaxWidth().padding(vertical = 36.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(icon, contentDescription = null, tint = c.sub, modifier = Modifier.size(40.dp))
        Text(text, color = c.sub, fontSize = 14.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun Bar(fraction: Float, color: Color, modifier: Modifier = Modifier) {
    val c = LocalColors.current
    Box(modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(c.border)) {
        Box(
            Modifier.fillMaxWidth(fraction.coerceIn(0.02f, 1f)).fillMaxHeight()
                .clip(RoundedCornerShape(4.dp)).background(color)
        )
    }
}

@Composable
fun TlxDialog(
    title: String,
    onDismiss: () -> Unit,
    confirmText: String?,
    onConfirm: () -> Unit,
    dismissText: String?,
    content: @Composable ColumnScope.() -> Unit
) {
    val c = LocalColors.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.dialog,
        titleContentColor = c.text,
        textContentColor = c.text,
        title = { Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp) },
        text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp), content = content) },
        confirmButton = {
            if (confirmText != null) {
                TextButton(onClick = onConfirm) { Text(confirmText, color = c.accent, fontWeight = FontWeight.Bold) }
            }
        },
        dismissButton = {
            if (dismissText != null) {
                TextButton(onClick = onDismiss) { Text(dismissText, color = c.sub) }
            }
        }
    )
}

@Composable
fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    val c = LocalColors.current
    val items = listOf(
        Triple(Icons.Outlined.Home, tr("خانه", "Home"), 0),
        Triple(Icons.Outlined.Visibility, tr("اطلاعات", "Info"), 1),
        Triple(Icons.Outlined.Apps, tr("برنامه‌ها", "Apps"), 2),
        Triple(Icons.Outlined.Settings, tr("تنظیمات", "Settings"), 3)
    )
    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 14.dp, vertical = 8.dp)) {
        GlassCard(Modifier.fillMaxWidth(), corner = 26.dp, padding = 6.dp) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                for (item in items) {
                    val sel = item.third == selected
                    Column(
                        Modifier.weight(1f)
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (sel) c.accent.copy(alpha = 0.20f) else Color.Transparent)
                            .clickable { onSelect(item.third) }
                            .padding(vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(item.first, contentDescription = null, tint = if (sel) c.accent else c.sub, modifier = Modifier.size(22.dp))
                        Text(item.second, color = if (sel) c.accent else c.sub, fontSize = 11.sp, maxLines = 1)
                    }
                }
            }
        }
    }
}
