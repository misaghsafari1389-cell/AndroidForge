package com.tacticallauncher.app

import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class City(val id: String, val fa: String, val en: String, val lat: Double, val lon: Double)

val Cities = listOf(
    City("thr", "تهران", "Tehran", 35.6892, 51.3890),
    City("mhd", "مشهد", "Mashhad", 36.2972, 59.6067),
    City("tbz", "تبریز", "Tabriz", 38.0800, 46.2919),
    City("isf", "اصفهان", "Isfahan", 32.6546, 51.6680),
    City("shz", "شیراز", "Shiraz", 29.5918, 52.5837),
    City("ahv", "اهواز", "Ahvaz", 31.3183, 48.6706),
    City("bnd", "بندرعباس", "Bandar Abbas", 27.1865, 56.2808),
    City("zah", "زاهدان", "Zahedan", 29.4963, 60.8629)
)

// Rough outline of Iran (lon, lat). Schematic only: borders are approximate.
private val IranOutline = listOf(
    44.03 to 39.40, 44.78 to 39.72, 45.45 to 39.00, 46.15 to 38.85, 46.55 to 38.90,
    47.40 to 39.10, 48.00 to 38.85, 48.35 to 38.45, 48.88 to 38.43, 49.45 to 37.45,
    50.20 to 37.05, 50.65 to 36.90, 51.55 to 36.72, 52.65 to 36.62, 53.85 to 36.92,
    53.95 to 37.35, 54.80 to 37.45, 55.40 to 38.00, 56.20 to 38.05, 57.30 to 37.65,
    58.30 to 37.60, 59.30 to 37.50, 60.00 to 36.65, 60.65 to 36.60, 61.25 to 36.60,
    60.90 to 35.60, 60.50 to 34.10, 60.90 to 33.50, 60.90 to 31.50, 61.70 to 31.40,
    60.85 to 29.85, 61.80 to 28.00, 62.50 to 28.25, 63.30 to 27.20, 62.80 to 26.35,
    61.60 to 25.20, 60.65 to 25.30, 59.00 to 25.40, 57.75 to 25.65, 57.00 to 27.10,
    56.30 to 27.15, 54.90 to 26.55, 53.50 to 26.85, 52.60 to 27.50, 51.30 to 28.35,
    50.83 to 28.95, 50.15 to 30.20, 49.20 to 30.50, 48.30 to 30.35, 48.00 to 30.00,
    47.70 to 31.00, 47.50 to 32.00, 46.10 to 33.00, 45.80 to 33.80, 45.40 to 34.40,
    46.20 to 35.10, 45.50 to 35.80, 45.10 to 36.40, 44.80 to 37.20, 44.30 to 37.90,
    44.20 to 38.60
)

private const val LON_MIN = 43.0
private const val LON_MAX = 64.0
private const val LAT_MIN = 24.0
private const val LAT_MAX = 40.5

private fun fx(lon: Double): Float = ((lon - LON_MIN) / (LON_MAX - LON_MIN)).toFloat()
private fun fy(lat: Double): Float = ((LAT_MAX - lat) / (LAT_MAX - LAT_MIN)).toFloat()

fun distKm(a: City, b: City): Double {
    val dLat = Math.toRadians(b.lat - a.lat)
    val dLon = Math.toRadians(b.lon - a.lon)
    val h = sin(dLat / 2).pow(2) + cos(Math.toRadians(a.lat)) * cos(Math.toRadians(b.lat)) * sin(dLon / 2).pow(2)
    return 2 * 6371.0 * asin(sqrt(h))
}

fun bearingDeg(a: City, b: City): Double {
    val p1 = Math.toRadians(a.lat)
    val p2 = Math.toRadians(b.lat)
    val dl = Math.toRadians(b.lon - a.lon)
    val y = sin(dl) * cos(p2)
    val x = cos(p1) * sin(p2) - sin(p1) * cos(p2) * cos(dl)
    return (Math.toDegrees(atan2(y, x)) + 360.0) % 360.0
}

@Composable
fun cityName(ct: City): String = tr(ct.fa, ct.en)

@Composable
fun statusLabel(s: Int): String = when (s) {
    0 -> tr("آرام", "Calm")
    1 -> tr("نیازمند توجه", "Watch")
    else -> tr("هشدار", "Alert")
}

fun statusColor(c: TlxColors, s: Int): Color = when (s) {
    0 -> c.ok
    1 -> c.warn
    else -> c.danger
}

@Composable
fun MapScreen(state: AppState, back: () -> Unit) {
    val c = LocalColors.current
    var tab by remember { mutableIntStateOf(0) }
    var selId by remember { mutableStateOf("thr") }
    val sel = Cities.first { it.id == selId }
    val tehran = Cities.first { it.id == "thr" }

    Column(Modifier.fillMaxSize()) {
        TopBar(tr("نقشه و اطلاعات", "Map & geo info"), back)
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            GlassChip(tr("نقشه‌ی جهانی", "World globe"), tab == 0) { tab = 0 }
            GlassChip(tr("آفلاین", "Offline"), tab == 1) { tab = 1 }
            GlassChip(tr("شهرها", "Cities"), tab == 2) { tab = 2 }
            GlassChip(tr("لایه‌های آفلاین", "Offline layers"), tab == 3) { tab = 3 }
        }
        if (tab == 0) {
            GlobeTab(state, Modifier.weight(1f).fillMaxWidth().padding(start = 12.dp, end = 12.dp, bottom = 8.dp))
        } else {
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
            if (tab == 1) {
                IranMap(state, selId) { selId = it }
                Text(
                    tr("نقشه‌ی طرح‌واره‌ی آفلاین؛ مرزها تقریبی‌اند و داده‌ی زنده نیست.", "Offline schematic map; borders are approximate, not live data."),
                    color = c.sub, fontSize = 11.sp
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    GlassCard(Modifier.weight(1f)) {
                        Text(tr("وضعیت منطقه (دستی)", "Region status (manual)"), color = c.text, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        for (ct in Cities.take(4)) {
                            val st = state.regionOf(ct.id)
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                                    .clickable { state.cycleRegion(ct.id) }.padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(Modifier.size(9.dp).clip(CircleShape).background(statusColor(c, st)))
                                Spacer(Modifier.width(8.dp))
                                Text(cityName(ct), color = c.text, fontSize = 13.sp, modifier = Modifier.weight(1f), maxLines = 1)
                                Text(statusLabel(st), color = c.sub, fontSize = 11.sp)
                            }
                        }
                    }
                    GlassCard(Modifier.weight(1f)) {
                        Text(tr("اطلاعات جغرافیایی", "Geo info"), color = c.text, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text(cityName(sel), color = c.accent, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Text(tr("عرض", "Lat") + ": " + nf(String.format(java.util.Locale.US, "%.3f", sel.lat)), color = c.sub, fontSize = 12.sp)
                        Text(tr("طول", "Lon") + ": " + nf(String.format(java.util.Locale.US, "%.3f", sel.lon)), color = c.sub, fontSize = 12.sp)
                        if (sel.id != "thr") {
                            Text(
                                tr("فاصله از تهران", "From Tehran") + ": " + nf("${distKm(tehran, sel).toInt()}") + tr(" کم", " km"),
                                color = c.sub, fontSize = 12.sp
                            )
                            Text(
                                tr("جهت", "Bearing") + ": " + nf("${bearingDeg(tehran, sel).toInt()}°"),
                                color = c.sub, fontSize = 12.sp
                            )
                        }
                    }
                }
            } else if (tab == 2) {
                for (ct in Cities) {
                    val st = state.regionOf(ct.id)
                    GlassCard(Modifier.fillMaxWidth(), onClick = { selId = ct.id; tab = 0 }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(cityName(ct), color = c.text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                Text(
                                    nf(String.format(java.util.Locale.US, "%.2f", ct.lat)) + "°N  " + nf(String.format(java.util.Locale.US, "%.2f", ct.lon)) + "°E",
                                    color = c.sub, fontSize = 12.sp
                                )
                            }
                            Row(
                                Modifier.clip(RoundedCornerShape(12.dp)).clickable { state.cycleRegion(ct.id) }
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(Modifier.size(9.dp).clip(CircleShape).background(statusColor(c, st)))
                                Spacer(Modifier.width(6.dp))
                                Text(statusLabel(st), color = c.text, fontSize = 12.sp)
                            }
                        }
                    }
                }
                Text(tr("برای تغییر وضعیت روی برچسب ضربه بزنید. وضعیت‌ها را خودتان تعیین می‌کنید.", "Tap the label to change a status. Statuses are set by you."), color = c.sub, fontSize = 11.sp)
            } else {
                LayerRow(tr("خطوط شبکه‌ی جغرافیایی", "Graticule lines"), state.showGrid) { state.changeLayer(0, it) }
                LayerRow(tr("نام شهرها", "City names"), state.showLabels) { state.changeLayer(1, it) }
                LayerRow(tr("رنگ وضعیت شهرها", "City status colors"), state.showStatusColors) { state.changeLayer(2, it) }
            }
            Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun LayerRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val c = LocalColors.current
    GlassCard(Modifier.fillMaxWidth(), padding = 12.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = c.text, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Switch(
                checked = checked, onCheckedChange = onChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = c.onAccent, checkedTrackColor = c.accent,
                    uncheckedThumbColor = c.sub, uncheckedTrackColor = c.field, uncheckedBorderColor = c.border
                )
            )
        }
    }
}

@Composable
private fun IranMap(state: AppState, selId: String, onSelect: (String) -> Unit) {
    val c = LocalColors.current
    val fa = LocalLang.current == "fa"
    // The map is drawn left-to-right regardless of the UI direction.
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        BoxWithConstraints(
            Modifier.fillMaxWidth().aspectRatio(1.08f).clip(RoundedCornerShape(20.dp))
                .background(c.field).border(1.dp, c.border, RoundedCornerShape(20.dp))
        ) {
            val w = maxWidth
            val h = maxHeight
            Canvas(
                Modifier.fillMaxSize().pointerInput(Unit) {
                    detectTapGestures { off ->
                        val sw = size.width.toFloat()
                        val sh = size.height.toFloat()
                        var best: City? = null
                        var bd = Float.MAX_VALUE
                        for (ct in Cities) {
                            val d = hypot(off.x - fx(ct.lon) * sw, off.y - fy(ct.lat) * sh)
                            if (d < bd) { bd = d; best = ct }
                        }
                        val b = best
                        if (b != null && bd < 64f * density) onSelect(b.id)
                    }
                }
            ) {
                val sw = size.width
                val sh = size.height
                if (state.showGrid) {
                    for (lon in listOf(45.0, 50.0, 55.0, 60.0)) {
                        drawLine(c.border, Offset(fx(lon) * sw, 0f), Offset(fx(lon) * sw, sh), strokeWidth = 1f)
                    }
                    for (lat in listOf(25.0, 30.0, 35.0, 40.0)) {
                        drawLine(c.border, Offset(0f, fy(lat) * sh), Offset(sw, fy(lat) * sh), strokeWidth = 1f)
                    }
                }
                val path = Path()
                var first = true
                for (p in IranOutline) {
                    val x = fx(p.first) * sw
                    val y = fy(p.second) * sh
                    if (first) { path.moveTo(x, y); first = false } else path.lineTo(x, y)
                }
                path.close()
                drawPath(path, c.accent.copy(alpha = 0.20f))
                drawPath(path, c.accent.copy(alpha = 0.85f), style = Stroke(width = 2.5f))
                for (ct in Cities) {
                    val cx = fx(ct.lon) * sw
                    val cy = fy(ct.lat) * sh
                    val col = if (state.showStatusColors) statusColor(c, state.regionOf(ct.id)) else c.accent
                    if (ct.id == selId) {
                        drawCircle(col.copy(alpha = 0.30f), radius = 20f, center = Offset(cx, cy))
                        drawCircle(col, radius = 20f, center = Offset(cx, cy), style = Stroke(width = 2f))
                    }
                    drawCircle(col, radius = 8f, center = Offset(cx, cy))
                }
            }
            if (state.showLabels) {
                for (ct in Cities) {
                    Text(
                        text = cityName(ct), color = c.text, fontSize = 10.sp, maxLines = 1,
                        modifier = Modifier.absoluteOffset(x = w * fx(ct.lon) + 8.dp, y = h * fy(ct.lat) - 8.dp)
                    )
                }
            }
            Text(tr("دریای خزر", "Caspian Sea"), color = c.sub, fontSize = 10.sp,
                modifier = Modifier.absoluteOffset(x = w * fx(50.2), y = h * fy(39.0)))
            Text(tr("خلیج فارس", "Persian Gulf"), color = c.sub, fontSize = 10.sp,
                modifier = Modifier.absoluteOffset(x = w * fx(49.3), y = h * fy(27.2)))
            Text(tr("دریای عمان", "Gulf of Oman"), color = c.sub, fontSize = 10.sp,
                modifier = Modifier.absoluteOffset(x = w * fx(58.5), y = h * fy(24.7)))
        }
    }
}
