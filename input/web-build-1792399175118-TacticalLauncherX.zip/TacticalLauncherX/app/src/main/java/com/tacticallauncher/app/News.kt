package com.tacticallauncher.app

import android.text.Html
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale

data class NewsItem(val title: String, val link: String, val source: String, val time: Long, val snippet: String)
data class Feed(val name: String, val url: String)

/** Free public RSS feeds. The user can add, remove or reset them from the app. */
val DefaultFeeds = listOf(
    Feed("BBC World", "https://feeds.bbci.co.uk/news/world/rss.xml"),
    Feed("Al Jazeera", "https://www.aljazeera.com/xml/rss/all.xml"),
    Feed("DW", "https://rss.dw.com/rdf/rss-en-all"),
    Feed("BBC فارسی", "https://feeds.bbci.co.uk/persian/rss.xml")
)

object NewsFetcher {
    private val patterns = arrayOf(
        "EEE, dd MMM yyyy HH:mm:ss Z",
        "EEE, dd MMM yyyy HH:mm:ss zzz",
        "dd MMM yyyy HH:mm:ss Z"
    )

    private fun parseTime(raw: String): Long {
        val t = raw.trim()
        if (t.isEmpty()) return 0L
        for (f in patterns) {
            try {
                val d = SimpleDateFormat(f, Locale.US).parse(t)
                if (d != null) return d.time
            } catch (e: Exception) { }
        }
        try { return java.time.OffsetDateTime.parse(t).toInstant().toEpochMilli() } catch (e: Exception) { }
        try { return java.time.Instant.parse(t).toEpochMilli() } catch (e: Exception) { }
        return 0L
    }

    private fun clean(s: String): String {
        val t = try { Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY).toString() } catch (e: Exception) { s }
        return t.replace('\uFFFC', ' ').replace(Regex("\\s+"), " ").trim()
    }

    /** Blocking network call: run it on a background dispatcher. Returns an empty list on any failure. */
    fun fetch(feed: Feed): List<NewsItem> {
        val out = ArrayList<NewsItem>()
        var conn: HttpURLConnection? = null
        try {
            conn = URL(feed.url).openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) TacticalLauncherX")
            conn.setRequestProperty("Accept", "application/rss+xml, application/xml, text/xml, */*")
            if (conn.responseCode !in 200..299) return out
            val p = Xml.newPullParser()
            p.setInput(conn.inputStream, null)
            var inItem = false
            var title = ""
            var link = ""
            var date = ""
            var desc = ""
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG) {
                    val n = p.name
                    if (n == "item" || n == "entry") {
                        inItem = true
                        title = ""; link = ""; date = ""; desc = ""
                    } else if (inItem) {
                        when (n) {
                            "title" -> title = p.nextText()
                            "link" -> {
                                val href = p.getAttributeValue(null, "href")
                                val txt = p.nextText()
                                link = if (href != null) { if (link.isEmpty()) href else link } else txt
                            }
                            "description", "summary" -> desc = p.nextText()
                            "pubDate", "published", "updated", "dc:date" -> date = p.nextText()
                            else -> { }
                        }
                    }
                } else if (ev == XmlPullParser.END_TAG) {
                    val n = p.name
                    if ((n == "item" || n == "entry") && inItem) {
                        inItem = false
                        if (title.isNotBlank() && link.isNotBlank()) {
                            out.add(NewsItem(clean(title), link.trim(), feed.name, parseTime(date), clean(desc).take(200)))
                        }
                        if (out.size >= 25) break
                    }
                }
                ev = p.next()
            }
        } catch (e: Exception) {
            // keep whatever was parsed before the failure
        } finally {
            try { conn?.disconnect() } catch (e: Exception) { }
        }
        return out
    }
}
