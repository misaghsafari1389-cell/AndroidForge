package com.tacticallauncher.app

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MonthPicker(selected: Long, today: Long, marks: Set<Long>, onSelect: (Long) -> Unit) {
    val c = LocalColors.current
    val fa = LocalLang.current == "fa"
    val init = CalUtil.ymd(fa, selected)
    var vy by remember { mutableIntStateOf(init[0]) }
    var vm by remember { mutableIntStateOf(init[1]) }
    val first = CalUtil.toEpoch(fa, vy, vm, 1)
    val len = CalUtil.monthLen(fa, vy, vm)
    val off = CalUtil.weekOffset(fa, first)
    val rows = (off + len + 6) / 7

    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(if (fa) Icons.Outlined.ChevronRight else Icons.Outlined.ChevronLeft) {
                val n = CalUtil.shiftMonth(vy, vm, -1); vy = n[0]; vm = n[1]
            }
            Text(
                nf("${CalUtil.monthName(fa, vm)} $vy"),
                color = c.text, fontSize = 16.sp, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center, modifier = Modifier.weight(1f)
            )
            IconBtn(if (fa) Icons.Outlined.ChevronLeft else Icons.Outlined.ChevronRight) {
                val n = CalUtil.shiftMonth(vy, vm, 1); vy = n[0]; vm = n[1]
            }
        }
        Row(Modifier.fillMaxWidth()) {
            for (h in CalUtil.dayHeaders(fa)) {
                Text(h, color = c.sub, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(4.dp))
        for (r in 0 until rows) {
            Row(Modifier.fillMaxWidth()) {
                for (col in 0 until 7) {
                    val dayNum = r * 7 + col - off + 1
                    Box(Modifier.weight(1f).aspectRatio(1f).padding(2.dp), contentAlignment = Alignment.Center) {
                        if (dayNum in 1..len) {
                            val e = first + (dayNum - 1)
                            val isSel = e == selected
                            val isToday = e == today
                            Box(
                                Modifier.fillMaxSize().clip(CircleShape)
                                    .background(if (isSel) c.accent else Color.Transparent)
                                    .border(1.dp, if (isToday && !isSel) c.accent else Color.Transparent, CircleShape)
                                    .clickable { onSelect(e) },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    nf(dayNum), fontSize = 13.sp,
                                    color = if (isSel) c.onAccent else c.text,
                                    fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal
                                )
                                if (e in marks) {
                                    Box(
                                        Modifier.align(Alignment.BottomCenter).padding(bottom = 3.dp).size(4.dp)
                                            .clip(CircleShape).background(if (isSel) c.onAccent else c.warn)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TaskRow(state: AppState, t: TaskItem, today: Long) {
    val c = LocalColors.current
    val fa = LocalLang.current == "fa"
    val due = t.due
    val overdue = due != null && due < today && !t.done
    GlassCard(Modifier.fillMaxWidth(), padding = 10.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (t.done) Icons.Outlined.CheckCircle else Icons.Outlined.RadioButtonUnchecked,
                contentDescription = null,
                tint = if (t.done) c.ok else c.sub,
                modifier = Modifier.size(26.dp).clip(CircleShape).clickable { state.toggleTask(t.id) }
            )
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    t.title, color = if (t.done) c.sub else c.text, fontSize = 14.sp,
                    textDecoration = if (t.done) TextDecoration.LineThrough else TextDecoration.None
                )
                if (due != null) {
                    Text(
                        CalUtil.fmt(fa, due) + if (overdue) "  ·  " + tr("گذشته", "overdue") else "",
                        color = if (overdue) c.danger else c.sub, fontSize = 11.sp
                    )
                }
            }
            IconBtn(Icons.Outlined.Delete, c.sub) { state.deleteTask(t.id) }
        }
    }
}

@Composable
fun PlannerScreen(state: AppState, initialTab: Int, back: () -> Unit) {
    val c = LocalColors.current
    val fa = LocalLang.current == "fa"
    val today = remember { CalUtil.today() }
    var tab by remember { mutableIntStateOf(initialTab) }
    var selected by remember { mutableLongStateOf(today) }
    var newTitle by remember { mutableStateOf("") }
    var newDue by remember { mutableStateOf<Long?>(null) }
    var showPicker by remember { mutableStateOf(false) }
    val marks = state.tasks.filter { !it.done }.mapNotNull { it.due }.toSet()

    Column(Modifier.fillMaxSize()) {
        TopBar(tr("تقویم و وظایف", "Calendar & tasks"), back)
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            GlassChip(tr("تقویم", "Calendar"), tab == 0, Modifier.weight(1f)) { tab = 0 }
            GlassChip(tr("وظایف", "Tasks"), tab == 1, Modifier.weight(1f)) { tab = 1 }
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (tab == 0) {
                GlassCard(Modifier.fillMaxWidth(), padding = 10.dp) {
                    MonthPicker(selected, today, marks) { selected = it }
                }
                Text(CalUtil.fmtLong(fa, selected), color = c.text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                val dayTasks = state.tasks.filter { it.due == selected }
                if (dayTasks.isEmpty()) {
                    Text(tr("وظیفه‌ای برای این روز نیست.", "No tasks for this day."), color = c.sub, fontSize = 13.sp)
                }
                for (t in dayTasks) TaskRow(state, t, today)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassField(newTitle, { newTitle = it }, tr("وظیفه‌ی جدید برای این روز", "New task for this day"), Modifier.weight(1f))
                    IconBtn(Icons.Outlined.Add, c.accent) {
                        if (newTitle.isNotBlank()) { state.addTask(newTitle.trim(), selected); newTitle = "" }
                    }
                }
            } else {
                GlassCard(Modifier.fillMaxWidth(), padding = 10.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GlassField(newTitle, { newTitle = it }, tr("وظیفه‌ی جدید", "New task"), Modifier.weight(1f))
                        IconBtn(Icons.Outlined.Add, c.accent) {
                            if (newTitle.isNotBlank()) { state.addTask(newTitle.trim(), newDue); newTitle = ""; newDue = null }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    val dueNow = newDue
                    GlassChip(
                        if (dueNow == null) tr("بدون تاریخ سررسید", "No due date") else tr("سررسید: ", "Due: ") + CalUtil.fmt(fa, dueNow),
                        dueNow != null
                    ) { showPicker = true }
                }
                val active = state.tasks.filter { !it.done }.sortedBy { it.due ?: Long.MAX_VALUE }
                val done = state.tasks.filter { it.done }
                if (state.tasks.isEmpty()) {
                    EmptyState(Icons.Outlined.CheckCircle, tr("وظیفه‌ای ثبت نشده.", "No tasks yet."))
                }
                for (t in active) TaskRow(state, t, today)
                if (done.isNotEmpty()) {
                    SectionTitle(tr("انجام‌شده", "Completed"))
                    for (t in done) TaskRow(state, t, today)
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }

    if (showPicker) {
        var temp by remember { mutableLongStateOf(newDue ?: today) }
        TlxDialog(
            title = tr("تاریخ سررسید", "Due date"),
            onDismiss = { showPicker = false },
            confirmText = tr("تایید", "OK"),
            onConfirm = { newDue = temp; showPicker = false },
            dismissText = tr("انصراف", "Cancel")
        ) {
            MonthPicker(temp, today, emptySet()) { temp = it }
            TextButton(onClick = { newDue = null; showPicker = false }) {
                Text(tr("بدون تاریخ", "No date"), color = c.sub)
            }
        }
    }
}
