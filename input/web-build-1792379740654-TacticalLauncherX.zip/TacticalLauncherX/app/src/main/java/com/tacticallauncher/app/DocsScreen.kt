package com.tacticallauncher.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

fun docKind(d: DocItem): Int {
    val n = d.name.lowercase()
    return when {
        d.mime.contains("pdf") || n.endsWith(".pdf") -> 1
        n.endsWith(".doc") || n.endsWith(".docx") || d.mime.contains("word") -> 2
        d.mime.startsWith("image/") -> 3
        n.endsWith(".zip") || n.endsWith(".rar") || n.endsWith(".7z") || d.mime.contains("zip") -> 4
        else -> 0
    }
}

private fun kindIcon(k: Int): ImageVector = when (k) {
    1 -> Icons.Outlined.PictureAsPdf
    3 -> Icons.Outlined.Image
    4 -> Icons.Outlined.Archive
    else -> Icons.Outlined.Description
}

private fun kindColor(k: Int): Color = when (k) {
    1 -> Color(0xFFE5484D)
    2 -> Color(0xFF3B82F6)
    3 -> Color(0xFF3FB27F)
    4 -> Color(0xFFE5A93B)
    else -> Color(0xFF8A99A8)
}

private fun openDoc(ctx: Context, d: DocItem, failText: String) {
    try {
        val i = Intent(Intent.ACTION_VIEW)
        i.setDataAndType(Uri.parse(d.uri), if (d.mime.isEmpty()) "*/*" else d.mime)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (e: Exception) {
        Toast.makeText(ctx, failText, Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun DocsScreen(state: AppState, back: () -> Unit) {
    val ctx = LocalContext.current
    val c = LocalColors.current
    val fa = LocalLang.current == "fa"
    var q by remember { mutableStateOf("") }
    var kind by remember { mutableIntStateOf(-1) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        for (u in uris) state.importDoc(u)
    }
    val failText = tr("برنامه‌ای برای باز کردن این فایل پیدا نشد", "No app found to open this file")
    val list = state.docs.filter {
        (kind < 0 || docKind(it) == kind) && (q.isBlank() || it.name.contains(q.trim(), true))
    }

    Column(Modifier.fillMaxSize()) {
        TopBar(tr("اسناد", "Documents"), back) {
            IconBtn(Icons.Outlined.Add) { picker.launch(arrayOf("*/*")) }
        }
        GlassField(
            value = q, onValueChange = { q = it },
            placeholder = tr("جستجو در اسناد...", "Search documents..."),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            leading = Icons.Outlined.Search
        )
        Spacer(Modifier.height(10.dp))
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            GlassChip(tr("همه", "All"), kind < 0) { kind = -1 }
            GlassChip("PDF", kind == 1) { kind = 1 }
            GlassChip("Word", kind == 2) { kind = 2 }
            GlassChip(tr("تصاویر", "Images"), kind == 3) { kind = 3 }
            GlassChip(tr("فشرده", "Archives"), kind == 4) { kind = 4 }
        }
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (list.isEmpty()) {
                item {
                    EmptyState(
                        Icons.Outlined.Folder,
                        tr("هنوز سندی اضافه نشده. با + فایل‌ها را از حافظه‌ی گوشی انتخاب کنید؛ فایل‌ها کپی نمی‌شوند، فقط پیوند آن‌ها نگه داشته می‌شود.",
                            "No documents yet. Use + to pick files from your phone. Files are not copied; only links are kept.")
                    )
                }
            }
            items(list, key = { it.id }) { d ->
                val k = docKind(d)
                var menu by remember { mutableStateOf(false) }
                GlassCard(Modifier.fillMaxWidth(), padding = 10.dp, onClick = { openDoc(ctx, d, failText) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(46.dp).clip(RoundedCornerShape(12.dp)).background(kindColor(k).copy(alpha = 0.22f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(kindIcon(k), contentDescription = null, tint = kindColor(k), modifier = Modifier.size(26.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(d.name, color = c.text, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(
                                nf(fmtSize(d.size)) + "  ·  " + CalUtil.fmt(fa, d.added / 86400000L),
                                color = c.sub, fontSize = 12.sp
                            )
                        }
                        Box {
                            IconBtn(Icons.Outlined.MoreVert) { menu = true }
                            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                DropdownMenuItem(
                                    text = { Text(tr("باز کردن", "Open"), color = c.text) },
                                    onClick = { menu = false; openDoc(ctx, d, failText) }
                                )
                                DropdownMenuItem(
                                    text = { Text(tr("حذف از فهرست", "Remove from list"), color = c.danger) },
                                    onClick = { menu = false; state.removeDoc(d.id) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NotesScreen(state: AppState, back: () -> Unit) {
    val c = LocalColors.current
    val fa = LocalLang.current == "fa"
    var editing by remember { mutableStateOf(false) }
    var editId by remember { mutableStateOf<Long?>(null) }
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize()) {
        TopBar(tr("گزارش‌ها و یادداشت‌ها", "Notes & reports"), back) {
            IconBtn(Icons.Outlined.Add) {
                editId = null; title = ""; body = ""; editing = true
            }
        }
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (state.notes.isEmpty()) {
                item { EmptyState(Icons.Outlined.Edit, tr("یادداشتی ثبت نشده. با + اولین یادداشت را بنویسید.", "No notes yet. Use + to write one.")) }
            }
            items(state.notes.toList(), key = { it.id }) { n ->
                GlassCard(Modifier.fillMaxWidth(), onClick = {
                    editId = n.id; title = n.title; body = n.body; editing = true
                }) {
                    Text(
                        if (n.title.isBlank()) tr("بدون عنوان", "Untitled") else n.title,
                        color = c.text, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    if (n.body.isNotBlank()) {
                        Text(n.body, color = c.sub, fontSize = 13.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(CalUtil.fmt(fa, n.updated / 86400000L), color = c.sub, fontSize = 11.sp)
                }
            }
        }
    }

    if (editing) {
        val id = editId
        TlxDialog(
            title = if (id == null) tr("یادداشت جدید", "New note") else tr("ویرایش یادداشت", "Edit note"),
            onDismiss = { editing = false },
            confirmText = tr("ذخیره", "Save"),
            onConfirm = {
                if (title.isNotBlank() || body.isNotBlank()) state.saveNote(id, title.trim(), body.trim())
                editing = false
            },
            dismissText = tr("انصراف", "Cancel")
        ) {
            GlassField(title, { title = it }, tr("عنوان", "Title"), Modifier.fillMaxWidth())
            GlassField(body, { body = it }, tr("متن", "Text"), Modifier.fillMaxWidth(), singleLine = false, minLines = 5)
            if (id != null) {
                TextButton(onClick = { state.deleteNote(id); editing = false }) {
                    Text(tr("حذف یادداشت", "Delete note"), color = c.danger)
                }
            }
        }
    }
}
