package com.tacticallauncher.app

import androidx.compose.ui.graphics.Path
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private class Hit(val kind: String, val title: String, val action: () -> Unit)
private class Tile(val icon: ImageVector, val label: String, val route: Route)

@Composable
fun HomeScreen(state: AppState, go: (Route) -> Unit) {
    val c = LocalColors.current
    val fa = LocalLang.current == "fa"
    val ctx = LocalContext.current

    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    var sys by remember { mutableStateOf(Sys.read(ctx)) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            sys = withContext(Dispatchers.Default) { Sys.read(ctx) }
            delay(20000L)
        }
    }
    var query by remember { mutableStateOf("") }

    val ldt = LocalDateTime.ofInstant(Instant.ofEpochMilli(now), ZoneId.systemDefault())
    val today = ldt.toLocalDate().toEpochDay()
    val hour = ldt.hour
    val greeting = if (fa) {
        when {
            hour in 5..11 -> "صبح بخیر"
            hour in 12..16 -> "ظهر بخیر"
            hour in 17..20 -> "عصر بخیر"
            else -> "شب بخیر"
        }
    } else {
        when {
            hour in 5..11 -> "Good morning"
            hour in 12..16 -> "Good afternoon"
            hour in 17..20 -> "Good evening"
            else -> "Good night"
        }
    }
    val hello = if (fa) "سلام فرمانده ${state.userName}" else "Hello, Commander ${state.userName}"
    val timeText = nf("${pad2(ldt.hour)}:${pad2(ldt.minute)}")
    val dateText = CalUtil.fmtLong(fa, today)

    val tiles = listOf(
        Tile(Icons.Outlined.Visibility, tr("اطلاعات", "Info"), Route.Info),
        Tile(Icons.Outlined.Place, tr("نقشه‌ها", "Maps"), Route.Map),
        Tile(Icons.Outlined.Wifi, tr("ارتباطات", "Network"), Route.Status),
        Tile(Icons.Outlined.Edit, tr("گزارش‌ها", "Notes"), Route.Notes),
        Tile(Icons.Outlined.Folder, tr("اسناد", "Docs"), Route.Docs),
        Tile(Icons.Outlined.DateRange, tr("تقویم", "Calendar"), Route.Calendar),
        Tile(Icons.Outlined.CheckCircle, tr("وظایف", "Tasks"), Route.Tasks),
        Tile(Icons.Outlined.Speed, tr("مانیتور سیستم", "System"), Route.Status)
    )

    val kNote = tr("یادداشت", "Note")
    val kTask = tr("وظیفه", "Task")
    val kInfo = tr("اطلاعات", "Info")
    val kDoc = tr("سند", "Doc")
    val kApp = tr("برنامه", "App")
    val hits = ArrayList<Hit>()
    if (query.isNotBlank()) {
        val q = query.trim()
        for (n in state.notes) {
            if (n.title.contains(q, true) || n.body.contains(q, true)) {
                hits.add(Hit(kNote, if (n.title.isBlank()) n.body.take(30) else n.title) { go(Route.Notes) })
            }
        }
        for (t in state.tasks) {
            if (t.title.contains(q, true)) hits.add(Hit(kTask, t.title) { go(Route.Tasks) })
        }
        for (i in state.infos) {
            if (i.title.contains(q, true) || i.summary.contains(q, true)) hits.add(Hit(kInfo, i.title) { go(Route.Info) })
        }
        for (d in state.docs) {
            if (d.name.contains(q, true)) hits.add(Hit(kDoc, d.name) { go(Route.Docs) })
        }
        for (a in state.apps) {
            if (a.label.contains(q, true)) hits.add(Hit(kApp, a.label) { launchApp(ctx, state, a.pkg) })
        }
    }

    val upcoming = state.tasks
        .filter { !it.done && it.due != null && it.due >= today }
        .sortedBy { it.due }
        .take(3)

    val netText = when (sys.net) {
        0 -> tr("قطع", "Offline")
        1 -> "Wi-Fi"
        2 -> tr("داده همراه", "Mobile data")
        else -> tr("متصل", "Connected")
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // header
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBtn(Icons.Outlined.Tune) { go(Route.Settings) }
            Column(Modifier.weight(1f).padding(horizontal = 6.dp)) {
                Text(dateText, color = c.text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                Text(tr("لانچر تاکتیکال", "Tactical Launcher"), color = c.sub, fontSize = 12.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(timeText, color = c.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                if (sys.battery >= 0) {
                    Text(
                        nf("${sys.battery}%") + if (sys.charging) " ⚡" else "",
                        color = c.sub, fontSize = 12.sp
                    )
                }
            }
        }

        // hero
        GlassCard(Modifier.fillMaxWidth().height(128.dp), padding = 0.dp) {
            Box(Modifier.fillMaxSize()) {
                Canvas(Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    drawRect(Brush.verticalGradient(listOf(c.glow2.copy(alpha = 0.85f), c.bgBottom)))
                    val back = Path().apply {
                        moveTo(0f, h); lineTo(0f, h * 0.60f); lineTo(w * 0.16f, h * 0.40f)
                        lineTo(w * 0.30f, h * 0.58f); lineTo(w * 0.46f, h * 0.28f)
                        lineTo(w * 0.62f, h * 0.55f); lineTo(w * 0.80f, h * 0.38f)
                        lineTo(w, h * 0.58f); lineTo(w, h); close()
                    }
                    drawPath(back, c.glow1.copy(alpha = 0.55f))
                    val front = Path().apply {
                        moveTo(0f, h); lineTo(0f, h * 0.80f); lineTo(w * 0.22f, h * 0.68f)
                        lineTo(w * 0.42f, h * 0.82f); lineTo(w * 0.66f, h * 0.66f)
                        lineTo(w * 0.86f, h * 0.80f); lineTo(w, h * 0.70f); lineTo(w, h); close()
                    }
                    drawPath(front, c.bgBottom.copy(alpha = 0.85f))
                }
                Row(
                    Modifier.fillMaxSize().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(58.dp).clip(CircleShape)
                            .background(c.bgBottom.copy(alpha = 0.6f))
                            .border(1.5.dp, c.accent, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Outlined.Shield, contentDescription = null, tint = c.accent, modifier = Modifier.size(32.dp))
                    }
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(greeting, color = c.sub, fontSize = 13.sp)
                        Text(hello, color = c.text, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }

        // search
        GlassField(
            value = query,
            onValueChange = { query = it },
            placeholder = tr("جستجو در برنامه‌ها و اطلاعات...", "Search apps and data..."),
            modifier = Modifier.fillMaxWidth(),
            leading = Icons.Outlined.Search
        )
        if (query.isNotBlank()) {
            GlassCard(Modifier.fillMaxWidth(), padding = 6.dp) {
                if (hits.isEmpty()) {
                    Text(tr("نتیجه‌ای پیدا نشد", "No results"), color = c.sub, fontSize = 14.sp, modifier = Modifier.padding(10.dp))
                }
                for (h in hits.take(8)) {
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                            .clickable { h.action() }.padding(horizontal = 10.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(h.title, color = c.text, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        Text(h.kind, color = c.accent, fontSize = 12.sp)
                    }
                }
            }
        }

        // shortcut tiles
        for (row in tiles.chunked(4)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                for (t in row) {
                    GlassCard(Modifier.weight(1f).height(86.dp), padding = 6.dp, onClick = { go(t.route) }) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(t.icon, contentDescription = null, tint = c.accent, modifier = Modifier.size(28.dp))
                                Text(t.label, color = c.text, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        }

        // upcoming + device
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassCard(Modifier.weight(1f).height(168.dp), onClick = { go(Route.Tasks) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(tr("رویدادهای پیش رو", "Upcoming"), color = c.text, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Icon(Icons.Outlined.Event, contentDescription = null, tint = c.accent, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.height(8.dp))
                if (upcoming.isEmpty()) {
                    Text(tr("رویدادی ثبت نشده. در بخش وظایف تاریخ‌دار اضافه کنید.", "Nothing scheduled. Add a dated task."), color = c.sub, fontSize = 12.sp)
                } else {
                    for (t in upcoming) {
                        Column(Modifier.padding(bottom = 6.dp)) {
                            Text(t.title, color = c.text, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(CalUtil.fmt(fa, t.due ?: today), color = c.sub, fontSize = 11.sp)
                        }
                    }
                }
            }
            GlassCard(Modifier.weight(1f).height(168.dp), onClick = { go(Route.Status) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(tr("وضعیت دستگاه", "Device"), color = c.text, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Icon(Icons.Outlined.Speed, contentDescription = null, tint = c.accent, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.height(10.dp))
                Text(tr("شبکه", "Network"), color = c.sub, fontSize = 11.sp)
                Text(netText, color = c.text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(8.dp))
                val ramFrac = if (sys.ramTotalMb > 0) sys.ramUsedMb.toFloat() / sys.ramTotalMb.toFloat() else 0f
                Text(tr("حافظه رم", "RAM"), color = c.sub, fontSize = 11.sp)
                Bar(ramFrac, c.accent, Modifier.padding(vertical = 4.dp))
                Text(nf("${(ramFrac * 100).toInt()}%"), color = c.text, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}
