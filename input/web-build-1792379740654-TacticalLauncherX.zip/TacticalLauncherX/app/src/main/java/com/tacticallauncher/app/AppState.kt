package com.tacticallauncher.app

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

data class Note(val id: Long, val title: String, val body: String, val updated: Long)
data class TaskItem(val id: Long, val title: String, val done: Boolean, val due: Long?)
data class InfoItem(val id: Long, val title: String, val summary: String, val category: Int, val created: Long, val sample: Boolean)
data class DocItem(val id: Long, val uri: String, val name: String, val size: Long, val mime: String, val added: Long)
data class AppEntry(val label: String, val pkg: String)

/** All user data lives in SharedPreferences on the device. Nothing is sent anywhere. */
class AppState(private val ctx: Context) {
    private val prefs: SharedPreferences = ctx.getSharedPreferences("tlx_prefs", Context.MODE_PRIVATE)
    private var lastId = 0L

    private fun nextId(): Long {
        val t = System.currentTimeMillis()
        lastId = if (t > lastId) t else lastId + 1L
        return lastId
    }

    // ---- settings ----
    var themeIndex by mutableIntStateOf(prefs.getInt("theme", 0))
        private set
    var lang by mutableStateOf(prefs.getString("lang", "fa") ?: "fa")
        private set
    var fontIndex by mutableIntStateOf(prefs.getInt("font", 1))
        private set
    var userName by mutableStateOf(prefs.getString("name", "صالح") ?: "صالح")
        private set
    var animations by mutableStateOf(prefs.getBoolean("anim", true))
        private set
    var showGrid by mutableStateOf(prefs.getBoolean("l_grid", true))
        private set
    var showLabels by mutableStateOf(prefs.getBoolean("l_labels", true))
        private set
    var showStatusColors by mutableStateOf(prefs.getBoolean("l_status", true))
        private set

    var apps by mutableStateOf<List<AppEntry>>(emptyList())
        private set

    // ---- data ----
    val notes = mutableStateListOf<Note>()
    val tasks = mutableStateListOf<TaskItem>()
    val infos = mutableStateListOf<InfoItem>()
    val docs = mutableStateListOf<DocItem>()
    val regionStatus = mutableStateMapOf<String, Int>()
    val pinned = mutableStateListOf<String>()
    val recent = mutableStateListOf<String>()

    init {
        loadNotes()
        loadTasks()
        loadInfos()
        loadDocs()
        loadRegions()
        loadStrings("pinned", pinned)
        loadStrings("recent", recent)
        if (!prefs.getBoolean("seeded", false)) {
            seedSamples()
            prefs.edit().putBoolean("seeded", true).apply()
        }
    }

    // ---- settings API ----
    fun changeTheme(i: Int) { themeIndex = i; prefs.edit().putInt("theme", i).apply() }
    fun changeLang(l: String) { lang = l; prefs.edit().putString("lang", l).apply() }
    fun changeFont(i: Int) { fontIndex = i; prefs.edit().putInt("font", i).apply() }
    fun changeName(n: String) { userName = n; prefs.edit().putString("name", n).apply() }
    fun changeAnimations(v: Boolean) { animations = v; prefs.edit().putBoolean("anim", v).apply() }
    fun changeLayer(which: Int, v: Boolean) {
        when (which) {
            0 -> { showGrid = v; prefs.edit().putBoolean("l_grid", v).apply() }
            1 -> { showLabels = v; prefs.edit().putBoolean("l_labels", v).apply() }
            else -> { showStatusColors = v; prefs.edit().putBoolean("l_status", v).apply() }
        }
    }
    fun updateApps(list: List<AppEntry>) { apps = list }

    // ---- notes ----
    fun saveNote(id: Long?, title: String, body: String) {
        val now = System.currentTimeMillis()
        if (id == null) {
            notes.add(0, Note(nextId(), title, body, now))
        } else {
            val idx = notes.indexOfFirst { it.id == id }
            if (idx >= 0) notes[idx] = notes[idx].copy(title = title, body = body, updated = now)
        }
        persistNotes()
    }
    fun deleteNote(id: Long) { notes.removeAll { it.id == id }; persistNotes() }

    // ---- tasks ----
    fun addTask(title: String, due: Long?) {
        tasks.add(0, TaskItem(nextId(), title, false, due))
        persistTasks()
    }
    fun toggleTask(id: Long) {
        val idx = tasks.indexOfFirst { it.id == id }
        if (idx >= 0) { tasks[idx] = tasks[idx].copy(done = !tasks[idx].done); persistTasks() }
    }
    fun deleteTask(id: Long) { tasks.removeAll { it.id == id }; persistTasks() }

    // ---- info ----
    fun addInfo(title: String, summary: String, category: Int) {
        infos.add(0, InfoItem(nextId(), title, summary, category, System.currentTimeMillis(), false))
        persistInfos()
    }
    fun deleteInfo(id: Long) { infos.removeAll { it.id == id }; persistInfos() }

    // ---- documents ----
    fun importDoc(uri: Uri) {
        val key = uri.toString()
        if (docs.any { it.uri == key }) return
        try {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) { }
        var name = uri.lastPathSegment ?: "file"
        var size = 0L
        try {
            val cur = ctx.contentResolver.query(uri, null, null, null, null)
            if (cur != null) {
                try {
                    if (cur.moveToFirst()) {
                        val ni = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        val si = cur.getColumnIndex(OpenableColumns.SIZE)
                        if (ni >= 0) { name = cur.getString(ni) ?: name }
                        if (si >= 0 && !cur.isNull(si)) { size = cur.getLong(si) }
                    }
                } finally {
                    cur.close()
                }
            }
        } catch (e: Exception) { }
        val mime = try { ctx.contentResolver.getType(uri) ?: "" } catch (e: Exception) { "" }
        docs.add(0, DocItem(nextId(), key, name, size, mime, System.currentTimeMillis()))
        persistDocs()
    }
    fun removeDoc(id: Long) { docs.removeAll { it.id == id }; persistDocs() }

    // ---- regions ----
    fun regionOf(id: String): Int = regionStatus[id] ?: 0
    fun cycleRegion(id: String) {
        regionStatus[id] = (regionOf(id) + 1) % 3
        val o = JSONObject()
        for ((k, v) in regionStatus) o.put(k, v)
        prefs.edit().putString("regions", o.toString()).apply()
    }

    // ---- apps ----
    fun togglePin(pkg: String) {
        if (pkg in pinned) pinned.remove(pkg) else pinned.add(pkg)
        prefs.edit().putString("pinned", pinned.joinToString("\n")).apply()
    }
    fun pushRecent(pkg: String) {
        recent.remove(pkg)
        recent.add(0, pkg)
        while (recent.size > 8) recent.removeAt(recent.size - 1)
        prefs.edit().putString("recent", recent.joinToString("\n")).apply()
    }

    fun clearAll() {
        notes.clear(); tasks.clear(); infos.clear(); docs.clear()
        regionStatus.clear(); pinned.clear(); recent.clear()
        prefs.edit()
            .remove("notes").remove("tasks").remove("infos").remove("docs")
            .remove("regions").remove("pinned").remove("recent")
            .apply()
    }

    // ---- persistence ----
    private fun persistNotes() {
        val a = JSONArray()
        for (n in notes) {
            a.put(JSONObject().put("id", n.id).put("title", n.title).put("body", n.body).put("updated", n.updated))
        }
        prefs.edit().putString("notes", a.toString()).apply()
    }
    private fun persistTasks() {
        val a = JSONArray()
        for (t in tasks) {
            val o = JSONObject().put("id", t.id).put("title", t.title).put("done", t.done)
            o.put("due", t.due ?: JSONObject.NULL)
            a.put(o)
        }
        prefs.edit().putString("tasks", a.toString()).apply()
    }
    private fun persistInfos() {
        val a = JSONArray()
        for (i in infos) {
            a.put(
                JSONObject().put("id", i.id).put("title", i.title).put("summary", i.summary)
                    .put("cat", i.category).put("created", i.created).put("sample", i.sample)
            )
        }
        prefs.edit().putString("infos", a.toString()).apply()
    }
    private fun persistDocs() {
        val a = JSONArray()
        for (d in docs) {
            a.put(
                JSONObject().put("id", d.id).put("uri", d.uri).put("name", d.name)
                    .put("size", d.size).put("mime", d.mime).put("added", d.added)
            )
        }
        prefs.edit().putString("docs", a.toString()).apply()
    }

    private fun loadNotes() {
        try {
            val a = JSONArray(prefs.getString("notes", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                notes.add(Note(o.getLong("id"), o.getString("title"), o.getString("body"), o.getLong("updated")))
            }
        } catch (e: Exception) { }
    }
    private fun loadTasks() {
        try {
            val a = JSONArray(prefs.getString("tasks", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val due: Long? = if (o.isNull("due")) null else o.getLong("due")
                tasks.add(TaskItem(o.getLong("id"), o.getString("title"), o.getBoolean("done"), due))
            }
        } catch (e: Exception) { }
    }
    private fun loadInfos() {
        try {
            val a = JSONArray(prefs.getString("infos", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                infos.add(
                    InfoItem(
                        o.getLong("id"), o.getString("title"), o.getString("summary"),
                        o.getInt("cat"), o.getLong("created"), o.optBoolean("sample", false)
                    )
                )
            }
        } catch (e: Exception) { }
    }
    private fun loadDocs() {
        try {
            val a = JSONArray(prefs.getString("docs", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                docs.add(
                    DocItem(
                        o.getLong("id"), o.getString("uri"), o.getString("name"),
                        o.getLong("size"), o.getString("mime"), o.getLong("added")
                    )
                )
            }
        } catch (e: Exception) { }
    }
    private fun loadRegions() {
        try {
            val o = JSONObject(prefs.getString("regions", "{}") ?: "{}")
            val keys = o.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                regionStatus[k] = o.getInt(k)
            }
        } catch (e: Exception) { }
    }
    private fun loadStrings(key: String, into: MutableList<String>) {
        val raw = prefs.getString(key, "") ?: ""
        if (raw.isNotEmpty()) for (s in raw.split("\n")) if (s.isNotEmpty()) into.add(s)
    }

    private fun seedSamples() {
        val now = System.currentTimeMillis()
        val hour = 3600000L
        val text = "این یک مورد نمونه‌ی محلی است و خبر زنده نیست. موارد خودتان را اضافه کنید یا این را حذف کنید."
        infos.add(InfoItem(nextId(), "نمونه: جمع‌بندی سیاسی", text, 0, now - 2 * hour, true))
        infos.add(InfoItem(nextId(), "نمونه: گزارش وضعیت", text, 1, now - 5 * hour, true))
        infos.add(InfoItem(nextId(), "نمونه: شاخص اقتصادی", text, 2, now - 9 * hour, true))
        infos.add(InfoItem(nextId(), "نمونه: رویداد فرهنگی", text, 3, now - 26 * hour, true))
        persistInfos()
    }
}

// ---------- installed apps ----------

fun loadLauncherApps(ctx: Context): List<AppEntry> {
    return try {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(intent, 0)
        list.map { AppEntry(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    } catch (e: Exception) {
        emptyList()
    }
}

fun launchApp(ctx: Context, state: AppState, pkg: String) {
    try {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) {
            state.pushRecent(pkg)
            ctx.startActivity(i)
        }
    } catch (e: Exception) { }
}

// ---------- device status (all read from the system, nothing simulated) ----------

data class SysSnapshot(
    val net: Int,            // 0 none, 1 wifi, 2 cellular, 3 other
    val internetOk: Boolean,
    val battery: Int,        // -1 unknown
    val charging: Boolean,
    val ramUsedMb: Long,
    val ramTotalMb: Long,
    val storUsedGb: Double,
    val storTotalGb: Double,
    val heapMb: Long
)

object Sys {
    fun read(ctx: Context): SysSnapshot {
        var net = 0
        var ok = false
        try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val n = cm.activeNetwork
            val caps = if (n != null) cm.getNetworkCapabilities(n) else null
            if (caps != null) {
                net = when {
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> 1
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> 2
                    else -> 3
                }
                ok = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            }
        } catch (e: Exception) { }

        var pct = -1
        var charging = false
        try {
            val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (i != null) {
                val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                if (level >= 0 && scale > 0) pct = level * 100 / scale
                val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            }
        } catch (e: Exception) { }

        var ramTotal = 0L
        var ramUsed = 0L
        try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            ramTotal = mi.totalMem / (1024L * 1024L)
            ramUsed = (mi.totalMem - mi.availMem) / (1024L * 1024L)
        } catch (e: Exception) { }

        var storTotal = 0.0
        var storUsed = 0.0
        try {
            val st = StatFs(Environment.getDataDirectory().path)
            val total = st.blockCountLong * st.blockSizeLong
            val free = st.availableBlocksLong * st.blockSizeLong
            storTotal = total / 1073741824.0
            storUsed = (total - free) / 1073741824.0
        } catch (e: Exception) { }

        val rt = Runtime.getRuntime()
        val heap = (rt.totalMemory() - rt.freeMemory()) / (1024L * 1024L)
        return SysSnapshot(net, ok, pct, charging, ramUsed, ramTotal, storUsed, storTotal, heap)
    }
}
