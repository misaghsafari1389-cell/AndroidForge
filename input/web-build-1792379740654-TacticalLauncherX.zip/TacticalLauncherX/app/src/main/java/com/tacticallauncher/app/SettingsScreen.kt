package com.tacticallauncher.app

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private class HelpItem(val title: String, val body: String)

@Composable
private fun SettingBlock(icon: ImageVector, title: String, content: @Composable ColumnScope.() -> Unit) {
    val c = LocalColors.current
    GlassCard(Modifier.fillMaxWidth(), padding = 12.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = c.accent, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(10.dp))
            Text(title, color = c.text, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(10.dp))
        content()
    }
}

@Composable
fun SettingsScreen(state: AppState) {
    val c = LocalColors.current
    val ctx = LocalContext.current
    var nameDialog by remember { mutableStateOf(false) }
    var nameDraft by remember { mutableStateOf("") }
    var clearDialog by remember { mutableStateOf(false) }
    var helpOpen by remember { mutableIntStateOf(-1) }

    val version = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "1.0.0"
    } catch (e: Exception) {
        "1.0.0"
    }

    val help = listOf(
        HelpItem(tr("خانه", "Home"), tr("داشبورد با ساعت و تاریخ، جستجوی سراسری در برنامه‌ها، یادداشت‌ها، وظایف، اسناد و اطلاعات، میان‌بر بخش‌ها و رویدادهای پیش رو.", "Dashboard with time and date, global search across apps, notes, tasks, documents and info, section shortcuts and upcoming events.")),
        HelpItem(tr("اطلاعات", "Information"), tr("مرکز اطلاعات آفلاین. خودتان با + مورد اضافه می‌کنید و بر اساس دسته فیلتر می‌کنید. هیچ خبر آنلاینی نمایش داده نمی‌شود؛ موارد «نمونه» را می‌توانید حذف کنید.", "An offline information center. Add items with + and filter by category. No online news is shown; you can delete the sample items.")),
        HelpItem(tr("نقشه‌ها", "Maps"), tr("نقشه‌ی طرح‌واره‌ی آفلاین ایران با شهرهای اصلی. روی شهر ضربه بزنید تا مختصات، فاصله و جهت از تهران را ببینید. وضعیت هر شهر را خودتان تعیین می‌کنید.", "An offline schematic map of Iran with major cities. Tap a city to see coordinates, distance and bearing from Tehran. You set each city's status yourself.")),
        HelpItem(tr("برنامه‌ها", "Apps"), tr("فهرست برنامه‌های نصب‌شده. ضربه برای اجرا و نگه‌داشتن برای پین کردن یا برداشتن پین.", "Your installed apps. Tap to launch, long-press to pin or unpin.")),
        HelpItem(tr("اسناد", "Documents"), tr("با + فایل‌ها را از حافظه انتخاب کنید. فایل‌ها کپی نمی‌شوند و فقط پیوندشان نگه داشته می‌شود؛ اگر فایل جابه‌جا یا حذف شود باز نخواهد شد.", "Pick files with +. Files are not copied; only links are kept, so a moved or deleted file will not open.")),
        HelpItem(tr("گزارش‌ها", "Notes"), tr("یادداشت و گزارش متنی بنویسید، ویرایش و حذف کنید. همه چیز فقط روی همین گوشی ذخیره می‌شود.", "Write, edit and delete text notes. Everything is stored only on this phone.")),
        HelpItem(tr("تقویم و وظایف", "Calendar & tasks"), tr("تقویم شمسی (در حالت انگلیسی میلادی). وظیفه را با یا بدون تاریخ اضافه کنید؛ روزهای دارای وظیفه نقطه دارند.", "A Persian calendar (Gregorian in English mode). Add tasks with or without a date; days with open tasks show a dot.")),
        HelpItem(tr("مانیتور سیستم", "System monitor"), tr("وضعیت شبکه، باتری، رم و حافظه که مستقیم از اندروید خوانده می‌شود.", "Network, battery, RAM and storage read directly from Android.")),
        HelpItem(tr("صفحه‌ی اصلی پیش‌فرض", "Default home screen"), tr("با دکمه‌ی «تنظیم به‌عنوان لانچر» می‌توانید این برنامه را به‌جای صفحه‌ی اصلی گوشی انتخاب کنید و هر زمان به لانچر قبلی برگردید.", "Use the launcher button to choose this app as your home screen; you can switch back any time.")),
        HelpItem(tr("حریم خصوصی", "Privacy"), tr("برنامه مجوز اینترنت ندارد و هیچ داده‌ای ارسال نمی‌کند.", "The app has no internet permission and sends no data anywhere."))
    )

    Column(Modifier.fillMaxSize()) {
        TopBar(tr("تنظیمات", "Settings"))
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            GlassCard(Modifier.fillMaxWidth(), onClick = { nameDraft = state.userName; nameDialog = true }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(56.dp).clip(CircleShape).background(c.bgBottom.copy(alpha = 0.5f))
                            .border(1.5.dp, c.accent, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Outlined.Shield, contentDescription = null, tint = c.accent, modifier = Modifier.size(30.dp))
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(state.userName, color = c.text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text(tr("کاربر اصلی (برای تغییر نام ضربه بزنید)", "Primary user (tap to rename)"), color = c.sub, fontSize = 12.sp)
                    }
                    Icon(Icons.Outlined.Edit, contentDescription = null, tint = c.sub, modifier = Modifier.size(20.dp))
                }
            }

            SectionTitle(tr("ظاهر و نمایش", "Appearance"))
            SettingBlock(Icons.Outlined.Palette, tr("پوسته", "Theme")) {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassChip(tr("تیره (شیشه‌ای)", "Dark glass"), state.themeIndex == 0) { state.changeTheme(0) }
                    GlassChip(tr("روشن (شیشه‌ای)", "Light glass"), state.themeIndex == 1) { state.changeTheme(1) }
                    GlassChip(tr("زیتونی", "Olive"), state.themeIndex == 2) { state.changeTheme(2) }
                }
            }
            SettingBlock(Icons.Outlined.Language, tr("زبان", "Language")) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassChip("فارسی", state.lang == "fa") { state.changeLang("fa") }
                    GlassChip("English", state.lang == "en") { state.changeLang("en") }
                }
            }
            SettingBlock(Icons.Outlined.TextFields, tr("اندازه‌ی قلم", "Font size")) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassChip(tr("کوچک", "Small"), state.fontIndex == 0) { state.changeFont(0) }
                    GlassChip(tr("متوسط", "Medium"), state.fontIndex == 1) { state.changeFont(1) }
                    GlassChip(tr("بزرگ", "Large"), state.fontIndex == 2) { state.changeFont(2) }
                }
            }
            GlassCard(Modifier.fillMaxWidth(), padding = 12.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(tr("انیمیشن انتقال صفحه", "Page transition animation"), color = c.text, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text(tr("برای گوشی‌های ضعیف‌تر خاموش کنید", "Turn off on slower phones"), color = c.sub, fontSize = 12.sp)
                    }
                    Switch(
                        checked = state.animations, onCheckedChange = { state.changeAnimations(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = c.onAccent, checkedTrackColor = c.accent,
                            uncheckedThumbColor = c.sub, uncheckedTrackColor = c.field, uncheckedBorderColor = c.border
                        )
                    )
                }
            }

            SectionTitle(tr("لانچر و داده‌ها", "Launcher & data"))
            GlassCard(
                Modifier.fillMaxWidth(), padding = 12.dp,
                onClick = {
                    try {
                        ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
                    } catch (e: Exception) { }
                }
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Home, contentDescription = null, tint = c.accent, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(tr("تنظیم به‌عنوان لانچر", "Set as launcher"), color = c.text, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text(tr("باز کردن تنظیمات صفحه‌ی اصلی اندروید", "Opens Android's home app settings"), color = c.sub, fontSize = 12.sp)
                    }
                }
            }
            GlassCard(Modifier.fillMaxWidth(), padding = 12.dp, onClick = { clearDialog = true }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Delete, contentDescription = null, tint = c.danger, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(tr("پاک‌سازی همه‌ی داده‌ها", "Clear all data"), color = c.danger, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text(tr("یادداشت‌ها، وظایف، اسناد و اطلاعات از این گوشی پاک می‌شوند", "Notes, tasks, documents and info are erased from this phone"), color = c.sub, fontSize = 12.sp)
                    }
                }
            }

            SectionTitle(tr("درباره", "About"))
            GlassCard(Modifier.fillMaxWidth(), padding = 12.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(tr("نسخه", "Version"), color = c.sub, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    Text(nf(version), color = c.text, fontSize = 13.sp)
                }
            }

            SectionTitle(tr("راهنما", "Help"))
            for ((idx, h) in help.withIndex()) {
                GlassCard(Modifier.fillMaxWidth(), padding = 12.dp, onClick = { helpOpen = if (helpOpen == idx) -1 else idx }) {
                    Text(h.title, color = c.text, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    if (helpOpen == idx) {
                        Spacer(Modifier.height(6.dp))
                        Text(h.body, color = c.sub, fontSize = 13.sp)
                    }
                }
            }
            Text(
                tr("ساخته شده توسط صالح صفری ۱۶۵۱۳۸۹", "Built by Saleh Safari 1651389"),
                color = c.accent, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp)
            )
        }
    }

    if (nameDialog) {
        TlxDialog(
            title = tr("نام کاربر", "User name"),
            onDismiss = { nameDialog = false },
            confirmText = tr("ذخیره", "Save"),
            onConfirm = { if (nameDraft.isNotBlank()) state.changeName(nameDraft.trim()); nameDialog = false },
            dismissText = tr("انصراف", "Cancel")
        ) {
            GlassField(nameDraft, { nameDraft = it }, tr("نام", "Name"), Modifier.fillMaxWidth())
        }
    }
    if (clearDialog) {
        TlxDialog(
            title = tr("پاک‌سازی همه‌ی داده‌ها؟", "Clear all data?"),
            onDismiss = { clearDialog = false },
            confirmText = tr("پاک‌سازی", "Clear"),
            onConfirm = { state.clearAll(); clearDialog = false },
            dismissText = tr("انصراف", "Cancel")
        ) {
            Text(tr("این کار برگشت‌پذیر نیست. تنظیمات ظاهری حفظ می‌شوند.", "This cannot be undone. Appearance settings are kept."), color = c.sub, fontSize = 14.sp)
        }
    }
}
