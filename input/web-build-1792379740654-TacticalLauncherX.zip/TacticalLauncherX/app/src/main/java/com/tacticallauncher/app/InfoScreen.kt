package com.tacticallauncher.app

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun catName(i: Int): String = when (i) {
    0 -> tr("سیاسی", "Political")
    1 -> tr("نظامی", "Military")
    2 -> tr("اقتصادی", "Economic")
    else -> tr("فرهنگی", "Cultural")
}

fun catIcon(i: Int): ImageVector = when (i) {
    0 -> Icons.Outlined.Public
    1 -> Icons.Outlined.Shield
    2 -> Icons.Outlined.Payments
    else -> Icons.Outlined.Palette
}

fun catColor(i: Int): Color = when (i) {
    0 -> Color(0xFF5B8DEF)
    1 -> Color(0xFF6FBF73)
    2 -> Color(0xFFE5A93B)
    else -> Color(0xFFB07CE8)
}

@Composable
fun InfoScreen(state: AppState, go: (Route) -> Unit) {
    val c = LocalColors.current
    val fa = LocalLang.current == "fa"
    var filter by remember { mutableIntStateOf(-1) }
    var showAdd by remember { mutableStateOf(false) }
    var detail by remember { mutableStateOf<InfoItem?>(null) }
    val now = System.currentTimeMillis()
    val list = if (filter < 0) state.infos.toList() else state.infos.filter { it.category == filter }

    Column(Modifier.fillMaxSize()) {
        TopBar(tr("اطلاعات", "Information")) {
            IconBtn(Icons.Outlined.Place) { go(Route.Map) }
            IconBtn(Icons.Outlined.Add) { showAdd = true }
        }
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            GlassChip(tr("همه", "All"), filter < 0) { filter = -1 }
            for (i in 0..3) {
                GlassChip(catName(i), filter == i) { filter = i }
            }
        }
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (list.isEmpty()) {
                item {
                    EmptyState(Icons.Outlined.Visibility, tr("موردی ثبت نشده. با دکمه‌ی + اطلاعات خودتان را اضافه کنید.", "Nothing here yet. Use + to add your own items."))
                }
            }
            items(list, key = { it.id }) { info ->
                GlassCard(Modifier.fillMaxWidth(), padding = 10.dp, onClick = { detail = info }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(68.dp).clip(RoundedCornerShape(14.dp))
                                .background(Brush.verticalGradient(listOf(catColor(info.category).copy(alpha = 0.55f), catColor(info.category).copy(alpha = 0.15f)))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(catIcon(info.category), contentDescription = null, tint = c.text, modifier = Modifier.size(30.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(info.title, color = c.text, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(info.summary, color = c.sub, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Spacer(Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(catName(info.category), color = catColor(info.category), fontSize = 11.sp)
                                Text("  ·  " + relTime(fa, info.created, now), color = c.sub, fontSize = 11.sp)
                                if (info.sample) {
                                    Text("  ·  " + tr("نمونه", "Sample"), color = c.warn, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAdd) {
        AddInfoDialog(onDismiss = { showAdd = false }, onSave = { t, s, cat ->
            state.addInfo(t, s, cat)
            showAdd = false
        })
    }
    val d = detail
    if (d != null) {
        TlxDialog(
            title = d.title,
            onDismiss = { detail = null },
            confirmText = tr("حذف", "Delete"),
            onConfirm = { state.deleteInfo(d.id); detail = null },
            dismissText = tr("بستن", "Close")
        ) {
            Text(catName(d.category), color = catColor(d.category), fontSize = 13.sp)
            Text(d.summary, color = c.text, fontSize = 14.sp)
            Text(CalUtil.fmt(fa, d.created / 86400000L), color = c.sub, fontSize = 12.sp)
        }
    }
}

@Composable
private fun AddInfoDialog(onDismiss: () -> Unit, onSave: (String, String, Int) -> Unit) {
    var title by remember { mutableStateOf("") }
    var summary by remember { mutableStateOf("") }
    var cat by remember { mutableIntStateOf(0) }
    TlxDialog(
        title = tr("افزودن اطلاعات", "Add information"),
        onDismiss = onDismiss,
        confirmText = tr("ذخیره", "Save"),
        onConfirm = { if (title.isNotBlank()) onSave(title.trim(), summary.trim(), cat) },
        dismissText = tr("انصراف", "Cancel")
    ) {
        GlassField(title, { title = it }, tr("عنوان", "Title"), Modifier.fillMaxWidth())
        GlassField(summary, { summary = it }, tr("خلاصه", "Summary"), Modifier.fillMaxWidth(), singleLine = false, minLines = 3)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (i in 0..3) {
                GlassChip(catName(i), cat == i) { cat = i }
            }
        }
    }
}
