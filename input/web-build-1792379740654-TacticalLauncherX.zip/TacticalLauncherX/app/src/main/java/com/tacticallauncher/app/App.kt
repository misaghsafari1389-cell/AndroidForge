package com.tacticallauncher.app

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class Route(val tab: Int) {
    Home(0), Info(1), Apps(2), Settings(3),
    Map(1), Docs(2), Notes(0), Calendar(0), Tasks(0), Status(0)
}

@Composable
fun TlxApp(state: AppState) {
    val ctx = LocalContext.current
    val stack = remember { mutableStateListOf(Route.Home) }
    val current = stack.last()

    LaunchedEffect(Unit) {
        state.updateApps(withContext(Dispatchers.Default) { loadLauncherApps(ctx) })
    }

    val go: (Route) -> Unit = { r -> if (stack.last() != r) stack.add(r) }
    val back: () -> Unit = { if (stack.size > 1) stack.removeAt(stack.size - 1) }
    val selectTab: (Int) -> Unit = { i ->
        val r = when (i) {
            1 -> Route.Info
            2 -> Route.Apps
            3 -> Route.Settings
            else -> Route.Home
        }
        stack.clear()
        stack.add(r)
    }
    BackHandler(enabled = stack.size > 1) { back() }

    Box(Modifier.fillMaxSize()) {
        Backdrop(Modifier.fillMaxSize())
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                Crossfade(
                    targetState = current,
                    animationSpec = tween(if (state.animations) 220 else 0),
                    label = "route"
                ) { r ->
                    when (r) {
                        Route.Home -> HomeScreen(state, go)
                        Route.Info -> InfoScreen(state, go)
                        Route.Apps -> AppsScreen(state)
                        Route.Settings -> SettingsScreen(state)
                        Route.Map -> MapScreen(state, back)
                        Route.Docs -> DocsScreen(state, back)
                        Route.Notes -> NotesScreen(state, back)
                        Route.Calendar -> PlannerScreen(state, 0, back)
                        Route.Tasks -> PlannerScreen(state, 1, back)
                        Route.Status -> StatusScreen(state, back)
                    }
                }
            }
            BottomNav(current.tab, selectTab)
        }
    }
}
