package com.tacticallauncher.app

import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.Locale
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
private fun StatCard(icon: ImageVector, title: String, content: @Composable ColumnScope.() -> Unit) {
    val c = LocalColors.current
    GlassCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = c.accent, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(10.dp))
            Text(title, color = c.text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(10.dp))
        content()
    }
}

@Composable
private fun KeyVal(k: String, v: String) {
    val c = LocalColors.current
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Text(k, color = c.sub, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Text(v, color = c.text, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun StatusScreen(state: AppState, back: () -> Unit) {
    val c = LocalColors.current
    val ctx = LocalContext.current
    var s by remember { mutableStateOf(Sys.read(ctx)) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(3000L)
            s = withContext(Dispatchers.Default) { Sys.read(ctx) }
        }
    }
    val ramFrac = if (s.ramTotalMb > 0) s.ramUsedMb.toFloat() / s.ramTotalMb.toFloat() else 0f
    val storFrac = if (s.storTotalGb > 0.0) (s.storUsedGb / s.storTotalGb).toFloat() else 0f
    val netText = when (s.net) {
        0 -> tr("بدون اتصال", "Not connected")
        1 -> "Wi-Fi"
        2 -> tr("داده‌ی همراه", "Mobile data")
        else -> tr("متصل (نوع دیگر)", "Connected (other)")
    }
    val version = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "1.0.0"
    } catch (e: Exception) {
        "1.0.0"
    }

    Column(Modifier.fillMaxSize()) {
        TopBar(tr("شبکه و وضعیت برنامه", "Network & app status"), back)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            StatCard(Icons.Outlined.Wifi, tr("شبکه", "Network")) {
                KeyVal(tr("نوع اتصال", "Connection"), netText)
                KeyVal(
                    tr("دسترسی به اینترنت", "Internet access"),
                    if (s.net == 0) "—" else if (s.internetOk) tr("تأییدشده توسط سیستم", "Validated by system") else tr("تأیید نشده", "Not validated")
                )
                Text(
                    tr("این صفحه فقط وضعیتی را که اندروید گزارش می‌کند نشان می‌دهد؛ برنامه خودش هیچ درخواست اینترنتی نمی‌فرستد.",
                        "This only shows what Android reports. The app itself makes no internet requests."),
                    color = c.sub, fontSize = 11.sp
                )
            }
            StatCard(Icons.Outlined.BatteryFull, tr("باتری", "Battery")) {
                if (s.battery >= 0) {
                    Bar(s.battery / 100f, if (s.battery <= 20) c.danger else c.ok)
                    Spacer(Modifier.height(6.dp))
                    KeyVal(
                        tr("شارژ", "Level"),
                        nf("${s.battery}%") + if (s.charging) tr(" (در حال شارژ)", " (charging)") else ""
                    )
                } else {
                    Text("—", color = c.sub)
                }
            }
            StatCard(Icons.Outlined.Memory, tr("حافظه‌ی رم", "RAM")) {
                Bar(ramFrac, if (ramFrac > 0.85f) c.warn else c.accent)
                Spacer(Modifier.height(6.dp))
                KeyVal(tr("استفاده‌شده", "Used"), nf("${s.ramUsedMb}") + " / " + nf("${s.ramTotalMb}") + " MB")
            }
            StatCard(Icons.Outlined.Storage, tr("فضای ذخیره‌سازی", "Storage")) {
                Bar(storFrac, if (storFrac > 0.9f) c.warn else c.accent)
                Spacer(Modifier.height(6.dp))
                KeyVal(
                    tr("استفاده‌شده", "Used"),
                    nf(String.format(Locale.US, "%.1f", s.storUsedGb)) + " / " + nf(String.format(Locale.US, "%.1f", s.storTotalGb)) + " GB"
                )
            }
            StatCard(Icons.Outlined.Info, tr("وضعیت برنامه", "App status")) {
                KeyVal(tr("نسخه", "Version"), nf(version))
                KeyVal(tr("برنامه‌های نصب‌شده", "Installed apps"), nf(state.apps.size))
                KeyVal(tr("یادداشت‌ها", "Notes"), nf(state.notes.size))
                KeyVal(tr("وظایف", "Tasks"), nf(state.tasks.size))
                KeyVal(tr("اسناد", "Documents"), nf(state.docs.size))
                KeyVal(tr("موارد اطلاعاتی", "Info items"), nf(state.infos.size))
                KeyVal(tr("حافظه‌ی مصرفی برنامه", "App memory"), nf("${s.heapMb}") + " MB")
            }
            StatCard(Icons.Outlined.Settings, tr("دستگاه", "Device")) {
                KeyVal(tr("مدل", "Model"), Build.MODEL)
                KeyVal(tr("اندروید", "Android"), nf(Build.VERSION.RELEASE) + " (API " + nf(Build.VERSION.SDK_INT) + ")")
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}
