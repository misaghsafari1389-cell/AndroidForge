package com.tacticallauncher.app

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AppIcon(pkg: String, size: Dp) {
    val ctx = LocalContext.current
    val c = LocalColors.current
    val bmp = remember(pkg) {
        try {
            ctx.packageManager.getApplicationIcon(pkg).toBitmap(120, 120).asImageBitmap()
        } catch (e: Exception) {
            null
        }
    }
    if (bmp != null) {
        Image(bitmap = bmp, contentDescription = null, modifier = Modifier.size(size))
    } else {
        Box(Modifier.size(size).clip(RoundedCornerShape(12.dp)).background(c.field))
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppCell(app: AppEntry, pinned: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    val c = LocalColors.current
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .padding(vertical = 6.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box {
            AppIcon(app.pkg, 48.dp)
            if (pinned) {
                Box(Modifier.align(Alignment.TopEnd).size(13.dp).clip(CircleShape).background(c.accent))
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(app.label, color = c.text, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
    }
}

@Composable
fun AppsScreen(state: AppState) {
    val ctx = LocalContext.current
    val c = LocalColors.current
    var q by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        state.updateApps(withContext(Dispatchers.Default) { loadLauncherApps(ctx) })
    }
    val all = state.apps
    val filtered = if (q.isBlank()) all else all.filter { it.label.contains(q.trim(), true) }
    val pinnedApps = all.filter { it.pkg in state.pinned }
    val recentApps = state.recent.mapNotNull { p -> all.firstOrNull { it.pkg == p } }.take(4)

    Column(Modifier.fillMaxSize()) {
        TopBar(tr("برنامه‌ها", "Apps")) {
            Text(nf(all.size), color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(end = 8.dp))
        }
        GlassField(
            value = q, onValueChange = { q = it },
            placeholder = tr("جستجوی برنامه...", "Search apps..."),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            leading = Icons.Outlined.Search
        )
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
            contentPadding = PaddingValues(vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            if (q.isBlank() && pinnedApps.isNotEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) { SectionTitle(tr("پین‌شده", "Pinned"), Modifier.padding(horizontal = 4.dp)) }
                items(pinnedApps) { a ->
                    AppCell(a, true, { launchApp(ctx, state, a.pkg) }, { state.togglePin(a.pkg) })
                }
            }
            if (q.isBlank() && recentApps.isNotEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) { SectionTitle(tr("برنامه‌های اخیر", "Recent"), Modifier.padding(horizontal = 4.dp)) }
                items(recentApps) { a ->
                    AppCell(a, a.pkg in state.pinned, { launchApp(ctx, state, a.pkg) }, { state.togglePin(a.pkg) })
                }
            }
            item(span = { GridItemSpan(maxLineSpan) }) {
                SectionTitle(
                    tr("همه‌ی برنامه‌ها (نگه‌داشتن برای پین)", "All apps (long-press to pin)"),
                    Modifier.padding(horizontal = 4.dp)
                )
            }
            if (filtered.isEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    EmptyState(Icons.Outlined.Apps, tr("برنامه‌ای پیدا نشد", "No apps found"))
                }
            }
            items(filtered) { a ->
                AppCell(a, a.pkg in state.pinned, { launchApp(ctx, state, a.pkg) }, { state.togglePin(a.pkg) })
            }
        }
    }
}
