# TACTICAL LAUNCHER X (لانچر تاکتیکال)

Native Android app (Kotlin + Jetpack Compose), Persian RTL by default, English optional.
Same project layout as the EmojiCipher ZIP that built successfully on AndroidForge.

## Sections (all functional, offline)
- Home: clock/date, global search, shortcuts, upcoming tasks, device status
- Information: your own offline items by category (sample items are marked "نمونه" and can be deleted)
- Maps: offline schematic map of Iran, city coordinates/distance/bearing, manual status per city
- Apps: real list of installed apps, launch, long-press to pin, recents
- Documents: pick files from storage (links only), filter, open, remove
- Notes, Tasks, Calendar (Persian calendar; Gregorian in English mode)
- Network & app status: read from Android (network type, battery, RAM, storage)
- Settings: 3 themes, language, font size, animation toggle, set as launcher, clear data, Help

## What is NOT included on purpose
No live news, weather or online maps (no internet permission, no paid APIs).

## Build
- Android Gradle Plugin 8.5.2, Kotlin 1.9.24, Gradle 8.9, JDK 17
- minSdk 26 (Android 8.0), targetSdk 34
- Debug APK: `gradle assembleDebug` -> app/build/outputs/apk/debug/app-debug.apk
- Optional Vazirmatn font is downloaded by scripts/download_fonts.sh; without it the system font is used.

Status: see BUILD_STATUS.txt (not yet built).
