package com.glasslauncher.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Wallpaper editor: pinch to zoom, drag to move, or use the slider. The frame is the full screen, so what you
 * see here is exactly what the launcher shows. "Apply" renders a screen-sized bitmap.
 */
@Composable
fun WallpaperEditor(state: AppState, onDone: () -> Unit) {
    val src = state.pendingWallpaper
    if (src == null) {
        LaunchedEffect(Unit) { onDone() }
        return
    }
    val img = remember(src) { src.asImageBitmap() }
    var zoom by remember { mutableFloatStateOf(1f) }
    var off by remember { mutableStateOf(Offset.Zero) }
    var box by remember { mutableStateOf(IntSize.Zero) }
    BackHandler { state.cancelWallpaper(); onDone() }

    fun baseScale(): Float =
        if (box.width == 0 || box.height == 0) 1f else maxOf(box.width.toFloat() / src.width, box.height.toFloat() / src.height)

    fun clampOff(o: Offset, z: Float): Offset {
        val s = baseScale() * z
        val mx = maxOf(0f, (src.width * s - box.width) / 2f)
        val my = maxOf(0f, (src.height * s - box.height) / 2f)
        return Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
    }

    Box(
        Modifier.fillMaxSize().blockTouches().background(Color.Black).onSizeChanged { box = it }
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, gz, _ ->
                    val z = (zoom * gz).coerceIn(1f, 5f)
                    zoom = z
                    off = clampOff(off + pan, z)
                }
            }
    ) {
        Image(
            bitmap = img, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().graphicsLayer {
                scaleX = zoom
                scaleY = zoom
                translationX = off.x
                translationY = off.y
            }
        )
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0x99000000))
                .navigationBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Text(tr("بزرگ‌نمایی و جابه‌جایی با دو انگشت یا نوار زیر", "Pinch and drag, or use the slider"), color = Color.White, fontSize = 13.sp)
            Slider(value = zoom, onValueChange = { zoom = it; off = clampOff(off, it) }, valueRange = 1f..5f)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { state.cancelWallpaper(); onDone() }) { Text(tr("انصراف", "Cancel"), color = Color.White) }
                Button(onClick = {
                    if (box.width > 0 && box.height > 0) {
                        val s = baseScale() * zoom
                        val out = android.graphics.Bitmap.createBitmap(box.width, box.height, android.graphics.Bitmap.Config.ARGB_8888)
                        val m = android.graphics.Matrix()
                        m.postScale(s, s)
                        m.postTranslate((box.width - src.width * s) / 2f + off.x, (box.height - src.height * s) / 2f + off.y)
                        android.graphics.Canvas(out).drawBitmap(src, m, android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG))
                        state.commitWallpaper(out)
                    }
                    onDone()
                }) { Text(tr("اعمال والپیپر", "Apply wallpaper")) }
            }
        }
    }
}
