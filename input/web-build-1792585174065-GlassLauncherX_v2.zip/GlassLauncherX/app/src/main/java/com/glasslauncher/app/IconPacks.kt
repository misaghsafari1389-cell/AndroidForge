package com.glasslauncher.app

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.File

data class IconPackInfo(val pkg: String, val label: String)

/** Finds installed icon packs using the standard ADW / Nova / Apex / GO intents. */
fun findIconPacks(ctx: Context): List<IconPackInfo> {
    val pm = ctx.packageManager
    val found = LinkedHashMap<String, IconPackInfo>()
    val intents = listOf(
        Intent("org.adw.launcher.THEMES"),
        Intent("org.adw.ActivityStarter.THEMES"),
        Intent("com.novalauncher.THEME"),
        Intent("com.gau.go.launcherex.theme"),
        Intent(Intent.ACTION_MAIN).addCategory("com.anddoes.launcher.THEME")
    )
    for (i in intents) {
        val list = try { pm.queryIntentActivities(i, PackageManager.GET_META_DATA) } catch (e: Exception) { emptyList() }
        for (ri in list) {
            val p = ri.activityInfo.packageName
            if (p !in found) found[p] = IconPackInfo(p, ri.loadLabel(pm).toString())
        }
    }
    return found.values.sortedBy { it.label.lowercase() }
}

/** Reads the <item component="ComponentInfo{pkg/cls}" drawable="name"/> entries of an appfilter.xml. */
fun readAppFilter(parser: XmlPullParser): HashMap<String, String> {
    val map = HashMap<String, String>()
    var ev = parser.eventType
    while (ev != XmlPullParser.END_DOCUMENT) {
        if (ev == XmlPullParser.START_TAG && parser.name == "item") {
            val comp = parser.getAttributeValue(null, "component")
            val dr = parser.getAttributeValue(null, "drawable")
            if (comp != null && dr != null && comp.startsWith("ComponentInfo{") && comp.endsWith("}")) {
                val inner = comp.substring(14, comp.length - 1)
                val slash = inner.indexOf('/')
                if (slash > 0) {
                    val p = inner.substring(0, slash)
                    var cls = inner.substring(slash + 1)
                    if (cls.startsWith(".")) cls = p + cls
                    if (!map.containsKey("$p/$cls")) map["$p/$cls"] = dr
                }
            }
        }
        ev = parser.next()
    }
    return map
}

/** An installed icon-pack app: reads res/xml/appfilter.xml (or assets/appfilter.xml). */
class IconPack(ctx: Context, private val pkg: String) {
    private val res: Resources = ctx.packageManager.getResourcesForApplication(pkg)
    private val map = HashMap<String, String>()

    init {
        try {
            val id = res.getIdentifier("appfilter", "xml", pkg)
            val parser: XmlPullParser = if (id != 0) {
                res.getXml(id)
            } else {
                val p = XmlPullParserFactory.newInstance().newPullParser()
                p.setInput(res.assets.open("appfilter.xml"), "utf-8")
                p
            }
            map.putAll(readAppFilter(parser))
        } catch (e: Exception) { }
    }

    fun iconFor(cn: ComponentName): Drawable? {
        val name = map[cn.packageName + "/" + cn.className] ?: return null
        val id = res.getIdentifier(name, "drawable", pkg)
        if (id == 0) return null
        return try { res.getDrawable(id, null) } catch (e: Exception) { null }
    }
}

/**
 * An icon pack imported from a ZIP file (folder of images + optional plain-text appfilter.xml).
 * Without a readable appfilter.xml, icons are matched by file name: com_whatsapp.png, com.whatsapp.png, whatsapp.png.
 */
class ZipPack(dir: File) {
    private val filter = HashMap<String, String>()
    private val images = HashMap<String, File>()

    init {
        try {
            dir.listFiles()?.forEach { f ->
                if (f.name == "appfilter.xml") {
                    try {
                        val p = XmlPullParserFactory.newInstance().newPullParser()
                        p.setInput(f.inputStream(), "utf-8")
                        filter.putAll(readAppFilter(p))
                    } catch (e: Exception) { }
                } else if (f.name.endsWith(".img")) {
                    images[f.nameWithoutExtension] = f
                }
            }
        } catch (e: Exception) { }
    }

    fun iconFor(app: AppEntry): Bitmap? {
        val names = ArrayList<String>()
        filter[app.pkg + "/" + app.cls]?.let { names.add(it.lowercase()) }
        names.add(app.pkg.lowercase().replace('.', '_'))
        names.add(app.pkg.lowercase())
        names.add(app.label.lowercase().replace(Regex("[^a-z0-9]"), ""))
        for (n in names) {
            val f = images[n]
            if (f != null) {
                val b = try { decodeSampled(f.path, 256) } catch (e: Exception) { null }
                if (b != null) return b
            }
        }
        return null
    }
}

/** Draws any launcher icon as a full iOS-style tile (adaptive layers are enlarged to fill the squircle). */
fun iosIcon(d: Drawable, px: Int): Bitmap {
    val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    if (d is AdaptiveIconDrawable) {
        val inset = (px * 0.2f).toInt()
        val bg = d.background
        val fg = d.foreground
        if (bg != null) {
            bg.setBounds(-inset, -inset, px + inset, px + inset)
            bg.draw(c)
        } else {
            c.drawColor(0xFFFFFFFF.toInt())
        }
        if (fg != null) {
            fg.setBounds(-inset, -inset, px + inset, px + inset)
            fg.draw(c)
        }
    } else {
        c.drawColor(0xF2FFFFFF.toInt())
        val p = (px * 0.12f).toInt()
        d.setBounds(p, p, px - p, px - p)
        d.draw(c)
    }
    return bmp
}
