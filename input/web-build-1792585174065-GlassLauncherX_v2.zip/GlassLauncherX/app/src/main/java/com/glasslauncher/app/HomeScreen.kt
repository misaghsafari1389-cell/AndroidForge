package com.glasslauncher.app

import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * progress(): 0 = home, 1 = app list fully open (read inside graphicsLayer so the animation never recomposes).
 * onSwipe(dy) / onSwipeEnd() let the parent move the app list under the finger.
 */
@Composable
fun HomeScreen(
    state: AppState,
    progress: () -> Float,
    onSwipe: (Float) -> Unit,
    onSwipeEnd: () -> Unit,
    openSettings: () -> Unit
) {
    val ctx = LocalContext.current
    val c = LocalColors.current
    val fa = state.lang == "fa"
    var menuApp by remember { mutableStateOf<AppEntry?>(null) }
    val now by produceState(System.currentTimeMillis()) {
        while (true) { value = System.currentTimeMillis(); delay(15_000L) }
    }
    val timeStr = remember(now, fa) {
        val s = SimpleDateFormat("HH:mm", Locale.US).format(Date(now))
        if (fa) faDigits(s) else s
    }
    val dateStr = remember(now, fa) { CalUtil.fmtLong(fa, CalUtil.today()) }
    val vis = state.visibleApps
    val pinnedApps = state.pinned.mapNotNull { p -> vis.firstOrNull { it.pkg == p } }
    val dockApps = state.dock.mapNotNull { p -> vis.firstOrNull { it.pkg == p } }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragEnd = { onSwipeEnd() },
                    onDragCancel = { onSwipeEnd() },
                    onVerticalDrag = { _, dy -> onSwipe(dy) }
                )
            }
            .padding(horizontal = 18.dp)
    ) {
        Column(
            Modifier.weight(1f).fillMaxWidth().graphicsLayer {
                val p = progress()
                alpha = 1f - 0.7f * p
                scaleX = 1f - 0.05f * p
                scaleY = 1f - 0.05f * p
            }
        ) {
            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth().glass(30.dp).padding(horizontal = 22.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(timeStr, color = c.text, fontSize = 52.sp, fontWeight = FontWeight.Light)
                    Text(dateStr, color = c.sub, fontSize = 14.sp)
                }
                IconButton(onClick = openSettings) {
                    Icon(Icons.Outlined.Settings, contentDescription = null, tint = c.text)
                }
            }
            Spacer(Modifier.height(22.dp))
            pinnedApps.chunked(state.columns).forEach { row ->
                Row(Modifier.fillMaxWidth()) {
                    row.forEach { a ->
                        AppTile(a, state, Modifier.weight(1f), onClick = { launchApp(ctx, a) }, onLong = { menuApp = a })
                    }
                    repeat(state.columns - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
        // dock: slides down and fades while the app list rises, comes back up when it closes
        LazyRow(
            Modifier.fillMaxWidth().graphicsLayer {
                val p = progress()
                translationY = p * 170.dp.toPx()
                alpha = 1f - p
            }.glass(34.dp),
            contentPadding = PaddingValues(horizontal = 18.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items(dockApps, key = { it.pkg + "/" + it.cls }) { a ->
                DockIcon(a, state, onClick = { launchApp(ctx, a) }, onLong = { menuApp = a })
            }
        }
        Spacer(Modifier.height(10.dp))
    }
    menuApp?.let { AppMenu(it, state) { menuApp = null } }
}
