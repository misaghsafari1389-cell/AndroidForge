package com.glasslauncher.app

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class AppEntry(val label: String, val pkg: String, val cls: String, val cat: Int, val sys: Boolean = false)

/** kind: 0 = photo, 1 = video, 2 = document. */
data class VaultItem(val id: String, val kind: Int, val name: String, val mime: String, val file: String, val added: Long)

/** Drawer category groups: 0 social, 1 games, 2 media, 3 productivity, 4 other. */
fun categoryOf(cat: Int): Int = when (cat) {
    ApplicationInfo.CATEGORY_SOCIAL -> 0
    ApplicationInfo.CATEGORY_GAME -> 1
    ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO, ApplicationInfo.CATEGORY_IMAGE -> 2
    ApplicationInfo.CATEGORY_PRODUCTIVITY, ApplicationInfo.CATEGORY_NEWS, ApplicationInfo.CATEGORY_MAPS -> 3
    else -> 4
}

fun loadLauncherApps(ctx: Context): List<AppEntry> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map {
            val cat = try { it.activityInfo.applicationInfo.category } catch (e: Exception) { ApplicationInfo.CATEGORY_UNDEFINED }
            val sys = try { (it.activityInfo.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0 } catch (e: Exception) { false }
            AppEntry(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.activityInfo.name, cat, sys)
        }
        .sortedBy { it.label.lowercase() }
}

fun launchApp(ctx: Context, app: AppEntry) {
    try {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(ComponentName(app.pkg, app.cls))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        ctx.startActivity(i)
    } catch (e: Exception) { }
}

/** All data lives in SharedPreferences and the app's private storage. Nothing is sent anywhere. */
class AppState(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("glx_prefs", Context.MODE_PRIVATE)

    // ---- settings ----
    var themeIndex by mutableIntStateOf(prefs.getInt("theme", 0)); private set
    var lang by mutableStateOf(prefs.getString("lang", "fa") ?: "fa"); private set
    var glass by mutableFloatStateOf(prefs.getFloat("glass", 1f)); private set
    var iconSize by mutableIntStateOf(prefs.getInt("icon", 58)); private set
    var columns by mutableIntStateOf(prefs.getInt("cols", 4)); private set
    var showLabels by mutableStateOf(prefs.getBoolean("labels", true)); private set
    var wallBlur by mutableStateOf(prefs.getBoolean("wblur", false)); private set
    var iconPackPkg by mutableStateOf(prefs.getString("pack", "") ?: ""); private set
    var iconVersion by mutableIntStateOf(0); private set
    var wallpaper by mutableStateOf<ImageBitmap?>(null); private set
    var pendingWallpaper by mutableStateOf<Bitmap?>(null); private set

    // ---- data ----
    var apps by mutableStateOf<List<AppEntry>>(emptyList()); private set
    var packs by mutableStateOf<List<IconPackInfo>>(emptyList()); private set
    val zipPacks = mutableStateListOf<IconPackInfo>()
    val pinned = mutableStateListOf<String>()
    val dock = mutableStateListOf<String>()
    val hidden = mutableStateListOf<String>()
    val vault = mutableStateListOf<VaultItem>()
    var patternHash by mutableStateOf<String?>(prefs.getString("pat", null)); private set

    // ---- lifecycle signals (MainActivity -> UI) ----
    var lockTick by mutableIntStateOf(0); private set
    var resumeTick by mutableIntStateOf(0)
    var homeTick by mutableIntStateOf(0)
    @Volatile var suppressLock = false

    private val cache = HashMap<String, ImageBitmap>()
    private var pack: IconPack? = null
    private var zip: ZipPack? = null

    init {
        loadList("pinned", pinned)
        loadList("dock", dock)
        loadList("hidden", hidden)
        loadVault()
        loadZipPacks()
        loadPack(iconPackPkg)
        val f = File(ctx.filesDir, "wall.img")
        if (f.exists()) wallpaper = decodeSampled(f.path, 1600)?.asImageBitmap()
    }

    // ---- simple settings ----
    fun changeTheme(i: Int) { themeIndex = i; prefs.edit().putInt("theme", i).apply() }
    fun changeLang(l: String) { lang = l; prefs.edit().putString("lang", l).apply() }
    fun changeGlass(v: Float) { glass = v; prefs.edit().putFloat("glass", v).apply() }
    fun changeIconSize(v: Int) { iconSize = v; prefs.edit().putInt("icon", v).apply() }
    fun changeColumns(v: Int) { columns = v; prefs.edit().putInt("cols", v).apply() }
    fun changeLabels(v: Boolean) { showLabels = v; prefs.edit().putBoolean("labels", v).apply() }
    fun changeWallBlur(v: Boolean) { wallBlur = v; prefs.edit().putBoolean("wblur", v).apply() }
    fun requestLock() { if (!suppressLock) lockTick++ }

    // ---- apps ----
    val visibleApps: List<AppEntry> get() = apps.filter { it.pkg !in hidden }

    fun updateApps(list: List<AppEntry>) {
        apps = list
        if (!prefs.contains("dock")) seedDock()
    }

    private fun seedDock() {
        val want = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        val list = ArrayList<String>()
        for (i in want) {
            val p = try { ctx.packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName } catch (e: Exception) { null }
            if (p != null && apps.any { it.pkg == p } && p !in list) list.add(p)
        }
        dock.clear(); dock.addAll(list); saveList("dock", dock)
    }

    fun togglePin(pkg: String) { if (pkg in pinned) pinned.remove(pkg) else pinned.add(pkg); saveList("pinned", pinned) }
    fun toggleDock(pkg: String) {
        if (pkg in dock) dock.remove(pkg) else if (dock.size < 12) dock.add(pkg)
        saveList("dock", dock)
    }
    fun setHidden(pkg: String, v: Boolean) {
        if (v && pkg !in hidden) hidden.add(pkg)
        if (!v) hidden.remove(pkg)
        saveList("hidden", hidden)
    }

    private fun loadList(key: String, into: MutableList<String>) {
        into.clear()
        (prefs.getString(key, "") ?: "").split("\n").filter { it.isNotBlank() }.forEach { into.add(it) }
    }
    private fun saveList(key: String, l: List<String>) { prefs.edit().putString(key, l.joinToString("\n")).apply() }

    // ---- icons / icon packs ----
    fun refreshPacks() { packs = findIconPacks(ctx) }

    private fun loadPack(pkg: String) {
        pack = null
        zip = null
        if (pkg.startsWith("zip:")) zip = ZipPack(File(ctx.filesDir, "packs/" + pkg.substring(4)))
        else if (pkg.isNotEmpty()) pack = try { IconPack(ctx, pkg) } catch (e: Exception) { null }
    }

    fun setIconPack(pkg: String) {
        iconPackPkg = pkg
        prefs.edit().putString("pack", pkg).apply()
        loadPack(pkg)
        cache.clear()
        iconVersion++
    }

    // ---- icon packs imported from a ZIP file ----
    private fun loadZipPacks() {
        zipPacks.clear()
        File(ctx.filesDir, "packs").listFiles()?.filter { it.isDirectory }?.sortedBy { it.name }?.forEach { d ->
            val label = try { File(d, "_label.txt").readText() } catch (e: Exception) { d.name }
            zipPacks.add(IconPackInfo("zip:" + d.name, label))
        }
    }

    /** Extracts icons (png/webp/jpg) and appfilter.xml from a ZIP. Returns the new pack id ("zip:..") or null. */
    suspend fun importZipPack(uri: Uri): String? = withContext(Dispatchers.IO) {
        val shown = (queryName(uri) ?: "pack").removeSuffix(".zip").removeSuffix(".ZIP")
        val id = "p" + System.currentTimeMillis()
        val dir = File(ctx.filesDir, "packs/" + id)
        var n = 0
        try {
            dir.mkdirs()
            val sizes = HashMap<String, Int>()
            var filterSize = -1
            val input = ctx.contentResolver.openInputStream(uri) ?: return@withContext null
            java.util.zip.ZipInputStream(input).use { zin ->
                var e = zin.nextEntry
                var guard = 0
                while (e != null && guard < 8000) {
                    guard++
                    if (!e.isDirectory) {
                        val base = e.name.substringAfterLast('/')
                        val lower = base.lowercase()
                        val ext = lower.substringAfterLast('.', "")
                        val isFilter = lower == "appfilter.xml"
                        val isImg = ext == "png" || ext == "webp" || ext == "jpg" || ext == "jpeg"
                        if (isFilter || isImg) {
                            val bytes = zin.readBytes()
                            if (bytes.size in 1..4_000_000) {
                                if (isFilter) {
                                    if (bytes.size > filterSize) { filterSize = bytes.size; File(dir, "appfilter.xml").writeBytes(bytes) }
                                } else {
                                    val key = base.substringBeforeLast('.').lowercase()
                                    if (bytes.size > (sizes[key] ?: -1)) {
                                        if (!sizes.containsKey(key)) n++
                                        sizes[key] = bytes.size
                                        File(dir, "$key.img").writeBytes(bytes)
                                    }
                                }
                            }
                        }
                    }
                    e = zin.nextEntry
                }
            }
        } catch (ex: Exception) { n = 0 }
        if (n == 0) { dir.deleteRecursively(); return@withContext null }
        File(dir, "_label.txt").writeText(shown)
        zipPacks.add(IconPackInfo("zip:$id", shown))
        "zip:$id"
    }

    fun deleteZipPack(pkg: String) {
        if (iconPackPkg == pkg) setIconPack("")
        File(ctx.filesDir, "packs/" + pkg.removePrefix("zip:")).deleteRecursively()
        zipPacks.removeAll { it.pkg == pkg }
    }

    fun iconFor(app: AppEntry): ImageBitmap {
        val key = app.pkg + "/" + app.cls
        cache[key]?.let { return it }
        val px = 192
        var bmp: Bitmap? = null
        try {
            val cn = ComponentName(app.pkg, app.cls)
            val z = zip?.iconFor(app)
            val d = if (z == null) pack?.iconFor(cn) else null
            bmp = if (z != null) z else if (d != null) d.toBitmap(px, px) else iosIcon(ctx.packageManager.getActivityIcon(cn), px)
        } catch (e: Exception) { }
        val out = (bmp ?: Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)).asImageBitmap()
        cache[key] = out
        return out
    }

    // ---- wallpaper ----
    /** Step 1: load the picked photo for the zoom/position editor. */
    suspend fun beginWallpaper(uri: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            val f = File(ctx.filesDir, "wall_tmp.img")
            ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            val b = decodeSampled(f.path, 2200)
            pendingWallpaper = b
            f.delete()
            b != null
        } catch (e: Exception) { false }
    }

    /** Step 2: the editor hands over the final, screen-sized bitmap. */
    fun commitWallpaper(bmp: Bitmap) {
        try {
            File(ctx.filesDir, "wall.img").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        } catch (e: Exception) { }
        wallpaper = bmp.asImageBitmap()
        pendingWallpaper = null
    }

    fun cancelWallpaper() { pendingWallpaper = null }

    fun clearWallpaper() { File(ctx.filesDir, "wall.img").delete(); wallpaper = null }

    // ---- vault pattern (stored only as a salted hash) ----
    private fun hashOf(p: String) = sha256Hex("glx::" + p)
    fun setPattern(p: String) { patternHash = hashOf(p); prefs.edit().putString("pat", patternHash).apply() }
    fun clearPattern() { patternHash = null; prefs.edit().remove("pat").apply() }
    fun checkPattern(p: String): Boolean = patternHash != null && patternHash == hashOf(p)

    // ---- vault files (copied into app-private storage) ----
    private fun vaultDir(): File = File(ctx.filesDir, "vault").apply { mkdirs() }
    fun vaultFile(it: VaultItem): File = File(vaultDir(), it.file)

    private fun queryName(u: Uri): String? = try {
        ctx.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (e: Exception) { null }

    /** Copies picked files into the vault. Returns (imported, originalsDeleted). */
    suspend fun importUris(uris: List<Uri>, kind: Int): Pair<Int, Int> = withContext(Dispatchers.IO) {
        var ok = 0
        var del = 0
        val added = ArrayList<VaultItem>()
        for (u in uris) {
            try {
                val name = queryName(u) ?: "file"
                val mime = ctx.contentResolver.getType(u) ?: "*/*"
                val id = UUID.randomUUID().toString()
                val fname = id + "_" + name.replace(Regex("[^A-Za-z0-9._-]"), "_")
                val out = File(vaultDir(), fname)
                val input = ctx.contentResolver.openInputStream(u) ?: continue
                input.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
                added.add(VaultItem(id, kind, name, mime, fname, System.currentTimeMillis()))
                ok++
                try { if (DocumentsContract.deleteDocument(ctx.contentResolver, u)) del++ } catch (e: Exception) { }
            } catch (e: Exception) { }
        }
        vault.addAll(0, added)
        persistVault()
        Pair(ok, del)
    }

    fun removeVault(item: VaultItem) {
        vaultFile(item).delete()
        vault.removeAll { it.id == item.id }
        persistVault()
    }

    private fun persistVault() {
        val arr = JSONArray()
        for (v in vault) {
            arr.put(JSONObject().put("id", v.id).put("k", v.kind).put("n", v.name).put("m", v.mime).put("f", v.file).put("t", v.added))
        }
        prefs.edit().putString("vault", arr.toString()).apply()
    }

    private fun loadVault() {
        vault.clear()
        try {
            val arr = JSONArray(prefs.getString("vault", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                vault.add(VaultItem(o.getString("id"), o.getInt("k"), o.getString("n"), o.getString("m"), o.getString("f"), o.getLong("t")))
            }
        } catch (e: Exception) { }
    }
}
