package com.glasslauncher.app

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class Route { Home, Settings, Lock, Vault, Wallpaper }

@Composable
fun GlApp(state: AppState) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var route by remember { mutableStateOf(Route.Home) }
    var lockMode by remember { mutableIntStateOf(0) }

    // app-list position: 0 = closed (home), 1 = fully open. dragP >= 0 while a finger is moving it.
    val prog = remember { Animatable(0f) }
    var dragP by remember { mutableFloatStateOf(-1f) }
    var h by remember { mutableFloatStateOf(1f) }
    val cur: () -> Float = { if (dragP >= 0f) dragP else prog.value }
    val open by remember { derivedStateOf { (if (dragP >= 0f) dragP else prog.value) > 0.5f } }

    fun settle(target: Float) {
        scope.launch {
            if (dragP >= 0f) { prog.snapTo(dragP); dragP = -1f }
            prog.animateTo(target, spring(dampingRatio = 0.86f, stiffness = 380f))
        }
    }
    // dy > 0 = finger moving down (closing), dy < 0 = moving up (opening)
    fun drag(dy: Float) { dragP = (cur() - dy / (h * 0.55f)).coerceIn(0f, 1f) }
    fun release(vy: Float) {
        if (dragP < 0f) return
        val p = dragP
        settle(if (vy > 1400f) 0f else if (vy < -1400f) 1f else if (p > 0.5f) 1f else 0f)
    }

    // (re)load the installed-apps list at start and whenever the launcher returns to the foreground
    LaunchedEffect(state.resumeTick) {
        state.updateApps(withContext(Dispatchers.Default) { loadLauncherApps(ctx) })
    }
    // leaving the app closes the vault
    LaunchedEffect(state.lockTick) {
        if (route == Route.Vault || route == Route.Lock) route = Route.Home
    }
    // Home button: back to the home screen
    LaunchedEffect(state.homeTick) {
        if (state.homeTick > 0) { route = Route.Home; settle(0f) }
    }
    BackHandler(enabled = open && route == Route.Home) { settle(0f) }

    Box(Modifier.fillMaxSize().onSizeChanged { h = it.height.toFloat() }) {
        Backdrop(state, Modifier.fillMaxSize())
        HomeScreen(
            state, progress = { cur() },
            onSwipe = { dy -> drag(dy) },
            onSwipeEnd = { release(if (cur() > 0.25f) -2000f else 2000f) },
            openSettings = { route = Route.Settings }
        )
        Box(
            Modifier.fillMaxSize().graphicsLayer {
                val p = cur()
                translationY = (1f - p) * size.height
                alpha = (p * 2.5f).coerceIn(0f, 1f)
            }
        ) {
            DrawerScreen(
                state, open = open,
                isPulling = { dragP >= 0f },
                onPull = { dy -> drag(dy) },
                onRelease = { vy -> release(vy) },
                onVault = { lockMode = 0; route = Route.Lock }
            )
        }
        AnimatedVisibility(visible = route == Route.Settings, enter = fadeIn(tween(180)), exit = fadeOut(tween(150))) {
            SettingsScreen(
                state, onBack = { route = Route.Home },
                onChangePattern = { lockMode = 1; route = Route.Lock },
                onEditWallpaper = { route = Route.Wallpaper }
            )
        }
        if (route == Route.Wallpaper) {
            WallpaperEditor(state, onDone = { route = Route.Settings })
        }
        if (route == Route.Lock) {
            PatternGate(
                state, lockMode,
                onSuccess = { route = if (lockMode == 1) Route.Settings else Route.Vault },
                onCancel = { route = if (lockMode == 1) Route.Settings else Route.Home }
            )
        }
        if (route == Route.Vault) {
            VaultScreen(state, onClose = { route = Route.Home })
        }
    }
}
