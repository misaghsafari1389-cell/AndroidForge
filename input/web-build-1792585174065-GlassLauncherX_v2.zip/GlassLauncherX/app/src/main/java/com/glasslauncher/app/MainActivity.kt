package com.glasslauncher.app

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge

class MainActivity : ComponentActivity() {
    private lateinit var state: AppState

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        state = AppState(applicationContext)
        setContent { GlTheme(state) { GlApp(state) } }
        handleApply(intent)
    }

    /** Some icon-pack apps send an "apply" intent (Nova / ADW / Apex style). Returns true if it was one. */
    private fun handleApply(i: Intent?): Boolean {
        if (i == null) return false
        val pkg: String? = when (i.action) {
            "com.teslacoilsw.launcher.APPLY_ICON_THEME" -> i.getStringExtra("com.teslacoilsw.launcher.extra.ICON_THEME_PACKAGE")
            "org.adw.launcher.SET_THEME" -> i.getStringExtra("org.adw.launcher.theme.NAME")
            "com.anddoes.launcher.SET_THEME" -> i.getStringExtra("com.anddoes.launcher.THEME_PACKAGE_NAME")
            else -> null
        }
        if (pkg.isNullOrBlank()) return false
        state.setIconPack(pkg)
        return true
    }

    override fun onResume() {
        super.onResume()
        state.suppressLock = false
        state.resumeTick++
    }

    override fun onStop() {
        super.onStop()
        state.requestLock()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (!handleApply(intent)) {
            // Home button pressed while the launcher is already running
            state.homeTick++
        }
    }
}
