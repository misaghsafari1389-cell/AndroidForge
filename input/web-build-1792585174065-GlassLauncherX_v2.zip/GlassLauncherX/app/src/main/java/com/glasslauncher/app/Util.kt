package com.glasslauncher.app

import java.time.LocalDate
import java.time.YearMonth
import java.util.Locale

fun faDigits(s: String): String {
    val sb = StringBuilder(s.length)
    for (c in s) {
        if (c in '0'..'9') sb.append('۰' + (c - '0')) else sb.append(c)
    }
    return sb.toString()
}

fun pad2(n: Int): String = if (n < 10) "0$n" else n.toString()

fun fmtSize(b: Long): String {
    if (b <= 0L) return "—"
    val kb = b / 1024.0
    if (kb < 1024.0) return String.format(Locale.US, "%.0f KB", kb)
    val mb = kb / 1024.0
    if (mb < 1024.0) return String.format(Locale.US, "%.1f MB", mb)
    return String.format(Locale.US, "%.2f GB", mb / 1024.0)
}

fun relTime(fa: Boolean, thenMs: Long, nowMs: Long): String {
    val min = ((nowMs - thenMs) / 60000L).coerceAtLeast(0L)
    val s: String = when {
        min < 1L -> if (fa) "اکنون" else "now"
        min < 60L -> if (fa) "$min دقیقه پیش" else "$min min ago"
        min < 1440L -> if (fa) "${min / 60} ساعت پیش" else "${min / 60} h ago"
        else -> if (fa) "${min / 1440} روز پیش" else "${min / 1440} d ago"
    }
    return if (fa) faDigits(s) else s
}

/** Persian (Jalali) <-> Gregorian conversion, pure arithmetic (no platform calendar APIs). */
object CalUtil {
    private val breaks = intArrayOf(
        -61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181,
        1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178
    )
    private const val EPOCH_JDN = 2440588

    private class JalCal(val leap: Int, val gy: Int, val march: Int)

    private fun jalCal(jy: Int): JalCal {
        val gy = jy + 621
        var leapJ = -14
        var jp = breaks[0]
        var jump = 0
        for (i in 1 until breaks.size) {
            val jm = breaks[i]
            jump = jm - jp
            if (jy < jm) break
            leapJ += (jump / 33) * 8 + ((jump % 33) / 4)
            jp = jm
        }
        var n = jy - jp
        leapJ += (n / 33) * 8 + (((n % 33) + 3) / 4)
        if ((jump % 33) == 4 && jump - n == 4) leapJ += 1
        val leapG = (gy / 4) - ((((gy / 100) + 1) * 3) / 4) - 150
        val march = 20 + leapJ - leapG
        if (jump - n < 6) n = n - jump + ((jump + 4) / 33) * 33
        var leap = (((n + 1) % 33) - 1) % 4
        if (leap == -1) leap = 4
        return JalCal(leap, gy, march)
    }

    private fun g2d(gy: Int, gm: Int, gd: Int): Int {
        var d = (((gy + (gm - 8) / 6 + 100100) * 1461) / 4) + ((153 * ((gm + 9) % 12) + 2) / 5) + gd - 34840408
        d = d - ((((gy + 100100 + (gm - 8) / 6) / 100) * 3) / 4) + 752
        return d
    }

    private fun d2g(jdn: Int): IntArray {
        var j = 4 * jdn + 139361631
        j += ((((4 * jdn + 183187720) / 146097) * 3) / 4) * 4 - 3908
        val i = ((j % 1461) / 4) * 5 + 308
        val gd = ((i % 153) / 5) + 1
        val gm = ((i / 153) % 12) + 1
        val gy = (j / 1461) - 100100 + ((8 - gm) / 6)
        return intArrayOf(gy, gm, gd)
    }

    private fun j2d(jy: Int, jm: Int, jd: Int): Int {
        val r = jalCal(jy)
        return g2d(r.gy, 3, r.march) + (jm - 1) * 31 - (jm / 7) * (jm - 7) + jd - 1
    }

    private fun d2j(jdn: Int): IntArray {
        val gy = d2g(jdn)[0]
        var jy = gy - 621
        val r = jalCal(jy)
        val jdn1f = g2d(gy, 3, r.march)
        var k = jdn - jdn1f
        if (k >= 0) {
            if (k <= 185) return intArrayOf(jy, 1 + k / 31, k % 31 + 1)
            k -= 186
        } else {
            jy -= 1
            k += 179
            if (r.leap == 1) k += 1
        }
        return intArrayOf(jy, 7 + k / 30, k % 30 + 1)
    }

    val faMonths = listOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    )
    val enMonths = listOf(
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    )
    private val faWeek = listOf("دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه", "یکشنبه")
    private val enWeek = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")

    fun today(): Long = LocalDate.now().toEpochDay()

    fun jalali(e: Long): IntArray = d2j(e.toInt() + EPOCH_JDN)

    fun fromJalali(y: Int, m: Int, d: Int): Long = (j2d(y, m, d) - EPOCH_JDN).toLong()

    /** year, month (1-12), day for the active calendar system. */
    fun ymd(fa: Boolean, e: Long): IntArray {
        if (fa) return jalali(e)
        val d = LocalDate.ofEpochDay(e)
        return intArrayOf(d.year, d.monthValue, d.dayOfMonth)
    }

    fun toEpoch(fa: Boolean, y: Int, m: Int, d: Int): Long =
        if (fa) fromJalali(y, m, d) else LocalDate.of(y, m, d).toEpochDay()

    fun monthLen(fa: Boolean, y: Int, m: Int): Int {
        if (!fa) return YearMonth.of(y, m).lengthOfMonth()
        if (m <= 6) return 31
        if (m <= 11) return 30
        return (fromJalali(y + 1, 1, 1) - fromJalali(y, 12, 1)).toInt()
    }

    /** Column index (0-6) of a date in the grid: Saturday-first for Persian, Sunday-first otherwise. */
    fun weekOffset(fa: Boolean, e: Long): Int {
        val v = LocalDate.ofEpochDay(e).dayOfWeek.value
        return if (fa) (v + 1) % 7 else v % 7
    }

    fun shiftMonth(y: Int, m: Int, delta: Int): IntArray {
        val idx = y * 12 + (m - 1) + delta
        return intArrayOf(idx / 12, idx % 12 + 1)
    }

    fun monthName(fa: Boolean, m: Int): String = if (fa) faMonths[m - 1] else enMonths[m - 1]

    fun dayHeaders(fa: Boolean): List<String> =
        if (fa) listOf("ش", "ی", "د", "س", "چ", "پ", "ج") else listOf("S", "M", "T", "W", "T", "F", "S")

    fun fmt(fa: Boolean, e: Long): String {
        val p = ymd(fa, e)
        val s = "${p[0]}/${pad2(p[1])}/${pad2(p[2])}"
        return if (fa) faDigits(s) else s
    }

    fun fmtLong(fa: Boolean, e: Long): String {
        val p = ymd(fa, e)
        val v = LocalDate.ofEpochDay(e).dayOfWeek.value
        return if (fa) {
            faDigits("${faWeek[v - 1]}، ${p[2]} ${faMonths[p[1] - 1]} ${p[0]}")
        } else {
            "${enWeek[v - 1]}, ${p[2]} ${enMonths[p[1] - 1]} ${p[0]}"
        }
    }
}

// ---------------------------------------------------------------- GlassLauncherX helpers

fun android.content.Context.findActivity(): android.app.Activity? {
    var c: android.content.Context = this
    while (c is android.content.ContextWrapper) {
        if (c is android.app.Activity) return c
        c = c.baseContext
    }
    return null
}

fun decodeSampled(path: String, max: Int): android.graphics.Bitmap? {
    val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
    android.graphics.BitmapFactory.decodeFile(path, o)
    var s = 1
    while (o.outWidth / s > max * 2 || o.outHeight / s > max * 2) s *= 2
    val o2 = android.graphics.BitmapFactory.Options().apply { inSampleSize = s }
    return android.graphics.BitmapFactory.decodeFile(path, o2)
}

fun sha256Hex(s: String): String =
    java.security.MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
